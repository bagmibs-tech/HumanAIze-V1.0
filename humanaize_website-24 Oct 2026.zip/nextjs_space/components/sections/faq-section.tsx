'use client';

import { useLanguage } from '@/lib/language-context';
import { faqGroups, getFaqItems, type FaqItem } from '@/lib/faq-data';
import { ChevronDown } from 'lucide-react';

type Lang = 'en' | 'de' | 'ar';

const headingText: Record<Lang, string> = {
  en: 'Frequently asked questions',
  de: 'Häufig gestellte Fragen',
  ar: 'الأسئلة الشائعة'
};

function FaqAccordion({ items, isRTL, lang }: { items: FaqItem[]; isRTL: boolean; lang: Lang }) {
  return (
    <div className="space-y-3">
      {items.map((item) => (
        <details
          key={item.id}
          className="group rounded-xl border border-gray-700/50 bg-[#111827]/70 px-5 py-4 open:border-cyan-500/40 transition-colors"
        >
          <summary
            className={`flex cursor-pointer items-center justify-between gap-4 list-none ${isRTL ? 'flex-row-reverse text-right' : ''}`}
          >
            <h3 className="text-base md:text-lg font-semibold text-white">{item.q[lang]}</h3>
            <ChevronDown className="text-cyan-400 flex-shrink-0 transition-transform group-open:rotate-180" size={20} />
          </summary>
          <p className={`mt-3 text-gray-300 leading-relaxed ${isRTL ? 'text-right' : ''}`}>{item.a[lang]}</p>
        </details>
      ))}
    </div>
  );
}

export default function FaqSection({
  ids,
  grouped = false,
  heading,
  className = ''
}: {
  ids?: string[];
  grouped?: boolean;
  heading?: string;
  className?: string;
}) {
  const { language } = useLanguage();
  const lang = (['en', 'de', 'ar'].includes(language) ? language : 'en') as Lang;
  const isRTL = lang === 'ar';

  const items: FaqItem[] = grouped
    ? faqGroups.flatMap((g) => g.items)
    : getFaqItems(ids || []);

  if (items.length === 0) return null;

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map((item) => ({
      '@type': 'Question',
      name: item.q[lang],
      acceptedAnswer: { '@type': 'Answer', text: item.a[lang] }
    }))
  };

  const sectionHeading = heading ?? headingText[lang];

  return (
    <section className={`py-16 px-4 bg-[#0a0e1a] ${className}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-4xl mx-auto">
        <h2 className={`text-2xl md:text-3xl font-bold text-white mb-8 ${isRTL ? 'text-right' : ''}`}>
          {sectionHeading}
        </h2>
        {grouped ? (
          <div className="space-y-10">
            {faqGroups.map((g) => (
              <div key={g.id}>
                <h3 className={`text-lg md:text-xl font-semibold text-cyan-300 mb-4 ${isRTL ? 'text-right' : ''}`}>
                  {g.title[lang]}
                </h3>
                <FaqAccordion items={g.items} isRTL={isRTL} lang={lang} />
              </div>
            ))}
          </div>
        ) : (
          <FaqAccordion items={items} isRTL={isRTL} lang={lang} />
        )}
      </div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
    </section>
  );
}
