'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

interface CaseStudiesHighlightProps {
  data: any;
  language: string;
}

const pageContent = {
  en: {
    title: 'Proven Impact Across Industries',
    subtitle: 'Proven ROI across DACH & UAE use cases in manufacturing, logistics, healthcare, and more',
    viewAll: 'View All Case Studies',
    cards: [
      {
        title: 'Manufacturing (DACH)',
        description: 'AI-Driven Quality Assurance',
        color: 'blue',
        metrics: [
          { value: '15pp+', label: 'defect detection (80% → 95%)' },
          { value: '30%', label: 'throughput gain' },
          { value: '100%', label: 'ERP traceability for audits' }
        ]
      },
      {
        title: 'Logistics (DACH & UAE)',
        description: 'AI-Powered AGV',
        color: 'orange',
        metrics: [
          { value: '20–40%', label: 'manpower capacity freed' },
          { value: '100%', label: 'automated material flow' },
          { value: 'Real-time', label: 'order scheduling' }
        ]
      },
      {
        title: 'Insurance & Healthcare',
        description: 'Medical Forms AI',
        color: 'blue',
        metrics: [
          { value: '92%', label: 'extraction accuracy' },
          { value: '<1 day', label: 'turnaround (from 5–7 days)' },
          { value: '50%', label: 'cost reduction' }
        ]
      }
    ]
  },
  de: {
    title: 'Nachgewiesene Wirkung in allen Branchen',
    subtitle: 'Nachgewiesener ROI in DACH & VAE Anwendungsfällen in Fertigung, Logistik, Gesundheitswesen und mehr',
    viewAll: 'Alle Fallstudien ansehen',
    cards: [
      {
        title: 'Fertigung (DACH)',
        description: 'KI-gesteuerte Qualitätssicherung',
        color: 'blue',
        metrics: [
          { value: '+15pp', label: 'Fehlererkennung (80% → 95%)' },
          { value: '30%', label: 'Durchsatzsteigerung' },
          { value: '100%', label: 'ERP-Rückverfolgbarkeit für Audits' }
        ]
      },
      {
        title: 'Logistik (DACH & VAE)',
        description: 'KI-gesteuerte FTS',
        color: 'orange',
        metrics: [
          { value: '20–40%', label: 'Personalkapazität freigesetzt' },
          { value: '100%', label: 'automatisierter Materialfluss' },
          { value: 'Echtzeit', label: 'Auftragsplanung' }
        ]
      },
      {
        title: 'Versicherung & Gesundheitswesen',
        description: 'Medizinische Formulare KI',
        color: 'blue',
        metrics: [
          { value: '92%', label: 'Extraktionsgenauigkeit' },
          { value: '<1 Tag', label: 'Bearbeitungszeit (von 5–7 Tagen)' },
          { value: '50%', label: 'Kostenreduzierung' }
        ]
      }
    ]
  },
  ar: {
    title: 'تأثير مثبت عبر الصناعات',
    subtitle: 'عائد استثمار مثبت عبر حالات استخدام DACH والإمارات في التصنيع والخدمات اللوجستية والرعاية الصحية والمزيد',
    viewAll: 'عرض جميع دراسات الحالة',
    cards: [
      {
        title: 'التصنيع (DACH)',
        description: 'ضمان الجودة بالذكاء الاصطناعي',
        color: 'blue',
        metrics: [
          { value: '+15 نقطة', label: 'اكتشاف العيوب (80% ← 95%)' },
          { value: '30%', label: 'زيادة الإنتاجية' },
          { value: '100%', label: 'تتبع ERP للتدقيق' }
        ]
      },
      {
        title: 'الخدمات اللوجستية (DACH والإمارات)',
        description: 'مركبات موجهة آلياً بالذكاء الاصطناعي',
        color: 'orange',
        metrics: [
          { value: '20-40%', label: 'تحرير قدرة القوى العاملة' },
          { value: '100%', label: 'تدفق المواد الآلي' },
          { value: 'فوري', label: 'جدولة الطلبات' }
        ]
      },
      {
        title: 'التأمين والرعاية الصحية',
        description: 'ذكاء اصطناعي للنماذج الطبية',
        color: 'blue',
        metrics: [
          { value: '92%', label: 'دقة الاستخراج' },
          { value: 'أقل من يوم', label: 'وقت المعالجة (من 5-7 أيام)' },
          { value: '50%', label: 'تخفيض التكلفة' }
        ]
      }
    ]
  }
};

export default function CaseStudiesHighlight({ data, language }: CaseStudiesHighlightProps) {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const content = pageContent[language as keyof typeof pageContent] || pageContent.en;

  return (
    <section ref={ref} className="py-20 bg-gradient-to-br from-blue-50 to-orange-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {content.title}
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            {content.subtitle}
          </p>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
          {content.cards.map((card, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-shadow"
            >
              <div className="mb-4">
                <h3 className="text-xl font-bold text-gray-900">{card.title}</h3>
                <p className="text-gray-500 text-sm">{card.description}</p>
              </div>
              
              <div className="space-y-4">
                {card.metrics.map((metric, mIndex) => (
                  <div 
                    key={mIndex} 
                    className={`border-l-4 ${card.color === 'orange' ? 'border-orange-500' : 'border-blue-600'} pl-4`}
                  >
                    <div className={`text-2xl font-bold ${card.color === 'orange' ? 'text-orange-500' : 'text-blue-600'}`}>
                      {metric.value}
                    </div>
                    <div className="text-sm text-gray-600">{metric.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center"
        >
          <Button
            asChild
            size="lg"
            className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white border-0"
          >
            <Link href="/case-studies">
              {content.viewAll}
              <ArrowRight className="ml-2" size={18} />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
