'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { useLanguage } from '@/lib/language-context';

const teaserContent = {
  eyebrow: {
    en: 'OUR APPROACH',
    de: 'WIE WIR ARBEITEN',
    ar: 'نهجنا'
  },
  title: {
    en: 'Our 5-Step Delivery Framework',
    de: 'Unser 5-Schritte-Umsetzungsrahmen',
    ar: 'إطار التنفيذ المكون من 5 خطوات'
  },
  subtitle: {
    en: 'From executive alignment to measurable AI ROI — governed, orchestrated, and accountable.',
    de: 'Von der Führungsabstimmung bis zum messbaren KI-ROI — gesteuert, orchestriert und verantwortlich.',
    ar: 'من التوافق التنفيذي إلى عائد استثمار قابل للقياس — محكوم ومنسق وخاضع للمساءلة.'
  },
  steps: [
    {
      number: '01',
      label: { en: 'Discovery', de: 'Entdeckung', ar: 'الاكتشاف' },
      desc: { en: 'Scope & metric baseline', de: 'Umfang & Metrik-Basis', ar: 'النطاق وخط الأساس' }
    },
    {
      number: '02',
      label: { en: 'Prioritise', de: 'Priorisieren', ar: 'الترتيب' },
      desc: { en: 'Impact × feasibility', de: 'Wirkung × Machbarkeit', ar: 'التأثير × الجدوى' }
    },
    {
      number: '03',
      label: { en: 'Blueprint', de: 'Konzipieren', ar: 'التخطيط' },
      desc: { en: 'Architecture & governance', de: 'Architektur & Steuerung', ar: 'البنية والحوكمة' }
    },
    {
      number: '04',
      label: { en: 'Execute', de: 'Umsetzen', ar: 'التنفيذ' },
      desc: { en: 'MVP in 6–12 weeks', de: 'MVP in 6–12 Wochen', ar: 'MVP في 6-12 أسبوع' }
    },
    {
      number: '05',
      label: { en: 'Scale', de: 'Skalieren', ar: 'التوسع' },
      desc: { en: 'Embed & measure ROI', de: 'Verankern & ROI messen', ar: 'التضمين وقياس العائد' }
    }
  ],
  benchmarks: [
    { value: { en: '90 Days', de: '90 Tage', ar: '90 يومًا' }, label: { en: 'to ROI', de: 'bis ROI', ar: 'للعائد' } },
    { value: { en: 'Governed', de: 'Gesteuert', ar: 'محكوم' }, label: { en: 'compliance', de: 'Compliance', ar: 'الامتثال' } },
    { value: { en: 'Accountable', de: 'Verantwortlich', ar: 'مسؤول' }, label: { en: 'single-owner', de: 'Einzelverantwortung', ar: 'مسؤول واحد' } }
  ],
  cta: {
    en: 'Explore Full Framework',
    de: 'Vollständiges Framework entdecken',
    ar: 'استكشف الإطار الكامل'
  }
};

interface HowWeWorkTeaserProps {
  data?: any;
  language?: string;
}

export default function HowWeWorkTeaser({ data, language: propLanguage }: HowWeWorkTeaserProps) {
  const { language: contextLanguage } = useLanguage();
  const language = propLanguage || contextLanguage;
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const isRTL = language === 'ar';

  const getText = (obj: Record<string, string>) => obj[language] || obj.en;

  return (
    <section
      ref={ref}
      className="py-20 bg-[#0B0F14] text-[#E5E9EF]"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center max-w-4xl mx-auto mb-12"
        >
          <p className="text-xs tracking-[2px] text-[#8FA3B8] mb-3">
            {getText(teaserContent.eyebrow)}
          </p>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            {getText(teaserContent.title)}
          </h2>
          <p className="text-[#AAB4BF] text-lg">
            {getText(teaserContent.subtitle)}
          </p>
        </motion.div>

        {/* Steps Flow - Horizontal on desktop, vertical on mobile */}
        <div className="mb-12">
          {/* Desktop: Horizontal flow with connecting line */}
          <div className="hidden md:block relative">
            {/* Connecting line */}
            <div className="absolute top-8 left-[10%] right-[10%] h-0.5 bg-gradient-to-r from-[#00AEEF]/20 via-[#00AEEF]/50 to-[#00AEEF]/20" />
            
            <div className="grid grid-cols-5 gap-4 relative">
              {teaserContent.steps.map((step, index) => (
                <motion.div
                  key={step.number}
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.1 * index }}
                  className="text-center relative"
                >
                  {/* Node */}
                  <div className="w-16 h-16 mx-auto mb-4 bg-[#121821] border-2 border-[#00AEEF] rounded-xl flex items-center justify-center relative z-10">
                    <span className="text-[#00AEEF] font-bold text-lg">{step.number}</span>
                  </div>
                  <h3 className="text-white font-semibold mb-1">
                    {getText(step.label)}
                  </h3>
                  <p className="text-[#8FA3B8] text-sm">
                    {getText(step.desc)}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Mobile: Compact vertical cards */}
          <div className="md:hidden space-y-3">
            {teaserContent.steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.4, delay: 0.08 * index }}
                className={`flex items-center gap-4 bg-[#121821] border border-white/5 rounded-xl p-4 ${isRTL ? 'flex-row-reverse' : ''}`}
              >
                <div className="bg-[#00AEEF] text-black font-bold w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0">
                  {step.number}
                </div>
                <div className={isRTL ? 'text-right' : ''}>
                  <h3 className="text-white font-semibold">{getText(step.label)}</h3>
                  <p className="text-[#8FA3B8] text-sm">{getText(step.desc)}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Benchmarks Strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-wrap justify-center gap-8 md:gap-16 mb-10 py-6 border-t border-b border-white/10"
        >
          {teaserContent.benchmarks.map((bench, i) => (
            <div key={i} className="text-center">
              <strong className="text-[#00AEEF] text-xl block">
                {getText(bench.value)}
              </strong>
              <span className="text-[#8FA3B8] text-sm">{getText(bench.label)}</span>
            </div>
          ))}
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          <Button 
            asChild 
            size="lg" 
            className="bg-[#00AEEF] hover:bg-[#00AEEF]/90 text-black font-semibold px-8"
          >
            <Link href="/how-we-work">
              {getText(teaserContent.cta)}
              <ArrowRight className={`${isRTL ? 'mr-2 rotate-180' : 'ml-2'}`} size={18} />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
