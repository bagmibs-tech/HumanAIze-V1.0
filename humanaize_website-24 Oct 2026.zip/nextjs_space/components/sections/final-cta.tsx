
'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import PlaybookArtefactButton from '@/components/sections/playbook-artefact-button';
import ReadinessDiagnosticButton from '@/components/sections/readiness-diagnostic-button';

interface FinalCTAProps {
  data: any;
  language: string;
}

export default function FinalCTA({ data, language }: FinalCTAProps) {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  
  const content = data?.content?.[language] || data?.content?.en || {};
  const { h2, supporting, cta_primary, cta_secondary } = content;

  return (
    <section ref={ref} className="py-24 bg-gradient-to-b from-[#1e3a5f] to-[#0f1729]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center space-y-8"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white">
            {h2}
          </h2>
          {supporting && (
            <p className="text-base md:text-lg text-gray-300 max-w-3xl mx-auto leading-relaxed">
              {supporting}
            </p>
          )}
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {cta_primary?.text && (
              <ReadinessDiagnosticButton
                language={language}
                label={cta_primary?.text}
                className="bg-cyan-500 hover:bg-cyan-600 text-white font-medium px-8 py-6 text-base rounded-full shadow-xl hover:shadow-2xl transition-all"
              />
            )}
            <PlaybookArtefactButton language={language} />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
