'use client';

import { useLanguage } from '@/lib/language-context';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Search, Zap, Cog, Users, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

const overviewContent = {
  en: {
    title: 'From Strategy to Scaled AI ROI',
    subtitle: 'The HumanAIze Operating System — value measured, never promised.',
    stageLabel: 'STAGE',
    optionalLabel: 'Optional',
    pillars: [
      {
        id: 'assess',
        number: '01',
        name: 'ASSESS',
        tagline: 'The 90-Day ROI Model',
        description: "A paid risk-reduction step, not a generic audit. ASSESS doesn't promise a 15–30% improvement — it tells you, with evidence, whether it's achievable in your organisation, and exactly where. IMPLEMENT is where you capture it. 4–8 weeks, fixed fee, single business unit.",
        highlights: ['Maturity Audit', 'Top-3 Use Cases', '90-Day Value Hypothesis'],
        color: 'blue'
      },
      {
        id: 'activate',
        number: '02',
        name: 'ACTIVATE',
        tagline: 'Scale Accelerator',
        optional: true,
        description: 'Design the enterprise foundation — roadmap, operating model and governance — when scaling beyond the first sprints.',
        highlights: ['3-Year Roadmap', 'Operating Model', 'Compliance Mapping'],
        color: 'cyan'
      },
      {
        id: 'implement',
        number: '03',
        name: 'IMPLEMENT',
        tagline: '90-Day ROI Sprints',
        description: 'Build and deploy priority use cases against a locked baseline — measured value, no unfalsifiable claims.',
        highlights: ['Build & Deploy', 'Baseline-Locked', 'TARA-A Governance'],
        color: 'slate'
      },
      {
        id: 'embed',
        number: '04',
        name: 'EMBED',
        tagline: 'Sustain & Scale',
        description: 'Scale proven winners org-wide, build AI capability at every level, and gate every sprint: scale, iterate, or kill.',
        highlights: ['Scale Winners', 'AI Capability Building', 'ROI-as-a-Service'],
        color: 'silver'
      }
    ],
    cta: 'Explore Our Full Service Framework',
    metrics: [
      { value: '90 Days', label: 'Per ROI Sprint' },
      { value: 'Day 90', label: 'Scale, Iterate or Kill Gate' },
      { value: 'Success Fee', label: 'Tied to Metric Uplift' }
    ]
  },
  de: {
    title: 'Von der Strategie zum skalierten AI-ROI',
    subtitle: 'Das HumanAIze Operating System — Wert wird gemessen, nie versprochen.',
    stageLabel: 'STUFE',
    optionalLabel: 'Optional',
    pillars: [
      {
        id: 'assess',
        number: '01',
        name: 'BEWERTEN',
        tagline: 'Das 90-Tage-ROI-Modell',
        description: 'Ein bezahlter Schritt zur Risikoreduktion, kein generisches Audit. ASSESS verspricht keine Verbesserung von 15–30 % — es sagt Ihnen mit Belegen, ob sie in Ihrer Organisation erreichbar ist und genau wo. IMPLEMENT ist, wo Sie sie realisieren. 4–8 Wochen, Festpreis, eine einzelne Geschäftseinheit.',
        highlights: ['Reifegrad-Audit', 'Top-3 Use Cases', '90-Tage-Werthypothese'],
        color: 'blue'
      },
      {
        id: 'activate',
        number: '02',
        name: 'AKTIVIEREN',
        tagline: 'Scale Accelerator',
        optional: true,
        description: 'Gestalten Sie das Fundament — Roadmap, Betriebsmodell und Governance — beim Skalieren über die ersten Sprints hinaus.',
        highlights: ['3-Jahres-Roadmap', 'Betriebsmodell', 'Compliance-Mapping'],
        color: 'cyan'
      },
      {
        id: 'implement',
        number: '03',
        name: 'IMPLEMENTIEREN',
        tagline: '90-Tage-ROI-Sprints',
        description: 'Prioritäre Use Cases gegen eine fixierte Basislinie bauen und ausrollen — gemessener Wert, keine unprüfbaren Versprechen.',
        highlights: ['Build & Deploy', 'Basislinie fixiert', 'TARA-A Governance'],
        color: 'slate'
      },
      {
        id: 'embed',
        number: '04',
        name: 'VERANKERN',
        tagline: 'Sustain & Scale',
        description: 'Bewährte Gewinner unternehmensweit skalieren, KI-Kompetenz auf allen Ebenen aufbauen und jeden Sprint bewerten: skalieren, iterieren oder stoppen.',
        highlights: ['Gewinner skalieren', 'KI-Kompetenzaufbau', 'ROI-as-a-Service'],
        color: 'silver'
      }
    ],
    cta: 'Unser vollständiges Service-Framework entdecken',
    metrics: [
      { value: '90 Tage', label: 'Pro ROI-Sprint' },
      { value: 'Tag 90', label: 'Skalieren, Iterieren oder Stoppen' },
      { value: 'Erfolgshonorar', label: 'An Metrik-Steigerung gekoppelt' }
    ]
  },
  ar: {
    title: 'من الاستراتيجية إلى عائد استثمار الذكاء الاصطناعي المُوسَّع',
    subtitle: 'نظام تشغيل HumanAIze — القيمة تُقاس ولا تُوعد.',
    stageLabel: 'المرحلة',
    optionalLabel: 'اختياري',
    pillars: [
      {
        id: 'assess',
        number: '01',
        name: 'التقييم',
        tagline: 'نموذج العائد في 90 يومًا',
        description: 'خطوة مدفوعة للحد من المخاطر، وليست تدقيقًا عامًا. لا يَعِد ASSESS بتحسّن بنسبة 15–30% — بل يخبرك، بالأدلة، ما إذا كان ذلك قابلاً للتحقيق في مؤسستك وأين بالضبط. أما IMPLEMENT فهو حيث تُحقّق ذلك. 4–8 أسابيع، رسوم ثابتة، وحدة أعمال واحدة.',
        highlights: ['تدقيق النضج', 'أفضل 3 حالات استخدام', 'فرضية القيمة 90 يوم'],
        color: 'blue'
      },
      {
        id: 'activate',
        number: '02',
        name: 'التفعيل',
        tagline: 'مُسرّع التوسع',
        optional: true,
        description: 'صمّم الأساس المؤسسي — خارطة الطريق ونموذج التشغيل والحوكمة — عند التوسع بعد السبرنتات الأولى.',
        highlights: ['خارطة طريق 3 سنوات', 'نموذج التشغيل', 'ربط الامتثال'],
        color: 'cyan'
      },
      {
        id: 'implement',
        number: '03',
        name: 'التنفيذ',
        tagline: 'سبرنتات العائد في 90 يومًا',
        description: 'بناء ونشر حالات الاستخدام ذات الأولوية مقابل خط أساس مُثبت — قيمة مقاسة دون ادّعاءات غير قابلة للتحقق.',
        highlights: ['البناء والنشر', 'خط أساس مُثبت', 'حوكمة TARA-A'],
        color: 'slate'
      },
      {
        id: 'embed',
        number: '04',
        name: 'التضمين',
        tagline: 'الاستدامة والتوسع',
        description: 'توسيع الناجحين المُثبتين على مستوى المؤسسة، وبناء قدرات الذكاء الاصطناعي على كل مستوى، وتقييم كل سبرنت: توسع أو تكرار أو إيقاف.',
        highlights: ['توسيع الناجحين', 'بناء قدرات الذكاء الاصطناعي', 'العائد كخدمة'],
        color: 'silver'
      }
    ],
    cta: 'استكشف إطار خدماتنا الكامل',
    metrics: [
      { value: '90 يومًا', label: 'لكل سبرنت عائد' },
      { value: 'اليوم 90', label: 'بوابة التوسع أو التكرار أو الإيقاف' },
      { value: 'رسوم النجاح', label: 'مرتبطة بتحسّن المقاييس' }
    ]
  }
};

const pillarIcons = {
  assess: Search,
  activate: Zap,
  implement: Cog,
  embed: Users
};

const getHeaderGradient = (color: string) => {
  switch (color) {
    case 'blue': return 'from-blue-600 to-blue-800';
    case 'cyan': return 'from-cyan-500 to-blue-600';
    case 'slate': return 'from-slate-500 to-slate-700';
    case 'silver': return 'from-gray-400 to-gray-600';
    default: return 'from-blue-600 to-cyan-500';
  }
};

const getPillBg = (color: string) => {
  switch (color) {
    case 'blue': return 'bg-blue-600';
    case 'cyan': return 'bg-cyan-500';
    case 'slate': return 'bg-slate-600';
    case 'silver': return 'bg-gray-500';
    default: return 'bg-blue-600';
  }
};

export default function ServicesOverview() {
  const { language } = useLanguage();
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });

  const content = overviewContent[language as keyof typeof overviewContent] || overviewContent.en;
  const isRTL = language === 'ar';

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-[#0a0e1a] via-[#0f1629] to-[#0a0e1a]" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-3">
            <span className="bg-gradient-to-r from-white via-cyan-200 to-blue-300 bg-clip-text text-transparent">
              {content.title}
            </span>
          </h2>
          <p className="text-lg md:text-xl text-gray-400">
            {content.subtitle}
          </p>
        </motion.div>

        {/* Pillars Flow Indicator */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-wrap items-center justify-center gap-2 md:gap-3 mb-10"
        >
          {content.pillars.map((pillar, index) => {
            const Icon = pillarIcons[pillar.id as keyof typeof pillarIcons];
            return (
              <div key={pillar.id} className="flex items-center">
                <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full ${getPillBg(pillar.color)} text-white font-medium text-sm`}>
                  <Icon size={14} />
                  {pillar.name}
                </div>
                {index < content.pillars.length - 1 && (
                  <ArrowRight className="text-gray-600 mx-1 hidden sm:block" size={16} />
                )}
              </div>
            );
          })}
        </motion.div>

        {/* Pillar Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5 mb-12">
          {content.pillars.map((pillar: any, index: number) => {
            const Icon = pillarIcons[pillar.id as keyof typeof pillarIcons];
            return (
              <motion.div
                key={pillar.id}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                className="bg-[#111827]/80 rounded-xl border border-gray-700/50 overflow-hidden hover:border-cyan-500/40 transition-all duration-300 group"
              >
                {/* Pillar Header */}
                <div className={`bg-gradient-to-r ${getHeaderGradient(pillar.color)} p-4`}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                      <Icon className="text-white" size={20} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-white/80 text-xs font-medium">{content.stageLabel} {pillar.number}</span>
                        {pillar.optional && (
                          <span className="text-[10px] font-semibold uppercase tracking-wide px-1.5 py-0.5 rounded bg-white/20 text-white">{content.optionalLabel}</span>
                        )}
                      </div>
                      <h3 className="text-lg font-bold text-white">{pillar.name}</h3>
                    </div>
                  </div>
                </div>

                {/* Pillar Content */}
                <div className="p-4">
                  <p className="text-cyan-400 font-medium text-sm mb-2">{pillar.tagline}</p>
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">{pillar.description}</p>
                  
                  <div className="flex flex-wrap gap-1.5">
                    {pillar.highlights.map((highlight: any, i: number) => (
                      <span key={i} className="text-xs px-2 py-1 bg-gray-800/50 text-gray-300 rounded-full border border-gray-700/50">
                        {highlight}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Metrics Strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="flex flex-wrap justify-center gap-6 md:gap-10 mb-10"
        >
          {content.metrics.map((metric, index) => (
            <div key={index} className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-cyan-400">{metric.value}</div>
              <div className="text-gray-500 text-sm">{metric.label}</div>
            </div>
          ))}
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="text-center"
        >
          <Link href="/services">
            <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white px-8 py-3 text-lg font-semibold shadow-lg shadow-cyan-500/25 hover:shadow-xl transition-all">
              {content.cta}
              <ArrowRight className={`${isRTL ? 'mr-2 rotate-180' : 'ml-2'}`} size={20} />
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}