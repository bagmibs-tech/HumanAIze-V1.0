'use client';

import { useState } from 'react';
import { getStoredUtm } from '@/hooks/use-utm';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  language: string;
  toolPath: string;
  formType: string;
  subject: string;
  downloadName: string;
  /** Language-resolved label shown on the trigger button and as the modal title. */
  toolName: string;
  className?: string;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const content = {
  en: {
    formDesc: (tool: string) => `Enter your details to open the ${tool} instantly.`,
    name: 'Full Name',
    email: 'Work Email',
    company: 'Company Name',
    jobTitle: 'Job Title (optional)',
    consent: 'I agree to receive communications from HumanAIze',
    submit: 'Open the tool',
    submitting: 'Opening\u2026',
    success: (tool: string) => `Your ${tool} is ready \u2014 opening it now.`,
    error: 'Something went wrong. Please try again.',
    required: 'Please fill in your name, work email and company.',
    invalidEmail: 'Please enter a valid work email address.',
  },
  de: {
    formDesc: (tool: string) => `Geben Sie Ihre Daten ein, um ${tool} sofort zu \u00f6ffnen.`,
    name: 'Vollst\u00e4ndiger Name',
    email: 'Gesch\u00e4ftliche E-Mail',
    company: 'Firmenname',
    jobTitle: 'Position (optional)',
    consent: 'Ich stimme zu, Mitteilungen von HumanAIze zu erhalten',
    submit: 'Tool \u00f6ffnen',
    submitting: 'Wird ge\u00f6ffnet\u2026',
    success: (tool: string) => `${tool} ist bereit \u2014 wird jetzt ge\u00f6ffnet.`,
    error: 'Etwas ist schiefgelaufen. Bitte versuchen Sie es erneut.',
    required: 'Bitte geben Sie Namen, gesch\u00e4ftliche E-Mail und Firma an.',
    invalidEmail: 'Bitte geben Sie eine g\u00fcltige gesch\u00e4ftliche E-Mail-Adresse ein.',
  },
  ar: {
    formDesc: (tool: string) => `\u0623\u062f\u062e\u0644 \u0628\u064a\u0627\u0646\u0627\u062a\u0643 \u0644\u0641\u062a\u062d ${tool} \u0641\u0648\u0631\u064b\u0627.`,
    name: '\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0643\u0627\u0645\u0644',
    email: '\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0644\u0644\u0639\u0645\u0644',
    company: '\u0627\u0633\u0645 \u0627\u0644\u0634\u0631\u0643\u0629',
    jobTitle: '\u0627\u0644\u0645\u0633\u0645\u0649 \u0627\u0644\u0648\u0638\u064a\u0641\u064a (\u0627\u062e\u062a\u064a\u0627\u0631\u064a)',
    consent: '\u0623\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u062a\u0644\u0642\u064a \u0627\u0644\u0645\u0631\u0627\u0633\u0644\u0627\u062a \u0645\u0646 HumanAIze',
    submit: '\u0627\u0641\u062a\u062d \u0627\u0644\u0623\u062f\u0627\u0629',
    submitting: '\u062c\u0627\u0631\u064d \u0627\u0644\u0641\u062a\u062d\u2026',
    success: (tool: string) => `${tool} \u062c\u0627\u0647\u0632 \u2014 \u064a\u062a\u0645 \u0641\u062a\u062d\u0647 \u0627\u0644\u0622\u0646.`,
    error: '\u062d\u062f\u062b \u062e\u0637\u0623 \u0645\u0627. \u0627\u0644\u0631\u062c\u0627\u0621 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0645\u0631\u0629 \u0623\u062e\u0631\u0649.',
    required: '\u0627\u0644\u0631\u062c\u0627\u0621 \u0625\u062f\u062e\u0627\u0644 \u0627\u0644\u0627\u0633\u0645 \u0648\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0648\u0627\u0644\u0634\u0631\u0643\u0629.',
    invalidEmail: '\u0627\u0644\u0631\u062c\u0627\u0621 \u0625\u062f\u062e\u0627\u0644 \u0628\u0631\u064a\u062f \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0635\u062d\u064a\u062d.',
  },
};

export default function ToolAccessButton({
  language,
  toolPath,
  formType,
  subject,
  downloadName,
  toolName,
  className,
}: Props) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [consent, setConsent] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isRTL = language === 'ar';
  const t = content[language as keyof typeof content] || content.en;

  const openTool = () => {
    const win = window.open(toolPath, '_blank');
    if (!win) {
      const link = document.createElement('a');
      link.href = toolPath;
      link.download = downloadName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name || !email || !company) {
      toast.error(t.required);
      return;
    }
    if (!EMAIL_RE.test(email)) {
      toast.error(t.invalidEmail);
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          company,
          subject,
          message: `Requested access to ${toolName}. Company: ${company}.${jobTitle ? ` Job title: ${jobTitle}.` : ''} Marketing consent: ${consent ? 'yes' : 'no'}.`,
          formType,
          ...getStoredUtm(),
        }),
      });

      if (response?.ok) {
        toast.success(t.success(toolName));
        openTool();
        setOpen(false);
        setName('');
        setEmail('');
        setCompany('');
        setJobTitle('');
        setConsent(false);
      } else {
        toast.error(t.error);
      }
    } catch (error) {
      console.error('Tool access error:', error);
      toast.error(t.error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Button
        onClick={() => setOpen(true)}
        size="lg"
        className={
          className ||
          'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold px-8 py-6 text-base rounded-full shadow-xl hover:shadow-cyan-500/40 transition-all'
        }
      >
        {toolName}
        <ArrowRight className={`${isRTL ? 'mr-2 rotate-180' : 'ml-2'}`} size={18} />
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md" dir={isRTL ? 'rtl' : 'ltr'}>
          <DialogHeader className={isRTL ? 'text-right' : ''}>
            <DialogTitle className="text-2xl font-bold">{toolName}</DialogTitle>
            <DialogDescription>{t.formDesc(toolName)}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 pt-2">
            <Input
              type="text"
              placeholder={t.name}
              value={name}
              onChange={(e) => setName(e?.target?.value || '')}
              required
              className="h-11"
            />
            <Input
              type="email"
              placeholder={t.email}
              value={email}
              onChange={(e) => setEmail(e?.target?.value || '')}
              required
              className="h-11"
            />
            <Input
              type="text"
              placeholder={t.company}
              value={company}
              onChange={(e) => setCompany(e?.target?.value || '')}
              required
              className="h-11"
            />
            <Input
              type="text"
              placeholder={t.jobTitle}
              value={jobTitle}
              onChange={(e) => setJobTitle(e?.target?.value || '')}
              className="h-11"
            />
            <div className={`flex items-start gap-2 ${isRTL ? 'flex-row-reverse text-right' : ''}`}>
              <Checkbox
                id={`tool-consent-${formType}`}
                checked={consent}
                onCheckedChange={(v) => setConsent(v === true)}
                className="mt-0.5"
              />
              <label htmlFor={`tool-consent-${formType}`} className="text-sm text-muted-foreground leading-snug cursor-pointer">
                {t.consent}
              </label>
            </div>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full h-11 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold"
            >
              {isSubmitting ? t.submitting : t.submit}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
