'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PricingStrategyProps {
  data?: any;
  language: string;
}

const teaserContent = {
  eyebrow: {
    en: 'OUR PRICING',
    de: 'UNSERE PREISE',
    ar: 'أسعارنا'
  },
  title: {
    en: 'Investment Models Aligned to Enterprise Outcomes',
    de: 'Investitionsmodelle ausgerichtet auf Unternehmensergebnisse',
    ar: 'نماذج استثمارية متوافقة مع نتائج المؤسسات'
  },
  subtitle: {
    en: 'We align fees to defined outcomes — not billable hours.',
    de: 'Wir orientieren unsere Honorare an definierten Ergebnissen — nicht an abrechenbaren Stunden.',
    ar: 'نحن نوائم الرسوم مع النتائج المحددة — وليس الساعات القابلة للفوترة.'
  },
  journey: {
    en: ['Entry', 'Blueprint', 'Delivery & Scale'],
    de: ['Einstieg', 'Konzeption', 'Lieferung & Skalierung'],
    ar: ['الدخول', 'التخطيط', 'التسليم والتوسع']
  },
  cards: [
    {
      kicker: { en: 'EXECUTIVE ENTRY', de: 'EXECUTIVE EINSTIEG', ar: 'الدخول التنفيذي' },
      title: { en: 'Executive Diagnostic', de: 'Executive-Diagnose', ar: 'التشخيص التنفيذي' },
      note: { en: 'Fixed-scope engagement', de: 'Engagement mit festem Umfang', ar: 'تعاقد بنطاق محدد' },
      icon: 'diagnostic',
      color: 'blue'
    },
    {
      kicker: { en: 'FOUNDATION', de: 'GRUNDLAGE', ar: 'الأساس' },
      title: { en: 'Transformation Blueprint', de: 'Transformations-Blueprint', ar: 'مخطط التحول' },
      note: { en: 'Milestone-based programme', de: 'Meilensteinbasiertes Programm', ar: 'برنامج قائم على المعالم' },
      featured: true,
      icon: 'blueprint',
      color: 'cyan'
    },
    {
      kicker: { en: 'SUSTAIN & SCALE', de: 'ERHALTEN & SKALIEREN', ar: 'الاستدامة والتوسع' },
      title: { en: 'Orchestrated Delivery & ROI Partnership', de: 'Orchestrierte Lieferung & ROI-Partnerschaft', ar: 'التسليم المنسق وشراكة العائد' },
      note: { en: 'Programme + retainer model', de: 'Programm + Retainer-Modell', ar: 'برنامج + نموذج التعاقد' },
      icon: 'scale',
      color: 'silver'
    }
  ],
  cta: {
    text: { en: 'View Full Pricing Models', de: 'Vollständige Preismodelle ansehen', ar: 'عرض نماذج التسعير الكاملة' },
    subtext: {
      en: 'We orient around our clients. Simply talk to us ☺',
      de: 'Wir orientieren uns an unseren Kunden. Sprechen Sie einfach mit uns ☺',
      ar: 'نحن نتمحور حول عملائنا. تحدث معنا ببساطة ☺'
    }
  }
};

const CardIcon = ({ type }: { type: string }) => {
  const icons: Record<string, JSX.Element> = {
    diagnostic: (
      <svg viewBox="0 0 24 24" className="w-6 h-6">
        <path d="M4 7h16M4 12h10M4 17h16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
      </svg>
    ),
    blueprint: (
      <svg viewBox="0 0 24 24" className="w-6 h-6">
        <path d="M4 20V8m0 0l4-4 4 4M4 8h8M14 20V4h6v16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    scale: (
      <svg viewBox="0 0 24 24" className="w-6 h-6">
        <path d="M12 2v4m0 12v4M4.2 4.2l2.8 2.8m10 10l2.8 2.8M2 12h4m12 0h4M4.2 19.8l2.8-2.8m10-10l2.8-2.8" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
        <path d="M8 12a4 4 0 1 0 8 0a4 4 0 1 0-8 0" fill="none" stroke="currentColor" strokeWidth="1.8"/>
      </svg>
    )
  };
  return icons[type] || icons.diagnostic;
};

export default function PricingStrategy({ data, language }: PricingStrategyProps) {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const isRTL = language === 'ar';

  const getText = (obj: Record<string, string | string[]>) => obj[language] || obj.en;

  const getCardBorderColor = (color: string, featured?: boolean) => {
    if (featured) return 'border-cyan-500/50 bg-gradient-to-br from-cyan-500/10 to-blue-500/5';
    if (color === 'blue') return 'border-blue-500/30 hover:border-blue-500/50';
    if (color === 'silver') return 'border-gray-400/30 hover:border-gray-400/50';
    return 'border-gray-600/30 hover:border-gray-600/50';
  };

  const getIconBgColor = (color: string) => {
    if (color === 'cyan') return 'bg-gradient-to-br from-cyan-500 to-blue-600';
    if (color === 'blue') return 'bg-gradient-to-br from-blue-500 to-blue-700';
    if (color === 'silver') return 'bg-gradient-to-br from-gray-400 to-gray-600';
    return 'bg-gradient-to-br from-blue-500 to-cyan-500';
  };

  return (
    <section
      id="pricing"
      ref={ref}
      className="py-20 bg-gradient-to-b from-[#0a0e1a] via-[#0f1629] to-[#0a0e1a] text-white"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <p className="text-xs tracking-[0.2em] uppercase text-cyan-400 mb-3 font-medium">
            {getText(teaserContent.eyebrow) as string}
          </p>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-white via-cyan-200 to-blue-300 bg-clip-text text-transparent">
            {getText(teaserContent.title) as string}
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            {getText(teaserContent.subtitle) as string}
          </p>
        </motion.div>

        {/* Journey Line */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex items-center justify-center gap-4 mb-10 flex-wrap"
        >
          {(getText(teaserContent.journey) as string[]).map((step, i) => (
            <div key={i} className="flex items-center gap-4">
              <span className="inline-flex items-center border border-cyan-500/30 bg-cyan-500/10 px-4 py-2 rounded-full text-sm text-cyan-300 font-medium">
                {step}
              </span>
              {i < 2 && <div className="w-10 h-0.5 bg-gradient-to-r from-cyan-500/50 to-blue-500/30" />}
            </div>
          ))}
        </motion.div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
          {teaserContent.cards.map((card, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 25 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.15 + index * 0.1 }}
              className={`relative overflow-hidden rounded-2xl p-5 border bg-[#111827]/80 backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-cyan-500/10 ${getCardBorderColor(card.color, card.featured)}`}
            >
              {card.featured && (
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-400" />
              )}

              {/* Card Top */}
              <div className={`flex gap-4 items-start ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className={`w-12 h-12 rounded-xl grid place-items-center text-white flex-shrink-0 ${getIconBgColor(card.color)}`}>
                  <CardIcon type={card.icon} />
                </div>
                <div className={isRTL ? 'text-right' : ''}>
                  <p className="text-xs tracking-[0.15em] uppercase text-gray-400 mb-1 font-medium">
                    {getText(card.kicker) as string}
                  </p>
                  <h3 className="text-lg font-bold text-white">
                    {getText(card.title) as string}
                  </h3>
                  <p className="text-cyan-400 text-sm mt-1 font-medium">
                    {getText(card.note) as string}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Box */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center"
        >
          {/* Subtext */}
          <div className="max-w-2xl mx-auto mb-6 py-4 px-6 rounded-2xl bg-gradient-to-r from-cyan-500/10 via-blue-500/5 to-gray-500/10 border border-cyan-500/20">
            <p className="text-lg text-white font-medium">
              {getText(teaserContent.cta.subtext) as string}
            </p>
          </div>

          <Button
            asChild
            size="lg"
            className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold px-8 shadow-lg shadow-cyan-500/25"
          >
            <Link href="/pricing">
              {getText(teaserContent.cta.text) as string}
              <ArrowRight className={`${isRTL ? 'mr-2 rotate-180' : 'ml-2'}`} size={18} />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
