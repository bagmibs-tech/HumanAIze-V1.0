'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

interface Props {
  language: string;
}

const content = {
  en: {
    problemHeading: 'Most enterprises have an AI strategy. Very few can show what it returned.',
    problemBody: "You approved the budget. You selected the vendor. Your teams attended the training. Twelve months later, the metric line hasn't moved. This is not an AI problem. It is a decision-systems problem \u2014 and it is more common than any consultancy will tell you, because most of them caused it. The gap between AI strategy and AI value is where HumanAIze operates. We don't sell transformation. We deliver the outcome it was supposed to produce.",
    cards: [
      { title: 'Outcome Based Fee, ROI-as-a-Service\u2122 in as less as 90 days', body: "We tie our engagement to outcomes baselined before we begin & measured as we proceed. Our fee is tied to milestones achieved & your success. No mindless hours billed either way. Is your present consultant's or vendor's fee aligned to your success? Ours is!" },
      { title: 'Vendor & tool agnostic. No lock-in. No dependency.', body: 'No preferred technology partner, no referral agreements, no platform to push \u2014 we start with your problem and our only incentive is your outcome. Every engagement builds toward hybrid-to-full capability building, so you get sustainable outcomes and not forever dependency.' },
      { title: 'Vetted Global Partner Network. End2End Accountability.', body: 'End-to-end human accountability, not a distributed pyramid. Every engagement is led by a senior practitioner, not graduate analysts or templated playbooks, and delivered through our vetted global partner network, with 25+ years of combined experience.' },
    ],
    diffHeading: 'Why enterprises choose HumanAIze over a Big4 firm',
    statsTitle: 'Our benchmark is not client satisfaction. It is client ROI.',
    statsLine: 'These are not projections. They are the standards we hold ourselves to \u2014 in writing, before the engagement begins.',
    stats: [
      { value: '15\u201330%', label: 'Process cycle time reduction' },
      { value: '20\u201328%', label: 'IT cost optimisation' },
      { value: '20\u201340%', label: 'AI-driven process acceleration' },
      { value: '15\u201325%', label: 'FTE productivity uplift' },
      { value: '90 days', label: 'to first measurable outcome' },
      { value: '18%', label: 'Revenue uplift' },
    ],
    whyConvert: {
      heading: 'Why Most AI Investment Never Converts',
      body1: 'Independent research puts the real conversion rate of enterprise AI spend into measured profit at closer to 10%, not the 25% most organisations self-report. The reason is structural, and it is not the algorithm.',
      colLeft: 'Where the challenge actually sits',
      colRight: 'Share of failure',
      rows: [
        { area: 'People and process: decision rights, workflow redesign, adoption', share: '70%' },
        { area: 'Data structure and readiness', share: '20%' },
        { area: 'The algorithm or model itself', share: '10%' },
      ],
      body2: 'Every vendor pitch leads with the 10%. HumanAIze is built for the 70%, because that is where enterprise AI budgets are actually won or lost.',
    },
    big4: {
      heading: 'How HumanAIze compares',
      criteriaLabel: 'Criteria',
      col2: 'Big4 / McKinsey',
      col3: 'HumanAIze',
      rows: [
        { c: 'Fee model', b: 'Billed by hours and team size', h: 'Tied to defined outcomes and KPIs' },
        { c: 'Execution', b: 'Strategy delivered, execution handed off', h: 'Strategy and execution: we stay until the number moves' },
        { c: 'Vendors', b: 'Preferred vendor ecosystem (SAP, Microsoft, Salesforce)', h: 'Vendor-neutral: no preferred platforms, no referral fees' },
        { c: 'Exit model', b: 'Dependency deepens with every engagement', h: 'Capability transfer: your team owns it when we leave' },
        { c: 'Team', b: 'Graduate analysts on your account', h: 'Curated senior experts, no juniors' },
        { c: 'Philosophy', b: 'AI as a technology implementation', h: 'AI as a human and decision-systems challenge' },
      ],
      closing: "You don't choose HumanAIze instead of McKinsey. You choose HumanAIze because McKinsey has already been, and the ROI line hasn't moved.",
    },
    landscape: {
      eyebrow: 'COMPETITIVE LANDSCAPE',
      heading: 'The White Space Nobody Owns',
      subheading: 'HumanAIze occupies the intersection of three vectors no incumbent combines.',
      caption: 'How HumanAIze compares with Big 4 firms, AI technology vendors, and boutique AI firms across six capabilities.',
      colCapability: 'Capability',
      colBig4: 'Big 4',
      colVendors: 'AI Tech Vendors',
      colBoutique: 'Boutique AI Firms',
      colUs: 'HumanAIze',
      partialWord: 'Partial',
      rows: [
        { cap: 'Vendor-Neutral', b: 'Vendor alliances', v: 'Own product first', bo: 'Partial', h: 'Structural — by design' },
        { cap: 'Outcome-Accountable', b: 'Hours billed', v: 'License sold', bo: 'Partial', h: 'ROI-as-a-Service, 90 days' },
        { cap: 'Agentic AI Governance', b: 'Reactive', v: 'Tool only, no framework', bo: 'Limited & reactive', h: 'Embedded & continuous (TARA-A)' },
        { cap: 'Scope & Intellectual Property', b: 'Standard & internal platform IP', v: 'Undefined', bo: 'Single market', h: 'Bespoke solution & reusable IP roadmap. DACH precision × MENA agility' },
        { cap: 'Boutique Agility', b: 'Bureaucratic', v: 'Product-led', bo: 'Yes', h: 'Yes + institutional scale' },
        { cap: 'Time to Value', b: 'Multi-year', v: 'Undefined', bo: 'Several months', h: '90 days or less, ROI-locked' },
      ],
      callout: 'The Big 4 are too slow and conflicted. Vendors are product-led. Boutiques lack institutional scale. HumanAIze is the only firm combining governance IP, outcome accountability, and a cross-market operator at founder level.',
      partners: 'Delivered with a global network of vetted strategic partners — selected for fit to your outcome, never for referral fees.',
    },
  },
  de: {
    problemHeading: 'Die meisten Unternehmen haben eine KI-Strategie. Nur wenige k\u00f6nnen zeigen, was sie eingebracht hat.',
    problemBody: 'Sie haben das Budget genehmigt. Sie haben den Anbieter ausgew\u00e4hlt. Ihre Teams haben an den Schulungen teilgenommen. Zw\u00f6lf Monate sp\u00e4ter hat sich die Metrik-Linie nicht bewegt. Das ist kein KI-Problem. Es ist ein Problem der Entscheidungssysteme \u2014 und es ist h\u00e4ufiger, als Ihnen irgendeine Beratung sagen wird, weil die meisten von ihnen es verursacht haben. Die L\u00fccke zwischen KI-Strategie und KI-Wert ist genau dort, wo HumanAIze arbeitet. Wir verkaufen keine Transformation. Wir liefern das Ergebnis, das sie h\u00e4tte erzielen sollen.',
    cards: [
      { title: 'Erfolgsbasiertes Honorar, ROI-as-a-Service\u2122 in nur 90 Tagen', body: 'Wir koppeln unser Engagement an Ergebnis-Baselines, die wir vor Beginn definieren und im Verlauf messen. Unser Honorar ist an erreichte Meilensteine und Ihren Erfolg gebunden. Keine sinnlosen Stunden, die in jedem Fall berechnet werden. Ist das Honorar Ihres derzeitigen Beraters oder Anbieters an Ihren Erfolg gekoppelt? Unseres schon!' },
      { title: 'Anbieter- & tool-agnostisch. Kein Lock-in. Keine Abh\u00e4ngigkeit.', body: 'Kein bevorzugter Technologiepartner, keine Vermittlungsvereinbarungen, keine Plattform, die wir pushen \u2014 wir beginnen mit Ihrem Problem, und unser einziger Anreiz ist Ihr Ergebnis. Jedes Engagement baut auf Hybrid-bis-Vollbef\u00e4higung auf, damit Sie nachhaltige Ergebnisse erhalten und keine dauerhafte Abh\u00e4ngigkeit.' },
      { title: 'Geprüftes globales Partnernetzwerk. End2End-Verantwortung.', body: 'End-to-End-Verantwortung durch Menschen, keine verteilte Pyramide. Jedes Engagement wird von einem erfahrenen Senior-Praktiker geleitet, nicht von Graduate-Analysten oder Playbooks von der Stange, und über unser geprüftes globales Partnernetzwerk umgesetzt, mit über 25 Jahren kombinierter Erfahrung.' },
    ],
    diffHeading: 'Warum sich Unternehmen f\u00fcr HumanAIze statt einer Big4-Firma entscheiden',
    statsLine: 'Das sind keine Prognosen. Es sind die Standards, an denen wir uns messen lassen \u2014 schriftlich, bevor das Engagement beginnt.',
    statsTitle: 'Unser Ma\u00dfstab ist nicht die Kundenzufriedenheit. Es ist der ROI des Kunden.',
    stats: [
      { value: '15\u201330%', label: 'Reduktion der Prozesszykluszeit' },
      { value: '20\u201328%', label: 'IT-Kostenoptimierung' },
      { value: '20\u201340%', label: 'KI-gest\u00fctzte Prozessbeschleunigung' },
      { value: '15\u201325%', label: 'FTE-Produktivit\u00e4tssteigerung' },
      { value: '90 Tage', label: 'bis zum ersten messbaren Ergebnis' },
      { value: '18%', label: 'Umsatzsteigerung' },
    ],
    whyConvert: {
      heading: 'Warum die meisten KI-Investitionen nie konvertieren',
      body1: 'Unabhängige Forschung beziffert die tatsächliche Konversionsrate von KI-Ausgaben im Unternehmen in gemessenen Gewinn auf eher 10 %, nicht die 25 %, die die meisten Organisationen selbst angeben. Der Grund ist struktureller Natur, und es ist nicht der Algorithmus.',
      colLeft: 'Wo die Herausforderung tatsächlich liegt',
      colRight: 'Anteil am Scheitern',
      rows: [
        { area: 'Menschen und Prozesse: Entscheidungsrechte, Workflow-Redesign, Adoption', share: '70%' },
        { area: 'Datenstruktur und -bereitschaft', share: '20%' },
        { area: 'Der Algorithmus oder das Modell selbst', share: '10%' },
      ],
      body2: 'Jeder Anbieter-Pitch führt mit den 10 %. HumanAIze ist für die 70 % gebaut, denn genau dort werden KI-Budgets im Unternehmen tatsächlich gewonnen oder verloren.',
    },
    big4: {
      heading: 'Wie HumanAIze im Vergleich abschneidet',
      criteriaLabel: 'Kriterium',
      col2: 'Big4 / McKinsey',
      col3: 'HumanAIze',
      rows: [
        { c: 'Honorarmodell', b: 'Abrechnung nach Stunden und Teamgröße', h: 'An definierte Ergebnisse und KPIs gekoppelt' },
        { c: 'Umsetzung', b: 'Strategie geliefert, Umsetzung übergeben', h: 'Strategie und Umsetzung: wir bleiben, bis sich die Zahl bewegt' },
        { c: 'Anbieter', b: 'Bevorzugtes Anbieter-Ökosystem (SAP, Microsoft, Salesforce)', h: 'Anbieterneutral: keine bevorzugten Plattformen, keine Vermittlungsgebühren' },
        { c: 'Exit-Modell', b: 'Abhängigkeit vertieft sich mit jedem Engagement', h: 'Fähigkeitstransfer: Ihr Team besitzt es, wenn wir gehen' },
        { c: 'Team', b: 'Graduate-Analysten in Ihrem Konto', h: 'Kuratierte Senior-Experten, keine Junioren' },
        { c: 'Philosophie', b: 'KI als technische Implementierung', h: 'KI als Herausforderung für Menschen und Entscheidungssysteme' },
      ],
      closing: 'Sie wählen HumanAIze nicht anstelle von McKinsey. Sie wählen HumanAIze, weil McKinsey bereits da war, und sich die ROI-Linie nicht bewegt hat.',
    },
    landscape: {
      eyebrow: 'WETTBEWERBSUMFELD',
      heading: 'Der weiße Fleck, den niemand besetzt',
      subheading: 'HumanAIze besetzt den Schnittpunkt dreier Vektoren, den kein etablierter Anbieter vereint.',
      caption: 'Wie HumanAIze im Vergleich zu Big-4-Firmen, KI-Technologieanbietern und Boutique-KI-Firmen über sechs Fähigkeiten abschneidet.',
      colCapability: 'Fähigkeit',
      colBig4: 'Big 4',
      colVendors: 'KI-Tech-Anbieter',
      colBoutique: 'Boutique-KI-Firmen',
      colUs: 'HumanAIze',
      partialWord: 'Teilweise',
      rows: [
        { cap: 'Vendor-neutral', b: 'Anbieterallianzen', v: 'Eigenes Produkt zuerst', bo: 'Teilweise', h: 'Strukturell — konzeptbedingt' },
        { cap: 'Ergebnisverantwortlich', b: 'Nach Stunden abgerechnet', v: 'Lizenz verkauft', bo: 'Teilweise', h: 'ROI-as-a-Service, 90 Tage' },
        { cap: 'Governance für agentische KI', b: 'Reaktiv', v: 'Nur Tool, kein Framework', bo: 'Begrenzt & reaktiv', h: 'Eingebettet & kontinuierlich (TARA-A)' },
        { cap: 'Umfang & geistiges Eigentum', b: 'Standard & interne Plattform-IP', v: 'Undefiniert', bo: 'Einzelmarkt', h: 'Maßgeschneiderte Lösung & wiederverwendbare IP-Roadmap. DACH-Präzision × MENA-Agilität' },
        { cap: 'Boutique-Agilität', b: 'Bürokratisch', v: 'Produktgetrieben', bo: 'Ja', h: 'Ja + institutionelle Skalierung' },
        { cap: 'Time-to-Value', b: 'Mehrjährig', v: 'Undefiniert', bo: 'Mehrere Monate', h: '90 Tage oder weniger, ROI-fixiert' },
      ],
      callout: 'Die Big 4 sind zu langsam und befangen. Anbieter sind produktgetrieben. Boutiquen fehlt die institutionelle Skalierung. HumanAIze ist die einzige Firma, die Governance-IP, Ergebnisverantwortung und einen marktübergreifenden Operator auf Gründerebene vereint.',
      partners: 'Umgesetzt mit einem globalen Netzwerk geprüfter strategischer Partner — ausgewählt nach Eignung für Ihr Ergebnis, niemals nach Vermittlungsgebühren.',
    },
  },
  ar: {
    problemHeading: '\u0645\u0639\u0638\u0645 \u0627\u0644\u0645\u0624\u0633\u0633\u0627\u062a \u0644\u062f\u064a\u0647\u0627 \u0627\u0633\u062a\u0631\u0627\u062a\u064a\u062c\u064a\u0629 \u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064a. \u0642\u0644\u064a\u0644\u0629 \u062c\u062f\u064b\u0627 \u064a\u0645\u0643\u0646\u0647\u0627 \u0625\u0638\u0647\u0627\u0631 \u0645\u0627 \u062d\u0642\u0642\u062a\u0647.',
    problemBody: '\u0644\u0642\u062f \u0627\u0639\u062a\u0645\u062f\u062a \u0627\u0644\u0645\u064a\u0632\u0627\u0646\u064a\u0629. \u0627\u062e\u062a\u0631\u062a \u0627\u0644\u0645\u0648\u0631\u062f. \u062d\u0636\u0631\u062a \u0641\u0631\u0642\u0643 \u0627\u0644\u062a\u062f\u0631\u064a\u0628. \u0628\u0639\u062f \u0627\u062b\u0646\u064a \u0639\u0634\u0631 \u0634\u0647\u0631\u064b\u0627\u060c \u0644\u0645 \u064a\u062a\u062d\u0631\u0643 \u062e\u0637 \u0627\u0644\u0645\u0642\u0627\u064a\u064a\u0633. \u0647\u0630\u0647 \u0644\u064a\u0633\u062a \u0645\u0634\u0643\u0644\u0629 \u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064a. \u0625\u0646\u0647\u0627 \u0645\u0634\u0643\u0644\u0629 \u0623\u0646\u0638\u0645\u0629 \u0642\u0631\u0627\u0631 \u2014 \u0648\u0647\u064a \u0623\u0643\u062b\u0631 \u0634\u064a\u0648\u0639\u064b\u0627 \u0645\u0645\u0627 \u0633\u062a\u062e\u0628\u0631\u0643 \u0628\u0647 \u0623\u064a \u0634\u0631\u0643\u0629 \u0627\u0633\u062a\u0634\u0627\u0631\u064a\u0629\u060c \u0644\u0623\u0646 \u0645\u0639\u0638\u0645\u0647\u0627 \u062a\u0633\u0628\u0628 \u0641\u064a\u0647\u0627. \u0627\u0644\u0641\u062c\u0648\u0629 \u0628\u064a\u0646 \u0627\u0633\u062a\u0631\u0627\u062a\u064a\u062c\u064a\u0629 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0648\u0642\u064a\u0645\u062a\u0647 \u0647\u064a \u062d\u064a\u062b \u062a\u0639\u0645\u0644 HumanAIze. \u0646\u062d\u0646 \u0644\u0627 \u0646\u0628\u064a\u0639 \u0627\u0644\u062a\u062d\u0648\u0644. \u0646\u062d\u0646 \u0646\u062d\u0642\u0642 \u0627\u0644\u0646\u062a\u064a\u062c\u0629 \u0627\u0644\u062a\u064a \u0643\u0627\u0646 \u0645\u0646 \u0627\u0644\u0645\u0641\u062a\u0631\u0636 \u0623\u0646 \u064a\u062d\u0642\u0642\u0647\u0627.',
    cards: [
      { title: 'أتعاب قائمة على النتائج، ROI-as-a-Service™ في 90 يومًا فقط', body: 'نربط ارتباطنا بخطوط أساس النتائج قبل أن نبدأ ونقيسها أثناء التقدم. أتعابنا مرتبطة بالمعالم المحققة ونجاحك. لا ساعات عشوائية تُحاسب في أي حال. هل أتعاب مستشارك أو موردك الحالي مرتبطة بنجاحك؟ أتعابنا كذلك!' },
      { title: 'محايدون تجاه الموردين والأدوات. لا احتكار. لا اعتمادية.', body: 'لا شريك تقني مفضل، ولا اتفاقيات إحالة، ولا منصة نروّج لها — نبدأ بمشكلتك، وحافزنا الوحيد هو نتيجتك. كل ارتباط يبني قدراتك من النموذج الهجين إلى التمكين الكامل، لتحصل على نتائج مستدامة وليس اعتمادًا دائمًا.' },
      { title: 'شبكة شركاء عالمية معتمدة. مسؤولية شاملة.', body: 'مسؤولية بشرية شاملة، لا هرم موزَّع. يقود كل ارتباط ممارس كبير — لا محللون حديثو التخرج، ولا كتيبات جاهزة — يُنفَّذ عبر شبكة شركائنا العالمية المعتمدة، أكثر من 25 عامًا من الخبرة المشتركة.' },
    ],
    diffHeading: 'لماذا تختار المؤسسات HumanAIze بدلاً من شركات Big4',
    statsLine: 'هذه ليست توقعات. إنها المعايير التي نُلزم أنفسنا بها — كتابةً، قبل أن يبدأ الارتباط.',
    statsTitle: 'معيارنا ليس رضا العميل. إنه العائد على استثمار العميل.',
    stats: [
      { value: '15-30%', label: '\u062a\u0642\u0644\u064a\u0644 \u0632\u0645\u0646 \u062f\u0648\u0631\u0629 \u0627\u0644\u0639\u0645\u0644\u064a\u0629' },
      { value: '20-28%', label: '\u062a\u062d\u0633\u064a\u0646 \u062a\u0643\u0627\u0644\u064a\u0641 \u062a\u0643\u0646\u0648\u0644\u0648\u062c\u064a\u0627 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a' },
      { value: '20-40%', label: '\u062a\u0633\u0631\u064a\u0639 \u0627\u0644\u0639\u0645\u0644\u064a\u0627\u062a \u0628\u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a' },
      { value: '15-25%', label: '\u0631\u0641\u0639 \u0625\u0646\u062a\u0627\u062c\u064a\u0629 \u0627\u0644\u0645\u0648\u0638\u0641\u064a\u0646' },
      { value: '90 \u064a\u0648\u0645\u064b\u0627', label: '\u062d\u062a\u0649 \u0623\u0648\u0644 \u0646\u062a\u064a\u062c\u0629 \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u0642\u064a\u0627\u0633' },
      { value: '18%', label: 'زيادة الإيرادات' },
    ],
    whyConvert: {
      heading: 'لماذا لا يتحول معظم الاستثمار في الذكاء الاصطناعي إلى قيمة',
      body1: 'تُقدّر الأبحاث المستقلة المعدل الحقيقي لتحويل إنفاق الذكاء الاصطناعي المؤسسي إلى ربح مقاس بنحو 10% لا 25% كما تُبلّغ معظم المؤسسات عن نفسها. والسبب بنيوي — وليس الخوارزمية.',
      colLeft: 'أين يكمن التحدي فعليًا',
      colRight: 'نصيبه من الفشل',
      rows: [
        { area: 'الأشخاص والعمليات — حقوق القرار، وإعادة تصميم سير العمل، والتبنّي', share: '70%' },
        { area: 'بنية البيانات وجاهزيتها', share: '20%' },
        { area: 'الخوارزمية أو النموذج نفسه', share: '10%' },
      ],
      body2: 'كل عرض مورد يبدأ بالـ 10%. أما HumanAIze فمبنية للـ 70% — لأن هناك تحديدًا تُكسب ميزانيات الذكاء الاصطناعي المؤسسية أو تُخسر.',
    },
    big4: {
      heading: 'كيف تُقارَن HumanAIze',
      criteriaLabel: 'المعيار',
      col2: 'Big4 / McKinsey',
      col3: 'HumanAIze',
      rows: [
        { c: 'نموذج الأتعاب', b: 'الفوترة حسب الساعات وحجم الفريق', h: 'مرتبط بنتائج ومؤشرات أداء محددة' },
        { c: 'التنفيذ', b: 'تُسلَّم الاستراتيجية ويُسلَّم التنفيذ لغيرها', h: 'الاستراتيجية والتنفيذ — نبقى حتى يتحرك الرقم' },
        { c: 'الموردون', b: 'منظومة موردين مفضّلة (SAP، Microsoft، Salesforce)', h: 'محايد تجاه الموردين — لا منصات مفضّلة ولا رسوم إحالة' },
        { c: 'نموذج الخروج', b: 'تتعمّق الاعتمادية مع كل ارتباط', h: 'نقل القدرات — يملكه فريقك عندما نغادر' },
        { c: 'الفريق', b: 'محللون حديثو التخرج على حسابك', h: 'خبراء كبار منتقون، بلا مبتدئين' },
        { c: 'الفلسفة', b: 'الذكاء الاصطناعي كتطبيق تقني', h: 'الذكاء الاصطناعي كتحدٍّ بشري وأنظمة قرار' },
      ],
      closing: 'أنت لا تختار HumanAIze بدلاً من McKinsey. أنت تختار HumanAIze لأن McKinsey قد حضرت بالفعل — ولم يتحرك خط العائد على الاستثمار.',
    },
    landscape: {
      eyebrow: 'المشهد التنافسي',
      heading: 'المساحة الفارغة التي لا يملكها أحد',
      subheading: 'تشغل HumanAIze نقطة تقاطع ثلاثة محاور لا يجمعها أي لاعب قائم.',
      caption: 'كيف تُقارَن HumanAIze بشركات Big 4 وموردي تقنيات الذكاء الاصطناعي وشركات الذكاء الاصطناعي المتخصصة عبر ست قدرات.',
      colCapability: 'القدرة',
      colBig4: 'Big 4',
      colVendors: 'موردو تقنيات الذكاء الاصطناعي',
      colBoutique: 'شركات ذكاء اصطناعي متخصصة',
      colUs: 'HumanAIze',
      partialWord: 'جزئي',
      rows: [
        { cap: 'محايد تجاه الموردين', b: 'تحالفات مع موردين', v: 'منتجهم أولاً', bo: 'جزئي', h: 'هيكلي — بحكم التصميم' },
        { cap: 'مسؤول عن النتائج', b: 'الفوترة بالساعات', v: 'بيع الترخيص', bo: 'جزئي', h: 'ROI-as-a-Service، 90 يومًا' },
        { cap: 'حوكمة الذكاء الاصطناعي الوكيلي', b: 'تفاعلي', v: 'أداة فقط، بلا إطار', bo: 'محدود وتفاعلي', h: 'مُدمَج ومستمر (TARA-A)' },
        { cap: 'النطاق والملكية الفكرية', b: 'قياسي وملكية فكرية داخلية للمنصة', v: 'غير محدد', bo: 'سوق واحد', h: 'حل مُفصَّل وخارطة طريق ملكية فكرية قابلة لإعادة الاستخدام. دقة DACH × مرونة MENA' },
        { cap: 'مرونة الشركات المتخصصة', b: 'بيروقراطي', v: 'مدفوع بالمنتج', bo: 'نعم', h: 'نعم + نطاق مؤسسي' },
        { cap: 'زمن تحقيق القيمة', b: 'متعدد السنوات', v: 'غير محدد', bo: 'عدة أشهر', h: '90 يومًا أو أقل، بعائد مثبّت' },
      ],
      callout: 'الشركات الأربع الكبرى بطيئة ومتضاربة المصالح. الموردون مدفوعون بالمنتج. والشركات المتخصصة تفتقر إلى النطاق المؤسسي. HumanAIze هي الشركة الوحيدة التي تجمع بين الملكية الفكرية للحوكمة، والمسؤولية عن النتائج، ومشغّل عابر للأسواق على مستوى المؤسس.',
      partners: 'يُنفَّذ عبر شبكة عالمية من الشركاء الاستراتيجيين المعتمدين — يُختارون بناءً على ملاءمتهم لنتيجتك، لا مقابل رسوم إحالة.',
    },
  },
};

export default function ProblemDifferentiation({ language }: Props) {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const c = (content as any)[language] || content.en;
  const isRTL = language === 'ar';

  return (
    <section
      ref={ref}
      dir={isRTL ? 'rtl' : 'ltr'}
      className="py-20 px-4 bg-gradient-to-b from-[#0f1729] to-[#0a0e1a]"
    >
      <div className="max-w-6xl mx-auto">
        {/* Problem */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto text-center mb-16"
        >
          <h2 className="text-2xl md:text-4xl font-bold text-white mb-6 leading-tight">
            <span className="bg-gradient-to-r from-white via-cyan-200 to-blue-300 bg-clip-text text-transparent">
              {c.problemHeading}
            </span>
          </h2>
          <p className="text-base md:text-lg text-gray-400 leading-relaxed">{c.problemBody}</p>
        </motion.div>

        {/* Why Most AI Investment Never Converts */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="max-w-4xl mx-auto mb-16"
        >
          <h3 className="text-2xl md:text-3xl font-bold text-white mb-5 text-center leading-tight">{c.whyConvert.heading}</h3>
          <p className="text-base md:text-lg text-gray-400 leading-relaxed mb-8">{c.whyConvert.body1}</p>
          <div className="bg-[#111827]/80 rounded-2xl border border-gray-700/50 overflow-hidden mb-8">
            <div className="grid grid-cols-3 bg-[#0a0e1a]/60 border-b border-gray-700/50">
              <div className="col-span-2 px-5 py-3 text-sm font-semibold text-gray-300">{c.whyConvert.colLeft}</div>
              <div className="px-5 py-3 text-sm font-semibold text-cyan-400 text-center">{c.whyConvert.colRight}</div>
            </div>
            {c.whyConvert.rows.map((row: any, i: number) => (
              <div key={i} className="grid grid-cols-3 border-b border-gray-700/30 last:border-0">
                <div className="col-span-2 px-5 py-4 text-sm text-gray-400 leading-relaxed">{row.area}</div>
                <div className="px-5 py-4 text-xl md:text-2xl font-bold text-cyan-400 text-center">{row.share}</div>
              </div>
            ))}
          </div>
          <p className="text-base md:text-lg text-gray-400 leading-relaxed">{c.whyConvert.body2}</p>
        </motion.div>

        {/* Competitive Landscape */}
        {c.landscape && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="max-w-5xl mx-auto mb-16"
          >
            <div className="text-center mb-8">
              <p className="text-xs md:text-sm font-semibold tracking-[0.2em] text-cyan-400 uppercase mb-3">
                {c.landscape.eyebrow}
              </p>
              <h3 className="text-2xl md:text-3xl font-bold mb-4 leading-tight">
                <span className="bg-gradient-to-r from-white via-cyan-200 to-blue-300 bg-clip-text text-transparent">
                  {c.landscape.heading}
                </span>
              </h3>
              <p className="text-base md:text-lg text-gray-400 leading-relaxed max-w-2xl mx-auto">
                {c.landscape.subheading}
              </p>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-cyan-500/20">
              <table className="w-full border-collapse min-w-[820px] text-sm">
                <caption className="sr-only">{c.landscape.caption}</caption>
                <thead>
                  <tr>
                    <th
                      scope="col"
                      className={`sticky ${isRTL ? 'right-0' : 'left-0'} z-20 px-4 py-4 min-w-[160px] text-[#E2E8F0] font-semibold ${isRTL ? 'text-right' : 'text-left'}`}
                      style={{ backgroundColor: '#1A2540' }}
                    >
                      {c.landscape.colCapability}
                    </th>
                    <th scope="col" className={`px-4 py-4 min-w-[150px] text-[#E2E8F0] font-semibold ${isRTL ? 'text-right' : 'text-left'}`} style={{ backgroundColor: '#1A2540' }}>
                      {c.landscape.colBig4}
                    </th>
                    <th scope="col" className={`px-4 py-4 min-w-[150px] text-[#E2E8F0] font-semibold ${isRTL ? 'text-right' : 'text-left'}`} style={{ backgroundColor: '#1A2540' }}>
                      {c.landscape.colVendors}
                    </th>
                    <th scope="col" className={`px-4 py-4 min-w-[150px] text-[#E2E8F0] font-semibold ${isRTL ? 'text-right' : 'text-left'}`} style={{ backgroundColor: '#1A2540' }}>
                      {c.landscape.colBoutique}
                    </th>
                    <th
                      scope="col"
                      className={`px-4 py-4 min-w-[170px] text-[#0a0e1a] font-bold border-2 border-[#38BDF8] ${isRTL ? 'text-right' : 'text-left'}`}
                      style={{ backgroundColor: '#38BDF8' }}
                    >
                      {c.landscape.colUs}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {c.landscape.rows.map((row: any, i: number) => {
                    const navy = i % 2 === 0 ? '#243352' : '#1A2540';
                    const others = [row.b, row.v, row.bo];
                    return (
                      <tr key={i}>
                        <th
                          scope="row"
                          className={`sticky ${isRTL ? 'right-0' : 'left-0'} z-10 px-4 py-4 min-w-[160px] text-[#E2E8F0] font-medium align-top ${isRTL ? 'text-right' : 'text-left'}`}
                          style={{ backgroundColor: navy }}
                        >
                          {row.cap}
                        </th>
                        {others.map((cell: string, j: number) => (
                          <td
                            key={j}
                            className={`px-4 py-4 align-top text-sm ${isRTL ? 'text-right' : 'text-left'} ${cell === c.landscape.partialWord ? 'text-[#67C8F0] font-medium' : 'text-[#E2E8F0]'}`}
                            style={{ backgroundColor: navy }}
                          >
                            {cell}
                          </td>
                        ))}
                        <td
                          className={`px-4 py-4 align-top text-sm font-bold text-[#2ABFBF] border-2 border-[#38BDF8] ${isRTL ? 'text-right' : 'text-left'}`}
                          style={{ backgroundColor: 'rgba(56,189,248,0.05)' }}
                        >
                          {row.h}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className={`mt-6 rounded-xl bg-[#111827]/80 border ${isRTL ? 'border-r-4' : 'border-l-4'} border-cyan-400 px-6 py-5`}>
              <p className="text-sm md:text-base text-gray-200 leading-relaxed">{c.landscape.callout}</p>
            </div>
            <p className="mt-3 px-1 text-xs md:text-sm text-cyan-300/90 leading-relaxed">{c.landscape.partners}</p>
          </motion.div>
        )}

        {/* Benchmark stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.2 }}
        >
          <h3 className="text-center text-lg md:text-xl font-semibold text-gray-300 mb-8">{c.statsTitle}</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {c.stats.map((s: any, i: number) => (
              <div
                key={i}
                className="bg-[#111827]/80 p-5 rounded-xl border border-cyan-500/20 text-center hover:border-cyan-400/40 transition-all"
              >
                <div className="text-2xl md:text-3xl font-bold text-cyan-400 mb-1">{s.value}</div>
                <div className="text-gray-500 text-xs md:text-sm leading-snug">{s.label}</div>
              </div>
            ))}
          </div>
          {c.statsLine && (
            <p className="text-sm md:text-base text-gray-500 leading-relaxed text-center mt-8 max-w-3xl mx-auto">{c.statsLine}</p>
          )}
        </motion.div>
      </div>
    </section>
  );
}
