'use client';

import { Fragment, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';

export type AdminRow = {
  id: string;
  source: string;
  name: string;
  email: string;
  company: string;
  createdAt: string;
  utmSource?: string | null;
  utmMedium?: string | null;
  utmCampaign?: string | null;
  utmContent?: string | null;
  utmTerm?: string | null;
  detail: Record<string, any>;
};

const SOURCES = [
  'All',
  'Contact Form',
  'Framework Download',
  'Readiness Diagnostic',
  'Readiness Assessment',
  'ROI Calculator',
  'Blindspot Lead',
  'Blindspot Unlock',
] as const;

function fmtVal(v: any): string {
  if (v === null || v === undefined || v === '') return '\u2014';
  if (typeof v === 'boolean') return v ? 'Yes' : 'No';
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}

function fmtDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString('en-GB', { timeZone: 'UTC' }) + ' UTC';
}

function utmBadge(row: AdminRow): string {
  if (row.utmSource) return row.utmSource + (row.utmMedium ? ` / ${row.utmMedium}` : '');
  return '\u2014';
}

/* ── UTM Link Builder ── */
function UtmLinkBuilder() {
  const [source, setSource] = useState('');
  const [medium, setMedium] = useState('');
  const [campaign, setCampaign] = useState('');
  const [content, setContent] = useState('');
  const [term, setTerm] = useState('');
  const [page, setPage] = useState('/');
  const [copied, setCopied] = useState(false);

  const url = useMemo(() => {
    const base = 'https://human-aize.com' + page;
    const p = new URLSearchParams();
    if (source) p.set('utm_source', source);
    if (medium) p.set('utm_medium', medium);
    if (campaign) p.set('utm_campaign', campaign);
    if (content) p.set('utm_content', content);
    if (term) p.set('utm_term', term);
    const qs = p.toString();
    return qs ? `${base}?${qs}` : base;
  }, [source, medium, campaign, content, term, page]);

  function copy() {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  const presets = [
    { label: 'LinkedIn DM', s: 'linkedin', m: 'dm' },
    { label: 'LinkedIn Post', s: 'linkedin', m: 'social' },
    { label: 'WhatsApp', s: 'whatsapp', m: 'chat' },
    { label: 'ABM Email', s: 'abm', m: 'email' },
    { label: 'Cold Email', s: 'email', m: 'outbound' },
    { label: 'Referral', s: 'referral', m: 'partner' },
  ];

  const inputCls = 'bg-[#0a0e1a] border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:border-cyan-500 focus:outline-none w-full';

  return (
    <div className="rounded-xl border border-gray-700/60 bg-[#111827] p-5">
      <h2 className="text-lg font-semibold text-white mb-4">UTM Link Builder</h2>
      <div className="flex flex-wrap gap-2 mb-4">
        {presets.map((p) => (
          <button
            key={p.label}
            onClick={() => { setSource(p.s); setMedium(p.m); }}
            className="rounded-full border border-gray-600 text-gray-300 text-xs px-3 py-1 hover:border-cyan-500/70 hover:text-cyan-300 transition-colors"
          >
            {p.label}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
        <div>
          <label className="block text-gray-400 text-xs mb-1">Landing Page</label>
          <select value={page} onChange={(e) => setPage(e.target.value)} className={inputCls}>
            {['/', '/services', '/pricing', '/how-we-work', '/about', '/contact', '/blog', '/case-studies', '/assessment', '/resources'].map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-gray-400 text-xs mb-1">Source *</label>
          <input value={source} onChange={(e) => setSource(e.target.value)} placeholder="e.g. linkedin" className={inputCls} />
        </div>
        <div>
          <label className="block text-gray-400 text-xs mb-1">Medium *</label>
          <input value={medium} onChange={(e) => setMedium(e.target.value)} placeholder="e.g. dm" className={inputCls} />
        </div>
        <div>
          <label className="block text-gray-400 text-xs mb-1">Campaign</label>
          <input value={campaign} onChange={(e) => setCampaign(e.target.value)} placeholder="e.g. q3-outreach" className={inputCls} />
        </div>
        <div>
          <label className="block text-gray-400 text-xs mb-1">Content</label>
          <input value={content} onChange={(e) => setContent(e.target.value)} placeholder="e.g. cta-variant-a" className={inputCls} />
        </div>
        <div>
          <label className="block text-gray-400 text-xs mb-1">Term</label>
          <input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="optional keyword" className={inputCls} />
        </div>
      </div>
      <div className="flex items-center gap-3">
        <code className="flex-1 bg-[#0a0e1a] text-cyan-300 text-xs p-3 rounded-lg overflow-x-auto whitespace-nowrap">{url}</code>
        <button onClick={copy} className="rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-semibold px-4 py-2 transition-colors whitespace-nowrap">
          {copied ? 'Copied!' : 'Copy'}
        </button>
      </div>
    </div>
  );
}

/* ── Main Dashboard ── */
export default function AdminDashboard({ rows }: { rows: AdminRow[] }) {
  const router = useRouter();
  const [filter, setFilter] = useState<string>('All');
  const [utmFilter, setUtmFilter] = useState<string>('All');
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [showBuilder, setShowBuilder] = useState(false);

  // Unique UTM sources for filter
  const utmSources = useMemo(() => {
    const s = new Set<string>();
    for (const r of rows) if (r.utmSource) s.add(r.utmSource);
    return Array.from(s).sort();
  }, [rows]);

  const filtered = useMemo(() => {
    let res = rows;
    if (filter !== 'All') res = res.filter((r) => r.source === filter);
    if (utmFilter === 'Direct') res = res.filter((r) => !r.utmSource);
    else if (utmFilter !== 'All') res = res.filter((r) => r.utmSource === utmFilter);
    return res;
  }, [rows, filter, utmFilter]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { All: rows.length };
    for (const r of rows) c[r.source] = (c[r.source] || 0) + 1;
    return c;
  }, [rows]);

  function toggle(id: string) {
    setExpanded((e) => ({ ...e, [id]: !e[id] }));
  }

  function exportCsv() {
    const detailKeys = Array.from(
      new Set(filtered.flatMap((r) => Object.keys(r.detail)))
    );
    const headers = ['Source', 'Name', 'Email', 'Company', 'UTM Source', 'UTM Medium', 'UTM Campaign', 'UTM Content', 'UTM Term', 'Submitted', ...detailKeys];
    const escape = (s: string) => '"' + s.replace(/"/g, '""') + '"';
    const lines = [headers.map(escape).join(',')];
    for (const r of filtered) {
      const base = [r.source, r.name, r.email, r.company, r.utmSource || '', r.utmMedium || '', r.utmCampaign || '', r.utmContent || '', r.utmTerm || '', r.createdAt];
      const details = detailKeys.map((k) => fmtVal(r.detail[k]));
      lines.push([...base, ...details].map((v) => escape(String(v ?? ''))).join(','));
    }
    const csv = lines.join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const burl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = burl;
    a.download = `humanaize-leads-${filter.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(burl);
  }

  async function logout() {
    await fetch('/api/admin/logout', { method: 'POST' });
    router.push('/admin/login');
    router.refresh();
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0e1a] via-[#0f1629] to-[#0a0e1a] px-4 py-10">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-white">Leads Dashboard</h1>
            <p className="text-gray-400 text-sm">All submissions with UTM attribution, most recent first.</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowBuilder((v) => !v)}
              className="rounded-lg border border-cyan-500/50 text-cyan-300 text-sm font-semibold px-4 py-2 hover:bg-cyan-500/10"
            >
              {showBuilder ? 'Hide' : 'UTM Link Builder'}
            </button>
            <button
              onClick={exportCsv}
              className="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-semibold px-4 py-2"
            >
              Export CSV
            </button>
            <button
              onClick={logout}
              className="rounded-lg border border-gray-600 text-gray-300 text-sm px-4 py-2 hover:bg-gray-800"
            >
              Log out
            </button>
          </div>
        </div>

        {showBuilder && <div className="mb-6"><UtmLinkBuilder /></div>}

        {/* Type filter tabs */}
        <div className="flex flex-wrap gap-2 mb-3">
          {SOURCES.map((s) => {
            if (s !== 'All' && !counts[s]) return null;
            return (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
                  filter === s
                    ? 'bg-cyan-500 text-white'
                    : 'bg-[#111827] text-gray-300 border border-gray-700 hover:border-cyan-500/50'
                }`}
              >
                {s} <span className="opacity-70">({counts[s] || 0})</span>
              </button>
            );
          })}
        </div>

        {/* UTM attribution filter */}
        {utmSources.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            <span className="text-gray-500 text-xs self-center mr-1">Attribution:</span>
            {['All', 'Direct', ...utmSources].map((s) => (
              <button
                key={s}
                onClick={() => setUtmFilter(s)}
                className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
                  utmFilter === s
                    ? 'bg-orange-500/90 text-white'
                    : 'bg-[#111827] text-gray-400 border border-gray-700 hover:border-orange-500/50'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        )}

        {/* Table */}
        <div className="overflow-x-auto rounded-xl border border-gray-700/60">
          <table className="w-full text-left text-sm">
            <thead className="bg-[#111827] text-gray-400">
              <tr>
                <th className="px-4 py-3 w-8"></th>
                <th className="px-4 py-3">Type</th>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Company</th>
                <th className="px-4 py-3">Attribution</th>
                <th className="px-4 py-3">Submitted</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-gray-500">
                    No leads yet.
                  </td>
                </tr>
              )}
              {filtered.map((r) => (
                <Fragment key={r.id}>
                  <tr
                    onClick={() => toggle(r.id)}
                    className="border-t border-gray-800 hover:bg-[#111827]/60 cursor-pointer"
                  >
                    <td className="px-4 py-3 text-cyan-400">{expanded[r.id] ? '\u2212' : '+'}</td>
                    <td className="px-4 py-3">
                      <span className="inline-block rounded-full bg-cyan-500/15 text-cyan-300 text-xs px-2 py-0.5">
                        {r.source}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-white">{r.name}</td>
                    <td className="px-4 py-3 text-gray-300">{r.email}</td>
                    <td className="px-4 py-3 text-gray-300">{r.company || '\u2014'}</td>
                    <td className="px-4 py-3">
                      {r.utmSource ? (
                        <span className="inline-block rounded-full bg-orange-500/15 text-orange-300 text-xs px-2 py-0.5">
                          {utmBadge(r)}
                        </span>
                      ) : (
                        <span className="text-gray-600 text-xs">Direct</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-gray-400 whitespace-nowrap">{fmtDate(r.createdAt)}</td>
                  </tr>
                  {expanded[r.id] && (
                    <tr className="border-t border-gray-800 bg-[#0a0e1a]">
                      <td colSpan={7} className="px-6 py-4">
                        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                          {/* UTM attribution details */}
                          {r.utmSource && (
                            <>
                              <div className="text-sm"><div className="text-orange-400/70">UTM Source</div><div className="text-gray-200">{r.utmSource}</div></div>
                              {r.utmMedium && <div className="text-sm"><div className="text-orange-400/70">UTM Medium</div><div className="text-gray-200">{r.utmMedium}</div></div>}
                              {r.utmCampaign && <div className="text-sm"><div className="text-orange-400/70">UTM Campaign</div><div className="text-gray-200">{r.utmCampaign}</div></div>}
                              {r.utmContent && <div className="text-sm"><div className="text-orange-400/70">UTM Content</div><div className="text-gray-200">{r.utmContent}</div></div>}
                              {r.utmTerm && <div className="text-sm"><div className="text-orange-400/70">UTM Term</div><div className="text-gray-200">{r.utmTerm}</div></div>}
                            </>
                          )}
                          {/* Regular detail fields */}
                          {Object.entries(r.detail).map(([k, v]) => (
                            <div key={k} className="text-sm">
                              <div className="text-gray-500">{k}</div>
                              <div className="text-gray-200 break-words">{fmtVal(v)}</div>
                            </div>
                          ))}
                        </div>
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
