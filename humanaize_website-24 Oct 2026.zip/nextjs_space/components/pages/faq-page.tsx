'use client';

import { useLanguage } from '@/lib/language-context';
import FaqSection from '@/components/sections/faq-section';

type Lang = 'en' | 'de' | 'ar';

const hero: Record<Lang, { eyebrow: string; title: string; subtitle: string }> = {
  en: {
    eyebrow: 'FAQ',
    title: 'Frequently asked questions',
    subtitle: 'Everything about how HumanAIze works — our model, our methodology, our pricing, and how we stay accountable for ROI across DACH and the UAE.'
  },
  de: {
    eyebrow: 'FAQ',
    title: 'Häufig gestellte Fragen',
    subtitle: 'Alles darüber, wie HumanAIze arbeitet — unser Modell, unsere Methodik, unsere Preise und wie wir in DACH und den VAE für ROI verantwortlich bleiben.'
  },
  ar: {
    eyebrow: 'الأسئلة الشائعة',
    title: 'الأسئلة الشائعة',
    subtitle: 'كل ما يتعلق بطريقة عمل HumanAIze — نموذجنا ومنهجيتنا وتسعيرنا وكيف نبقى مسؤولين عن العائد عبر DACH والإمارات.'
  }
};

export default function FaqPage() {
  const { language } = useLanguage();
  const lang = (['en', 'de', 'ar'].includes(language) ? language : 'en') as Lang;
  const isRTL = lang === 'ar';
  const t = hero[lang];

  return (
    <main className="bg-[#0B0F14] min-h-screen">
      <section className="pt-24 pb-6 px-4" dir={isRTL ? 'rtl' : 'ltr'}>
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-xs tracking-[2px] text-cyan-400 mb-3 uppercase">{t.eyebrow}</p>
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">{t.title}</h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">{t.subtitle}</p>
        </div>
      </section>
      <FaqSection grouped heading="" className="pt-6" />
    </main>
  );
}
