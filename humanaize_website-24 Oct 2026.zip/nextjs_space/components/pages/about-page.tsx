
'use client';

import { useLanguage } from '@/lib/language-context';
import { getPageContent } from '@/lib/content';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { CheckCircle2, Heart } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import FaqSection from '@/components/sections/faq-section';

const secondaryCta = {
  en: 'Read how we define ROI before we begin →',
  de: 'Lesen Sie, wie wir ROI definieren, bevor wir beginnen →',
  ar: 'اقرأ كيف نحدّد العائد على الاستثمار قبل أن نبدأ ←',
};

const manifestoContent = {
  en: {
    title: 'Founder Manifesto',
    paragraphs: [
      "I didn't found HumanAIze to chase technology or build a \"cool\" start-up.",
      "I built it knowing that most businesses don't fail because they lack ambition or tools—they fail because they sell before they solve, chase numbers instead of truth, and mistake motion for meaning.",
      "Over the years, I watched teams confuse speed with progress, tools with strategy, and automation with leadership.",
      "AI isn't failing because it's powerful. It's failing because people don't trust what they don't understand.",
      "HumanAIze was founded on a simple conviction: AI only creates value when humans trust it enough to rely on it, own it, and stay accountable for its outcomes.",
      "This is not about more technology. It's about better thinking, clearer decisions, and systems that serve people—not replace them.",
      "That's why HumanAIze exists."
    ],
    attribution: '- Bagmi Sahoo, Founder'
  },
  de: {
    title: 'Gründer-Manifest',
    paragraphs: [
      "Ich habe HumanAIze nicht gegründet, um Technologie zu jagen oder ein \"cooles\" Start-up aufzubauen.",
      "Ich habe es aufgebaut, weil ich weiß, dass die meisten Unternehmen nicht scheitern, weil ihnen Ehrgeiz oder Werkzeuge fehlen – sie scheitern, weil sie verkaufen, bevor sie Probleme lösen, Zahlen statt Wahrheit jagen und Bewegung mit Bedeutung verwechseln.",
      "Im Laufe der Jahre habe ich beobachtet, wie Teams Geschwindigkeit mit Fortschritt, Werkzeuge mit Strategie und Automatisierung mit Führung verwechselten.",
      "KI scheitert nicht, weil sie mächtig ist. Sie scheitert, weil Menschen dem nicht vertrauen, was sie nicht verstehen.",
      "HumanAIze wurde auf einer einfachen Überzeugung gegründet: KI schafft nur Wert, wenn Menschen ihr genug vertrauen, um sich auf sie zu verlassen, sie zu besitzen und für ihre Ergebnisse verantwortlich zu bleiben.",
      "Es geht nicht um mehr Technologie. Es geht um besseres Denken, klarere Entscheidungen und Systeme, die Menschen dienen – nicht ersetzen.",
      "Deshalb existiert HumanAIze."
    ],
    attribution: '- Bagmi Sahoo, Gründer'
  },
  ar: {
    title: 'بيان المؤسس',
    paragraphs: [
      "لم أؤسس HumanAIze لمطاردة التكنولوجيا أو بناء شركة ناشئة \"رائعة\".",
      "بنيتها وأنا أعلم أن معظم الشركات لا تفشل لأنها تفتقر إلى الطموح أو الأدوات - إنها تفشل لأنها تبيع قبل أن تحل، وتطارد الأرقام بدلاً من الحقيقة، وتخلط بين الحركة والمعنى.",
      "على مر السنين، شاهدت الفرق تخلط بين السرعة والتقدم، والأدوات والاستراتيجية، والأتمتة والقيادة.",
      "الذكاء الاصطناعي لا يفشل لأنه قوي. إنه يفشل لأن الناس لا يثقون بما لا يفهمونه.",
      "تأسست HumanAIze على قناعة بسيطة: الذكاء الاصطناعي يخلق قيمة فقط عندما يثق به البشر بما يكفي للاعتماد عليه وامتلاكه والبقاء مسؤولين عن نتائجه.",
      "الأمر لا يتعلق بمزيد من التكنولوجيا. إنه يتعلق بتفكير أفضل وقرارات أوضح وأنظمة تخدم الناس - لا تستبدلهم.",
      "لهذا السبب توجد HumanAIze."
    ],
    attribution: '- باجمي ساهو، المؤسس'
  }
};

export default function AboutPage() {
  const { language } = useLanguage();
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const [manifestoRef, manifestoInView] = useInView({ triggerOnce: true, threshold: 0.1 });

  const pageData: any = getPageContent('about', language) || getPageContent('about', 'en');
  const manifesto = manifestoContent[language as keyof typeof manifestoContent] || manifestoContent.en;

  const sections = pageData?.sections || [];
  const aboutIntro = sections?.find?.((s: any) => s?.section_id === 'about_intro');
  const brandPillars = sections?.find?.((s: any) => s?.section_id === 'brand_pillars');
  const founderStory = sections?.find?.((s: any) => s?.section_id === 'founder_story');

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-blue-50 to-orange-50">
      {/* About Intro */}
      {aboutIntro && (
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <motion.div
              ref={ref}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7 }}
              className="text-center max-w-4xl mx-auto"
            >
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                {aboutIntro?.content?.[language]?.h1 || aboutIntro?.content?.en?.h1}
              </h1>
              <p className="text-lg text-gray-600 leading-relaxed whitespace-pre-line">
                {aboutIntro?.content?.[language]?.body || aboutIntro?.content?.en?.body}
              </p>
            </motion.div>
          </div>
        </section>
      )}

      {/* Brand Pillars */}
      {brandPillars && (
        <section className="py-20 bg-white">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-12"
            >
              {brandPillars?.content?.[language]?.h2 || brandPillars?.content?.en?.h2}
            </motion.h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {(brandPillars?.content?.[language]?.pillars || brandPillars?.content?.en?.pillars)?.map?.((pillar: any, index: number) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-gradient-to-br from-blue-50 to-orange-50 rounded-2xl p-8 shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start gap-4">
                    <CheckCircle2 className="text-blue-600 flex-shrink-0 mt-1" size={24} />
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">
                        {pillar?.title}
                      </h3>
                      <p className="text-gray-700 leading-relaxed">
                        {pillar?.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Founder Story */}
      {founderStory && (
        <section id="founder" className="py-20 bg-gradient-to-br from-blue-50 to-white">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Left - Profile Picture */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.7 }}
                className="relative"
              >
                <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl border-4 border-cyan-500/20">
                  <Image
                    src="/founder-profile.jpg"
                    alt="Bagmi Sahoo - Founder of HumanAIze"
                    width={600}
                    height={600}
                    className="object-cover w-full h-full"
                    priority
                  />
                </div>
              </motion.div>

              {/* Right - Content */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="space-y-6"
              >
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                  {founderStory?.content?.[language]?.h2 || founderStory?.content?.en?.h2}
                </h2>
                <p className="text-lg text-gray-600 leading-relaxed whitespace-pre-line">
                  {founderStory?.content?.[language]?.body || founderStory?.content?.en?.body}
                </p>
              </motion.div>
            </div>
          </div>
        </section>
      )}

      {/* Founder Manifesto */}
      <section className="py-20 bg-gradient-to-b from-[#0f172a] to-[#1e293b]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            ref={manifestoRef}
            initial={{ opacity: 0, y: 30 }}
            animate={manifestoInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            <div className="bg-[#1a2332] rounded-3xl p-8 md:p-12 shadow-2xl border border-gray-700/50">
              {/* Manifesto Header */}
              <div className="flex items-center justify-center gap-3 mb-8">
                <div className="p-2 bg-gradient-to-br from-purple-500/20 to-cyan-500/20 rounded-lg">
                  <Heart className="w-6 h-6 text-purple-400" />
                </div>
                <h3 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-purple-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent">
                  {manifesto.title}
                </h3>
              </div>

              {/* Manifesto Content */}
              <div className="space-y-5 max-w-4xl mx-auto">
                {manifesto.paragraphs.map((paragraph, index) => (
                  <p 
                    key={index} 
                    className="text-gray-300 leading-relaxed text-base md:text-lg"
                  >
                    {paragraph}
                  </p>
                ))}
              </div>

              {/* Attribution */}
              <div className="mt-8 pt-6 border-t border-gray-700/50 text-center">
                <p className="text-cyan-400 font-semibold text-lg">
                  {manifesto.attribution}
                </p>
              </div>
            </div>
          </motion.div>

          {/* Secondary CTA — Read how we define ROI */}
          <div className="mt-12 text-center">
            <Link
              href="/how-we-work"
              className="inline-flex items-center gap-2 text-lg font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
              dir={language === 'ar' ? 'rtl' : 'ltr'}
            >
              {secondaryCta[language as keyof typeof secondaryCta] || secondaryCta.en}
            </Link>
          </div>
        </div>
      </section>
      <FaqSection ids={['what-is-humanaize', 'how-different', 'who-works-with', 'who-leads', 'where-based', 'is-vendor-neutral']} />
    </div>
  );
}
