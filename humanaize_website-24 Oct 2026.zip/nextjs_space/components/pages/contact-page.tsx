
'use client';

import { useState } from 'react';
import { useLanguage } from '@/lib/language-context';
import { getStoredUtm } from '@/hooks/use-utm';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Mail, Phone, MapPin, Send, Calendar } from 'lucide-react';
import { toast } from 'sonner';

// Google Calendar appointment URL
const CALENDAR_URL = 'https://calendar.google.com/calendar/u/0/r/appointment';

export default function ContactPage() {
  const { language } = useLanguage();
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const [calendarRef, calendarInView] = useInView({ triggerOnce: true, threshold: 0.1 });
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    subject: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);



  const texts = {
    en: {
      title: 'Get in Touch',
      subtitle: 'Ready to orchestrate AI across your organisation for measurable ROI. Let\'s start a conversation.',
      nameLabel: 'Name',
      emailLabel: 'Email',
      companyLabel: 'Company',
      phoneLabel: 'Phone',
      subjectLabel: 'Subject',
      messageLabel: 'Message',
      submitButton: 'Send Message',
      contactInfo: 'Contact Information',
      successMessage: 'Thank you! Your message has been sent successfully. We\'ll get back to you soon.',
      errorMessage: 'Failed to send message. Please try again.',
      scheduleTitle: 'Book your AI Readiness Diagnostic',
      scheduleSubtitle: 'Schedule a 30-minute consultation to discuss how we can help transform your business with AI.',
      scheduleButton: 'Open Calendar & Book Now',
    },
    de: {
      title: 'Kontakt aufnehmen',
      subtitle: 'Bereit, KI in Ihrer Organisation für messbaren ROI zu orchestrieren. Lassen Sie uns ins Gespräch kommen.',
      nameLabel: 'Name',
      emailLabel: 'E-Mail',
      companyLabel: 'Unternehmen',
      phoneLabel: 'Telefon',
      subjectLabel: 'Betreff',
      messageLabel: 'Nachricht',
      submitButton: 'Nachricht senden',
      contactInfo: 'Kontaktinformationen',
      successMessage: 'Vielen Dank! Ihre Nachricht wurde erfolgreich gesendet. Wir melden uns bald bei Ihnen.',
      errorMessage: 'Nachricht konnte nicht gesendet werden. Bitte versuchen Sie es erneut.',
      scheduleTitle: 'KI-Readiness-Diagnose buchen',
      scheduleSubtitle: 'Vereinbaren Sie ein 30-minütiges Beratungsgespräch, um zu besprechen, wie wir Ihr Unternehmen mit KI transformieren können.',
      scheduleButton: 'Kalender öffnen & jetzt buchen',
    },
    ar: {
      title: 'تواصل معنا',
      subtitle: 'جاهز لتنسيق الذكاء الاصطناعي في DACH أو الإمارات؟ لنبدأ المحادثة.',
      nameLabel: 'الاسم',
      emailLabel: 'البريد الإلكتروني',
      companyLabel: 'الشركة',
      phoneLabel: 'الهاتف',
      subjectLabel: 'الموضوع',
      messageLabel: 'الرسالة',
      submitButton: 'إرسال الرسالة',
      contactInfo: 'معلومات الاتصال',
      successMessage: 'شكراً لك! تم إرسال رسالتك بنجاح. سنتواصل معك قريباً.',
      errorMessage: 'فشل إرسال الرسالة. الرجاء المحاولة مرة أخرى.',
      scheduleTitle: 'احجز تشخيص جاهزية الذكاء الاصطناعي',
      scheduleSubtitle: 'حدد موعداً لاستشارة مدتها 30 دقيقة لمناقشة كيف يمكننا المساعدة في تحويل أعمالك باستخدام الذكاء الاصطناعي.',
      scheduleButton: 'افتح التقويم واحجز الآن',
    },
  };

  const t = texts[language as keyof typeof texts] || texts.en;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData?.name || !formData?.email || !formData?.message) {
      toast.error(t.errorMessage);
      return;
    }

    setIsSubmitting(true);

    try {
      // Save to database
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, formType: 'contact', ...getStoredUtm() }),
      });

      if (response?.ok) {
        toast.success(t.successMessage);
        
        // Reset form
        setFormData({
          name: '',
          email: '',
          company: '',
          phone: '',
          subject: '',
          message: '',
        });
      } else {
        toast.error(t.errorMessage);
      }
    } catch (error) {
      console.error('Contact form error:', error);
      toast.error(t.errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            {t.title}
          </h1>
          <p className="text-lg text-gray-600">
            {t.subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card className="shadow-xl">
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t.nameLabel} *
                      </label>
                      <Input
                        type="text"
                        value={formData?.name}
                        onChange={(e) => setFormData({ ...formData, name: e?.target?.value || '' })}
                        required
                        className="h-12"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t.emailLabel} *
                      </label>
                      <Input
                        type="email"
                        value={formData?.email}
                        onChange={(e) => setFormData({ ...formData, email: e?.target?.value || '' })}
                        required
                        className="h-12"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t.companyLabel}
                      </label>
                      <Input
                        type="text"
                        value={formData?.company}
                        onChange={(e) => setFormData({ ...formData, company: e?.target?.value || '' })}
                        className="h-12"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t.phoneLabel}
                      </label>
                      <Input
                        type="tel"
                        value={formData?.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e?.target?.value || '' })}
                        className="h-12"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t.subjectLabel}
                    </label>
                    <Input
                      type="text"
                      value={formData?.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e?.target?.value || '' })}
                      className="h-12"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t.messageLabel} *
                    </label>
                    <Textarea
                      value={formData?.message}
                      onChange={(e) => setFormData({ ...formData, message: e?.target?.value || '' })}
                      required
                      rows={6}
                      className="resize-none"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full h-12 bg-blue-600 hover:bg-blue-700"
                  >
                    {isSubmitting ? (
                      language === 'de' ? 'Wird gesendet...' : language === 'ar' ? 'جاري الإرسال...' : 'Sending...'
                    ) : (
                      <>
                        {t.submitButton}
                        <Send className="ml-2" size={18} />
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.4 }}
          >
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle>{t.contactInfo}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <Mail className="text-blue-600" size={24} />
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">Email</div>
                    <a href="mailto:connect@human-aize.com" className="text-gray-600 hover:text-blue-600">
                      connect@human-aize.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-orange-100 p-3 rounded-lg">
                    <Phone className="text-orange-600" size={24} />
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">Phone</div>
                    <div className="space-y-1">
                      <div>
                        <a href="tel:+97145581150" className="text-gray-600 hover:text-blue-600">
                          Tel: +971 4558 1150
                        </a>
                      </div>
                      <div>
                        <a href="tel:+971559658808" className="text-gray-600 hover:text-blue-600">
                          Mob: +971 55965 8808
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <MapPin className="text-blue-600" size={24} />
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">Address</div>
                    <p className="text-gray-600">
                      BC-888856, Amber Gem Tower, UAE
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Calendar Section */}
        <motion.div
          ref={calendarRef}
          initial={{ opacity: 0, y: 30 }}
          animate={calendarInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-16"
        >
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
                <Calendar className="text-white" size={24} />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              {t.scheduleTitle}
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              {t.scheduleSubtitle}
            </p>
          </div>
          
          <Card className="shadow-xl">
            <CardContent className="p-8 text-center">
              <a 
                href={CALENDAR_URL}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white px-8 py-6 text-lg font-semibold shadow-lg hover:shadow-xl transition-all">
                  <Calendar className="mr-2" size={24} />
                  {t.scheduleButton}
                </Button>
              </a>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
