'use client';

import { useLanguage } from '@/lib/language-context';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Search, Zap, Cog, Users, CheckCircle2, ArrowRight, Target, Shield, TrendingUp } from 'lucide-react';
import ToolAccessButton from '@/components/sections/tool-access-button';
import FaqSection from '@/components/sections/faq-section';

const servicesContent = {
  en: {
    heroTitle: 'We don\'t deliver strategies. We deliver outcomes.',
    heroSubtitle: 'A 4-stage Operating System \u2014 plus an optional Blindspot entry. Value measured against a signed baseline, never promised.',
    introPara: 'The HumanAIze Operating System takes you from strategy to scaled AI ROI \u2014 value measured, never promised. The client path is simple: ASSESS locks a signed baseline, then 90-day Sprints prove value. ACTIVATE and EMBED are engaged only when you are ready to scale. Blindspot is a separate pre-methodology offer for organisations with no AI investment yet.',
    blindspot: {
      label: 'Pre-methodology offer \u00b7 separate',
      name: 'BLINDSPOT',
      tagline: 'Opportunity Case Builder',
      meta: 'Standalone engagement \u00b7 3\u20135 days \u00b7 Fixed fee \u00b7 Optional, before ASSESS',
      desc: 'A separate pre-methodology offer \u2014 not one of the four Operating System stages. For organisations with no AI investment yet, we scan for the opportunity and build the internal business case leadership can sign off, before any commitment to a diagnostic or delivery programme.',
      items: [
        'AI opportunity scan \u2014 no prior AI investment needed',
        'Budget-ready business case built for leadership sign-off',
        '2\u20133 quick-win use cases identified and sized',
        'Internal buy-in framework the client presents upward'
      ],
      bestFor: 'Who it\'s for: organisations with no AI investment yet, who need a credible internal case to get budget approved \u2014 before any commitment to a diagnostic or delivery programme.'
    },
    progressLabels: ['Baseline', 'Scale design', 'Sprints', 'Sustain'],
    pillars: [
      {
        id: 'assess',
        number: '01',
        name: 'ASSESS',
        tagline: 'The 90-Day ROI Model',
        meta: '4\u20138 weeks \u00b7 Fixed fee \u00b7 Entry point, scoped to org size',
        objective: 'Before a single euro or dirham is committed, you will know exactly which AI investments are worth making \u2014 and which ones aren\'t. Most organisations skip this step. That is why most AI investments underperform. The entry point to the Operating System. Before capital is committed, ASSESS locks a signed metric baseline and a 90-Day Value Hypothesis with metric uplift targets \u2014 so every downstream sprint is measured, never promised.',
        entryPoint: 'Start here \u2014 this is the entry point. The client path is simply ASSESS \u2192 Sprint.',
        startHere: 'Start here if you have budget authority but no validated business case yet.',
        capabilities: [
          'AI maturity audit across 5 criteria',
          'Top-3 use cases prioritised & scored',
          'Each use case is classified as Automate (deterministic, repetitive work), Augment (human judgment, AI-accelerated), or Agency (autonomous, governed action) — the most common point of failure in enterprise AI budgets is picking the wrong bucket before picking the wrong vendor.',
          'Metric baselines locked & signed off',
          '90-Day Value Hypothesis with metric uplift targets'
        ],
        benchmarks: [
          'Signed metric baseline \u2014 the measurement contract',
          'Top-3 use cases sized for the first sprint',
          'Fixed fee, scoped to organisation size'
        ],
        outputs: 'Maturity Scorecard \u00b7 Prioritised Use-Case Map \u00b7 Locked Metric Baseline \u00b7 90-Day Value Hypothesis',
        valueHypothesis: {
          title: 'The HumanAIze Value Hypothesis',
          subtitle: 'Every ASSESS ends with a written, signed Value Hypothesis \u2014 the six-part case leadership approves before a single sprint begins.',
          items: [
            { label: 'Current State', text: 'Where the business stands today \u2014 baseline metrics and current process performance, captured and signed off.' },
            { label: 'Pain', text: 'The specific operational and financial pain the current state creates, named and owned by the sponsor.' },
            { label: 'Cost of Inaction', text: 'What standing still costs \u2014 quantified in time, money and risk over the 90-day window.' },
            { label: 'Desired State', text: 'The measurable end state the metric uplift targets \u2014 an explicit, falsifiable goal.' },
            { label: 'ROI', text: 'Projected metric uplift set against the fixed engagement fee \u2014 the return case leadership signs off.' },
            { label: 'Solution', text: 'The prioritised use case and the 90-day sprint that will move the number.' },
          ]
        },
                color: 'blue'
      },
      {
        id: 'activate',
        number: '02',
        name: 'ACTIVATE',
        tagline: 'Scale Accelerator',
        optional: true,
        meta: 'Optional \u00b7 As scoped \u00b7 Monthly retainer \u00b7 Recommended when scaling beyond first sprints',
        objective: 'Optional. Once early sprints prove value, ACTIVATE designs the roadmap, operating model and governance to scale AI across the organisation. It sits outside the required path \u2014 you take it only when scaling beyond the first sprints.',
        entryPoint: 'Recommended when you are scaling beyond your first sprints \u2014 not a required step.',
        startHere: 'Start here if you already have a validated business case and need the governance and architecture to move to delivery.',
        capabilities: [
          '3-year AI roadmap design',
          'Operating model alignment & change management',
          'Regulatory compliance mapping (EU AI Act / UAE, DIFC-10, NIST)'
        ],
        benchmarks: [
          'Scale roadmap tied to proven sprint wins',
          'Governance aligned to EU AI Act, UAE, DIFC-10 & NIST',
          'Optional \u2014 engaged as scoped, on retainer'
        ],
        outputs: '3-Year AI Roadmap \u00b7 Operating Model \u00b7 Compliance Map \u00b7 Change Plan',
        color: 'cyan'
      },
      {
        id: 'implement',
        number: '03',
        name: 'IMPLEMENT',
        tagline: '90-Day ROI Sprints',
        meta: '90 days per sprint \u00b7 + 10\u201315% Metric success fee',
        objective: 'Priority use cases built and deployed in 90-day sprints, measured against the locked baseline. Every sprint carries an Activation Gate \u2014 sponsor alignment, baseline lock and governance \u2014 so value is proven, iterated, or killed inside 90 days.',
        entryPoint: 'The core of the Operating System \u2014 the client path runs straight from ASSESS into the first sprint.',
        startHere: 'Start here if strategy and governance are already in place and you\'re ready to build.',
        capabilities: [
          'Build & deploy priority use cases',
          'Baseline-locked measurement \u2014 no unfalsifiable claims',
          'Agentic AI governed by TARA-A; vendor-native governance elsewhere',
          'Named-owner accountability enforced at the point of action, not reconstructed afterward in an incident review.',
          'Activation Gate: sponsor alignment, baseline lock & governance'
        ],
        benchmarks: [
          'Use cases live in production within the sprint',
          'Day-90 gate: scale, iterate, or kill',
          'Paid on metric uplift \u2014 a 10\u201315% success fee, not on promises'
        ],
        outputs: 'Production Use Cases \u00b7 Baseline-Locked Metric Evidence \u00b7 Day-90 Scale Decision',
        color: 'slate'
      },
      {
        id: 'embed',
        number: '04',
        name: 'EMBED',
        tagline: 'Sustain & Scale',
        meta: 'Ongoing \u00b7 Monthly retainer',
        objective: 'The goal of every HumanAIze engagement is to make ourselves unnecessary. We build the internal capability, governance structures, and measurement systems your organisation needs to sustain AI value without external dependency. When we leave, you own everything. Your team runs it. You don\'t need us to maintain it. That is not a feature. It is the only honest definition of transformation.',
        entryPoint: 'Start here once you have proven winners ready to scale across the organisation.',
        startHere: 'Start here if you have at least one proven pilot and need it to scale organisation-wide.',
        capabilities: [
          'Scale proven winners org-wide',
          'AI literacy & capability building (CAIO+ to all levels)',
          'TransformationOffice-as-a-Service',
          'AIaaS retainers + packaged training'
        ],
        benchmarks: [
          'Proven winners scaled across the organisation',
          'Capability transferred \u2014 your team runs it',
          'Ongoing AIaaS retainer + packaged training'
        ],
        outputs: 'Org-Wide Rollout \u00b7 AI Literacy Programme \u00b7 Transformation Office \u00b7 AIaaS Retainer',
        color: 'silver'
      }
    ],
    kpiBand: {
      title: 'The Operating System by the Numbers',
      metrics: [
        { value: '3\u20135 Days', label: 'Blindspot business case' },
        { value: '6\u201312 Weeks', label: 'ASSESS baseline lock' },
        { value: '90 Days', label: 'per ROI sprint' },
        { value: 'Day 90', label: 'Scale, iterate, or kill' },
        { value: '10\u201315%', label: 'Metric success fee' }
      ]
    },
    vsBig4: {
      title: 'HumanAIze vs. the Big 4',
      colBig4: 'Big4 / McKinsey',
      colUs: 'HumanAIze',
      rows: [
        { criteria: 'Fee model', big4: 'Billed by hours and team size', us: 'Fixed-fee entry + 10\u201315% success fee tied to metric uplift' },
        { criteria: 'Execution', big4: 'Strategy delivered, execution handed off', us: 'Strategy and execution \u2014 we stay until the number moves' },
        { criteria: 'Measurement', big4: 'Outcomes projected in the pitch', us: 'Value measured against a signed baseline \u2014 no unfalsifiable claims' },
        { criteria: 'Exit model', big4: 'Dependency deepens with every engagement', us: 'Capability transfer \u2014 your team owns it when we leave' },
        { criteria: 'Team', big4: 'Graduate analysts on your account', us: 'Curated senior experts, no juniors' },
        { criteria: 'Governance', big4: 'AI as a technology implementation', us: 'TARA-A for agentic AI; vendor-native governance elsewhere' }
      ]
    },
    commitment: {
      title: 'Our Accountability Standard',
      items: [
        'Signed metric baseline before any sprint begins',
        'Written 90-Day Value Hypothesis',
        'Activation Gate on every sprint: sponsor, baseline & governance',
        'Day-90 gate \u2014 scale, iterate, or kill',
        'Paid on metric uplift, not on promises',
        'Vendor-neutral recommendations — no preferred platforms, no referral fees',
        'Cross-border regulatory alignment (EU AI Act / UAE, DIFC-10, NIST)'
      ],
      footer: 'Value proven \u2014 or killed \u2014 in 90 days. We are paid on uplift, not on promises.'
    },
    labels: {
      objective: 'The Model',
      capabilities: 'Core Capabilities',
      benchmarks: 'How Value Is Proven',
      outputs: 'Output Snapshot',
      optional: 'Optional',
      blindspotCalcHeading: 'Blindspot Calculator',
      blindspotCalcSub: 'Estimate the cost of doing nothing. See where AI blindspots are quietly draining value — in under two minutes.',
      roiCalcHeading: 'AI ROI Calculator',
      roiCalcSub: 'Model the potential return of your first 90-day ROI Sprint against verified industry benchmarks.'
    }
  },
  de: {
    heroTitle: 'Wir liefern keine Strategien. Wir liefern Ergebnisse.',
    heroSubtitle: 'Ein 4-stufiges Operating System \u2014 plus optionalem Blindspot-Einstieg. Wert gemessen an einer unterschriebenen Baseline, nie versprochen.',
    introPara: 'Das HumanAIze Operating System f\u00fchrt Sie von der Strategie zum skalierten AI-ROI \u2014 Wert gemessen, nie versprochen. Der Kundenpfad ist einfach: ASSESS fixiert eine unterschriebene Baseline, dann beweisen 90-Tage-Sprints den Wert. ACTIVATE und EMBED werden nur bei Skalierung eingesetzt. Blindspot ist ein separates Pre-Methodology-Angebot f\u00fcr Organisationen ohne bisherige KI-Investition.',
    blindspot: {
      label: 'Pre-Methodology-Angebot \u00b7 separat',
      name: 'BLINDSPOT',
      tagline: 'Opportunity Case Builder',
      meta: 'Eigenst\u00e4ndige Leistung \u00b7 3\u20135 Tage \u00b7 Festpreis \u00b7 Optional, vor ASSESS',
      desc: 'Ein separates Pre-Methodology-Angebot \u2014 keine der vier Operating-System-Stufen. F\u00fcr Organisationen ohne bisherige KI-Investition suchen wir die Chance und erstellen den internen Business Case, den die F\u00fchrung freigeben kann \u2014 vor jeder Festlegung auf eine Diagnose oder ein Umsetzungsprogramm.',
      items: [
        'KI-Chancen-Scan \u2014 keine vorherige KI-Investition n\u00f6tig',
        'Budgetreifer Business Case f\u00fcr die Freigabe durch die F\u00fchrung',
        '2\u20133 Quick-Win-Anwendungsf\u00e4lle identifiziert und dimensioniert',
        'Internes Buy-in-Framework, das der Kunde nach oben pr\u00e4sentiert'
      ],
      bestFor: 'F\u00fcr wen: Organisationen ohne bisherige KI-Investition, die einen glaubw\u00fcrdigen internen Case ben\u00f6tigen, um Budget freizugeben \u2014 vor jeder Festlegung auf eine Diagnose oder ein Umsetzungsprogramm.'
    },
    progressLabels: ['Baseline', 'Skalierungsdesign', 'Sprints', 'Nachhaltig'],
    pillars: [
      {
        id: 'assess',
        number: '01',
        name: 'BEWERTEN',
        tagline: 'Das 90-Tage-ROI-Modell',
        meta: '4\u20138 Wochen \u00b7 Festpreis \u00b7 Einstiegspunkt, skaliert nach Organisationsgr\u00f6\u00dfe',
        objective: 'Bevor ein einziger Euro oder Dirham gebunden wird, wissen Sie genau, welche KI-Investitionen sich lohnen \u2014 und welche nicht. Die meisten Organisationen \u00fcberspringen diesen Schritt. Deshalb bleiben die meisten KI-Investitionen hinter den Erwartungen zur\u00fcck. Der Einstiegspunkt in das Operating System. Bevor Kapital gebunden wird, fixiert ASSESS eine unterschriebene Metrik-Baseline und eine 90-Tage-Wert-Hypothese mit Uplift-Zielwerten \u2014 damit jeder folgende Sprint gemessen und nicht versprochen wird.',
        entryPoint: 'Beginnen Sie hier \u2014 das ist der Einstieg. Der Kundenpfad ist schlicht: ASSESS \u2192 Sprint.',
        startHere: 'Beginnen Sie hier, wenn Sie Budgethoheit haben, aber noch keinen validierten Business Case.',
        capabilities: [
          'KI-Reifegrad-Audit \u00fcber 5 Kriterien',
          'Top-3-Use-Cases priorisiert & bewertet',
          'Jeder Use Case wird klassifiziert als Automate (deterministische, repetitive Arbeit), Augment (menschliches Urteil, KI-beschleunigt) oder Agency (autonomes, gesteuertes Handeln) — der häufigste Fehlerpunkt bei KI-Budgets im Unternehmen ist die Wahl des falschen Buckets vor der Wahl des falschen Anbieters.',
          'Metrik-Baselines fixiert & freigegeben',
          '90-Tage-Wert-Hypothese mit Uplift-Zielwerten'
        ],
        benchmarks: [
          'Unterschriebene Metrik-Baseline \u2014 der Messvertrag',
          'Top-3-Use-Cases f\u00fcr den ersten Sprint dimensioniert',
          'Festpreis, skaliert nach Organisationsgr\u00f6\u00dfe'
        ],
        outputs: 'Reifegrad-Scorecard \u00b7 Priorisierte Use-Case-Map \u00b7 Fixierte Metrik-Baseline \u00b7 90-Tage-Wert-Hypothese',
        valueHypothesis: {
          title: 'Die HumanAIze Wert-Hypothese',
          subtitle: 'Jedes ASSESS endet mit einer schriftlichen, unterschriebenen Wert-Hypothese \u2014 dem sechsteiligen Case, den die F\u00fchrung freigibt, bevor ein einziger Sprint beginnt.',
          items: [
            { label: 'Ist-Zustand', text: 'Wo das Unternehmen heute steht \u2014 Baseline-Metriken und aktuelle Prozessleistung, erfasst und freigegeben.' },
            { label: 'Schmerzpunkt', text: 'Der konkrete operative und finanzielle Schmerz, den der Ist-Zustand erzeugt \u2014 benannt und vom Sponsor verantwortet.' },
            { label: 'Kosten des Nichtstuns', text: 'Was Stillstand kostet \u2014 quantifiziert in Zeit, Geld und Risiko \u00fcber das 90-Tage-Fenster.' },
            { label: 'Soll-Zustand', text: 'Der messbare Zielzustand, den der Metrik-Uplift anstrebt \u2014 ein explizites, falsifizierbares Ziel.' },
            { label: 'ROI', text: 'Prognostizierter Metrik-Uplift gegen das Festhonorar \u2014 der Return-Case, den die F\u00fchrung freigibt.' },
            { label: 'L\u00f6sung', text: 'Der priorisierte Use-Case und der 90-Tage-Sprint, der die Zahl bewegt.' },
          ]
        },
                color: 'blue'
      },
      {
        id: 'activate',
        number: '02',
        name: 'AKTIVIEREN',
        tagline: 'Scale Accelerator',
        optional: true,
        meta: 'Optional \u00b7 Nach Scope \u00b7 Monatlicher Retainer \u00b7 Empfohlen beim Skalieren \u00fcber die ersten Sprints hinaus',
        objective: 'Optional. Sobald erste Sprints Wert nachweisen, gestaltet ACTIVATE Roadmap, Betriebsmodell und Governance, um KI organisationsweit zu skalieren. Es liegt au\u00dferhalb des erforderlichen Pfads \u2014 Sie w\u00e4hlen es nur beim Skalieren \u00fcber die ersten Sprints hinaus.',
        entryPoint: 'Empfohlen, wenn Sie \u00fcber Ihre ersten Sprints hinaus skalieren \u2014 kein Pflichtschritt.',
        startHere: 'Beginnen Sie hier, wenn Sie bereits einen validierten Business Case haben und die Governance und Architektur benötigen, um zur Umsetzung überzugehen.',
        capabilities: [
          '3-Jahres-KI-Roadmap-Design',
          'Operating-Model-Ausrichtung & Change Management',
          'Regulatorisches Compliance-Mapping (EU AI Act / UAE, DIFC-10, NIST)'
        ],
        benchmarks: [
          'Skalierungs-Roadmap an nachgewiesene Sprint-Erfolge gekoppelt',
          'Governance ausgerichtet an EU AI Act, UAE, DIFC-10 & NIST',
          'Optional \u2014 nach Scope, auf Retainer-Basis'
        ],
        outputs: '3-Jahres-KI-Roadmap \u00b7 Betriebsmodell \u00b7 Compliance-Map \u00b7 Change-Plan',
        color: 'cyan'
      },
      {
        id: 'implement',
        number: '03',
        name: 'IMPLEMENTIEREN',
        tagline: '90-Tage-ROI-Sprints',
        meta: '90 Tage pro Sprint \u00b7 + 10\u201315% Metrik-Erfolgshonorar',
        objective: 'Priorisierte Use-Cases werden in 90-Tage-Sprints gebaut und deployt, gemessen gegen die fixierte Baseline. Jeder Sprint tr\u00e4gt ein Activation Gate \u2014 Sponsor-Alignment, Baseline-Lock und Governance \u2014 damit Wert innerhalb von 90 Tagen bewiesen, iteriert oder gestoppt wird.',
        entryPoint: 'Der Kern des Operating Systems \u2014 der Kundenpfad f\u00fchrt direkt von ASSESS in den ersten Sprint.',
        startHere: 'Beginnen Sie hier, wenn Strategie und Governance bereits stehen und Sie bereit sind zu bauen.',
        capabilities: [
          'Priorisierte Use-Cases bauen & deployen',
          'Baseline-fixierte Messung \u2014 keine unfalsifizierbaren Behauptungen',
          'Agentic AI via TARA-A gesteuert; vendor-native Governance andernorts',
          'Verantwortung mit benanntem Owner — durchgesetzt am Punkt der Handlung, nicht nachträglich in einem Incident-Review rekonstruiert.',
          'Activation Gate: Sponsor-Alignment, Baseline-Lock & Governance'
        ],
        benchmarks: [
          'Use-Cases live in Produktion innerhalb des Sprints',
          'Day-90-Gate: skalieren, iterieren oder stoppen',
          'Verg\u00fctung auf Metrik-Uplift \u2014 10\u201315% Erfolgshonorar, nicht auf Versprechen'
        ],
        outputs: 'Produktive Use-Cases \u00b7 Baseline-fixierte Metrik-Evidenz \u00b7 Day-90-Skalierungsentscheidung',
        color: 'slate'
      },
      {
        id: 'embed',
        number: '04',
        name: 'VERANKERN',
        tagline: 'Sustain & Scale',
        meta: 'Laufend \u00b7 Monatlicher Retainer',
        objective: 'Das Ziel jeder HumanAIze-Zusammenarbeit ist es, uns selbst \u00fcberfl\u00fcssig zu machen. Wir bauen die interne F\u00e4higkeit, die Governance-Strukturen und die Messsysteme auf, die Ihre Organisation braucht, um KI-Wert ohne externe Abh\u00e4ngigkeit zu erhalten. Wenn wir gehen, besitzen Sie alles. Ihr Team betreibt es. Sie brauchen uns nicht, um es zu warten. Das ist kein Feature. Es ist die einzig ehrliche Definition von Transformation.',
        entryPoint: 'Beginnen Sie hier, sobald Sie bew\u00e4hrte Gewinner haben, die organisationsweit skaliert werden sollen.',
        startHere: 'Beginnen Sie hier, wenn Sie mindestens ein bewährtes Pilotprojekt haben und es organisationsweit skalieren möchten.',
        capabilities: [
          'Bew\u00e4hrte Gewinner organisationsweit skalieren',
          'KI-Kompetenz & Capability Building (CAIO+ bis auf alle Ebenen)',
          'TransformationOffice-as-a-Service',
          'AIaaS-Retainer + geb\u00fcndelte Trainings'
        ],
        benchmarks: [
          'Bew\u00e4hrte Gewinner organisationsweit skaliert',
          'Capability transferiert \u2014 Ihr Team betreibt es',
          'Laufender AIaaS-Retainer + geb\u00fcndelte Trainings'
        ],
        outputs: 'Organisationsweiter Rollout \u00b7 KI-Kompetenzprogramm \u00b7 Transformation Office \u00b7 AIaaS-Retainer',
        color: 'silver'
      }
    ],
    kpiBand: {
      title: 'Das Operating System in Zahlen',
      metrics: [
        { value: '3\u20135 Tage', label: 'Blindspot Business Case' },
        { value: '6\u201312 Wochen', label: 'ASSESS Baseline-Lock' },
        { value: '90 Tage', label: 'pro ROI-Sprint' },
        { value: 'Tag 90', label: 'Skalieren, iterieren, stoppen' },
        { value: '10\u201315%', label: 'Metrik-Erfolgshonorar' }
      ]
    },
    vsBig4: {
      title: 'HumanAIze vs. die Big 4',
      colBig4: 'Big4 / McKinsey',
      colUs: 'HumanAIze',
      rows: [
        { criteria: 'Honorarmodell', big4: 'Abrechnung nach Stunden und Teamgr\u00f6\u00dfe', us: 'Festpreis-Einstieg + 10\u201315% Erfolgshonorar auf Metrik-Uplift' },
        { criteria: 'Umsetzung', big4: 'Strategie geliefert, Umsetzung \u00fcbergeben', us: 'Strategie und Umsetzung \u2014 wir bleiben, bis sich die Zahl bewegt' },
        { criteria: 'Messung', big4: 'Ergebnisse im Pitch prognostiziert', us: 'Wert gemessen an unterschriebener Baseline \u2014 keine unfalsifizierbaren Behauptungen' },
        { criteria: 'Exit-Modell', big4: 'Abh\u00e4ngigkeit vertieft sich mit jedem Engagement', us: 'Capability-Transfer \u2014 Ihr Team besitzt es, wenn wir gehen' },
        { criteria: 'Team', big4: 'Graduate-Analysten in Ihrem Account', us: 'Kuratierte Senior-Experten, keine Junioren' },
        { criteria: 'Governance', big4: 'KI als Technologie-Implementierung', us: 'TARA-A f\u00fcr agentische KI; vendor-native Governance andernorts' }
      ]
    },
    commitment: {
      title: 'Unser Accountability-Standard',
      items: [
        'Unterschriebene Metrik-Baseline vor jedem Sprint',
        'Schriftliche 90-Tage-Wert-Hypothese',
        'Activation Gate bei jedem Sprint: Sponsor, Baseline & Governance',
        'Day-90-Gate \u2014 skalieren, iterieren oder stoppen',
        'Verg\u00fctung auf Metrik-Uplift, nicht auf Versprechen',
        'Herstellerneutrale Empfehlungen — keine bevorzugten Plattformen, keine Vermittlungsgebühren',
        'Grenz\u00fcberschreitende regulatorische Abstimmung (EU AI Act / UAE, DIFC-10, NIST)'
      ],
      footer: 'Wert bewiesen \u2014 oder gestoppt \u2014 in 90 Tagen. Wir werden auf Uplift verg\u00fctet, nicht auf Versprechen.'
    },
    labels: {
      objective: 'Das Modell',
      capabilities: 'Kernf\u00e4higkeiten',
      benchmarks: 'Wie Wert bewiesen wird',
      outputs: 'Output-Snapshot',
      optional: 'Optional',
      blindspotCalcHeading: 'Blindspot-Rechner',
      blindspotCalcSub: 'Berechnen Sie die Kosten des Nichtstuns. Sehen Sie in unter zwei Minuten, wo KI-Blindspots stillschweigend Wert vernichten.',
      roiCalcHeading: 'KI-ROI-Rechner',
      roiCalcSub: 'Modellieren Sie den potenziellen Return Ihres ersten 90-Tage-ROI-Sprints anhand verifizierter Branchen-Benchmarks.'
    }
  },
  ar: {
    heroTitle: '\u0646\u062d\u0646 \u0644\u0627 \u0646\u0642\u062f\u0651\u0645 \u0627\u0633\u062a\u0631\u0627\u062a\u064a\u062c\u064a\u0627\u062a. \u0646\u062d\u0646 \u0646\u062d\u0642\u0642 \u0627\u0644\u0646\u062a\u0627\u0626\u062c.',
    heroSubtitle: '\u0646\u0638\u0627\u0645 \u062a\u0634\u063a\u064a\u0644 \u0645\u0646 4 \u0645\u0631\u0627\u062d\u0644 \u2014 \u0628\u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0625\u0644\u0649 \u0645\u062f\u062e\u0644 Blindspot \u0627\u0644\u0627\u062e\u062a\u064a\u0627\u0631\u064a. \u0642\u064a\u0645\u0629 \u062a\u064f\u0642\u0627\u0633 \u0645\u0642\u0627\u0628\u0644 \u062e\u0637 \u0623\u0633\u0627\u0633 \u0645\u0648\u0642\u0651\u0639\u060c \u0644\u0627 \u064a\u064f\u0648\u0639\u062f \u0628\u0647\u0627.',
    introPara: '\u064a\u0623\u062e\u0630\u0643 \u0646\u0638\u0627\u0645 \u062a\u0634\u063a\u064a\u0644 HumanAIze \u0645\u0646 \u0627\u0644\u0627\u0633\u062a\u0631\u0627\u062a\u064a\u062c\u064a\u0629 \u0625\u0644\u0649 \u0639\u0627\u0626\u062f \u0627\u0633\u062a\u062b\u0645\u0627\u0631 \u0645\u0648\u0633\u0651\u0639 \u2014 \u0642\u064a\u0645\u0629 \u062a\u064f\u0642\u0627\u0633 \u0648\u0644\u0627 \u064a\u064f\u0648\u0639\u062f \u0628\u0647\u0627. \u0645\u0633\u0627\u0631 \u0627\u0644\u0639\u0645\u064a\u0644 \u0628\u0633\u064a\u0637: \u064a\u062b\u0628\u0651\u062a ASSESS \u062e\u0637 \u0623\u0633\u0627\u0633 \u0645\u0648\u0642\u0651\u0639\u060c \u062b\u0645 \u062a\u064f\u062b\u0628\u062a \u0633\u0628\u0627\u0642\u0627\u062a \u0627\u0644\u0640 90 \u064a\u0648\u0645\u064b\u0627 \u0627\u0644\u0642\u064a\u0645\u0629. \u064a\u064f\u0633\u062a\u062e\u062f\u0645 ACTIVATE \u0648EMBED \u0641\u0642\u0637 \u0639\u0646\u062f \u0627\u0644\u062a\u0648\u0633\u0639. \u0648Blindspot \u0639\u0631\u0636 \u0645\u0646\u0641\u0635\u0644 \u0633\u0627\u0628\u0642 \u0644\u0644\u0645\u0646\u0647\u062c\u064a\u0629 \u0644\u0644\u0645\u0624\u0633\u0633\u0627\u062a \u0627\u0644\u062a\u064a \u0644\u064a\u0633 \u0644\u062f\u064a\u0647\u0627 \u0627\u0633\u062a\u062b\u0645\u0627\u0631 \u0641\u064a \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0628\u0639\u062f.',
    blindspot: {
      label: '\u0639\u0631\u0636 \u0633\u0627\u0628\u0642 \u0644\u0644\u0645\u0646\u0647\u062c\u064a\u0629 \u00b7 \u0645\u0646\u0641\u0635\u0644',
      name: 'BLINDSPOT',
      tagline: '\u0623\u062f\u0627\u0629 \u0628\u0646\u0627\u0621 \u062d\u0627\u0644\u0629 \u0627\u0644\u0641\u0631\u0635',
      meta: '\u0627\u0631\u062a\u0628\u0627\u0637 \u0645\u0633\u062a\u0642\u0644 \u00b7 3\u20135 \u0623\u064a\u0627\u0645 \u00b7 \u0633\u0639\u0631 \u062b\u0627\u0628\u062a \u00b7 \u0627\u062e\u062a\u064a\u0627\u0631\u064a\u060c \u0642\u0628\u0644 ASSESS',
      desc: '\u0639\u0631\u0636 \u0645\u0646\u0641\u0635\u0644 \u0633\u0627\u0628\u0642 \u0644\u0644\u0645\u0646\u0647\u062c\u064a\u0629 \u2014 \u0644\u064a\u0633 \u0648\u0627\u062d\u062f\u064b\u0627 \u0645\u0646 \u0645\u0631\u0627\u062d\u0644 \u0646\u0638\u0627\u0645 \u0627\u0644\u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0623\u0631\u0628\u0639. \u0644\u0644\u0645\u0624\u0633\u0633\u0627\u062a \u0627\u0644\u062a\u064a \u0644\u064a\u0633 \u0644\u062f\u064a\u0647\u0627 \u0627\u0633\u062a\u062b\u0645\u0627\u0631 \u0628\u0639\u062f\u060c \u0646\u0628\u062d\u062b \u0639\u0646 \u0627\u0644\u0641\u0631\u0635\u0629 \u0648\u0646\u0628\u0646\u064a \u062d\u0627\u0644\u0629 \u0627\u0644\u0639\u0645\u0644 \u0627\u0644\u062f\u0627\u062e\u0644\u064a\u0629 \u0627\u0644\u062a\u064a \u062a\u0639\u062a\u0645\u062f\u0647\u0627 \u0627\u0644\u0642\u064a\u0627\u062f\u0629 \u2014 \u0642\u0628\u0644 \u0623\u064a \u0627\u0644\u062a\u0632\u0627\u0645 \u0628\u0628\u0631\u0646\u0627\u0645\u062c \u062a\u0634\u062e\u064a\u0635 \u0623\u0648 \u062a\u0646\u0641\u064a\u0630.',
      items: [
        '\u0645\u0633\u062d \u0641\u0631\u0635 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a \u2014 \u062f\u0648\u0646 \u0627\u0644\u062d\u0627\u062c\u0629 \u0625\u0644\u0649 \u0627\u0633\u062a\u062b\u0645\u0627\u0631 \u0633\u0627\u0628\u0642',
        '\u062d\u0627\u0644\u0629 \u0639\u0645\u0644 \u062c\u0627\u0647\u0632\u0629 \u0644\u0644\u0645\u064a\u0632\u0627\u0646\u064a\u0629 \u0644\u0627\u0639\u062a\u0645\u0627\u062f \u0627\u0644\u0642\u064a\u0627\u062f\u0629',
        '\u062a\u062d\u062f\u064a\u062f \u0648\u062a\u062d\u062c\u064a\u0645 2\u20133 \u062d\u0627\u0644\u0627\u062a \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0633\u0631\u064a\u0639\u0629 \u0627\u0644\u0641\u0648\u0632',
        '\u0625\u0637\u0627\u0631 \u0642\u0628\u0648\u0644 \u062f\u0627\u062e\u0644\u064a \u064a\u0639\u0631\u0636\u0647 \u0627\u0644\u0639\u0645\u064a\u0644 \u0639\u0644\u0649 \u0627\u0644\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0639\u0644\u064a\u0627'
      ],
      bestFor: '\u0644\u0645\u0646 \u0647\u0648: \u0627\u0644\u0645\u0624\u0633\u0633\u0627\u062a \u0627\u0644\u062a\u064a \u0644\u064a\u0633 \u0644\u062f\u064a\u0647\u0627 \u0627\u0633\u062a\u062b\u0645\u0627\u0631 \u0641\u064a \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0628\u0639\u062f\u060c \u0648\u062a\u062d\u062a\u0627\u062c \u0625\u0644\u0649 \u062d\u0627\u0644\u0629 \u062f\u0627\u062e\u0644\u064a\u0629 \u0645\u0648\u062b\u0648\u0642\u0629 \u0644\u0627\u0639\u062a\u0645\u0627\u062f \u0627\u0644\u0645\u064a\u0632\u0627\u0646\u064a\u0629 \u2014 \u0642\u0628\u0644 \u0623\u064a \u0627\u0644\u062a\u0632\u0627\u0645 \u0628\u0628\u0631\u0646\u0627\u0645\u062c \u062a\u0634\u062e\u064a\u0635 \u0623\u0648 \u062a\u0646\u0641\u064a\u0630.'
    },
    progressLabels: ['\u062e\u0637 \u0627\u0644\u0623\u0633\u0627\u0633', '\u062a\u0635\u0645\u064a\u0645 \u0627\u0644\u062a\u0648\u0633\u0639', '\u0627\u0644\u0633\u0628\u0627\u0642\u0627\u062a', '\u0627\u0644\u0627\u0633\u062a\u062f\u0627\u0645\u0629'],
    pillars: [
      {
        id: 'assess',
        number: '01',
        name: '\u0627\u0644\u062a\u0642\u064a\u064a\u0645',
        tagline: '\u0646\u0645\u0648\u0630\u062c \u0627\u0644\u0639\u0627\u0626\u062f \u0641\u064a 90 \u064a\u0648\u0645\u064b\u0627',
        meta: '4\u20138 \u0623\u0633\u0628\u0648\u0639\u064b\u0627 \u00b7 \u0633\u0639\u0631 \u062b\u0627\u0628\u062a \u00b7 \u0646\u0642\u0637\u0629 \u0627\u0644\u062f\u062e\u0648\u0644\u060c \u0645\u062d\u062f\u062f\u0629 \u062d\u0633\u0628 \u062d\u062c\u0645 \u0627\u0644\u0645\u0624\u0633\u0633\u0629',
        objective: 'قبل الالتزام بأي يورو أو درهم، ستعرف بالضبط أي استثمارات الذكاء الاصطناعي تستحق — وأيها لا يستحق. تتخطى معظم المؤسسات هذه الخطوة. ولهذا السبب تقصّر معظم استثمارات الذكاء الاصطناعي عن التوقعات. نقطة الدخول إلى نظام التشغيل. قبل الالتزام برأس المال، \u064a\u062b\u0628\u0651\u062a ASSESS \u062e\u0637 \u0623\u0633\u0627\u0633 \u0645\u0642\u0627\u064a\u064a\u0633 \u0645\u0648\u0642\u0651\u0639 \u0648\u0641\u0631\u0636\u064a\u0629 \u0642\u064a\u0645\u0629 \u0644\u0640 90 \u064a\u0648\u0645\u064b\u0627 \u0628\u0623\u0647\u062f\u0627\u0641 \u0631\u0641\u0639 \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u0642\u064a\u0627\u0633 \u2014 \u0628\u062d\u064a\u062b \u064a\u064f\u0642\u0627\u0633 \u0643\u0644 \u0633\u0628\u0627\u0642 \u0644\u0627\u062d\u0642 \u0648\u0644\u0627 \u064a\u064f\u0648\u0639\u062f \u0628\u0647.',
        entryPoint: '\u0627\u0628\u062f\u0623 \u0645\u0646 \u0647\u0646\u0627 \u2014 \u0647\u0630\u0647 \u0646\u0642\u0637\u0629 \u0627\u0644\u062f\u062e\u0648\u0644. \u0645\u0633\u0627\u0631 \u0627\u0644\u0639\u0645\u064a\u0644 \u0628\u0628\u0633\u0627\u0637\u0629: \u0627\u0644\u062a\u0642\u064a\u064a\u0645 \u2190 \u0627\u0644\u0633\u0628\u0627\u0642.',
        startHere: 'ابدأ من هنا إذا كانت لديك صلاحية الميزانية لكن دون حالة عمل مُثبتة بعد.',
        capabilities: [
          '\u062a\u062f\u0642\u064a\u0642 \u0646\u0636\u062c \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0639\u0628\u0631 5 \u0645\u0639\u0627\u064a\u064a\u0631',
          '\u062a\u0631\u062a\u064a\u0628 \u0623\u0648\u0644\u0648\u064a\u0627\u062a \u0623\u0641\u0636\u0644 3 \u062d\u0627\u0644\u0627\u062a \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0648\u062a\u0642\u064a\u064a\u0645\u0647\u0627',
          'تُصنَّف كل حالة استخدام على أنها Automate (عمل حتمي متكرر) أو Augment (حكم بشري مُسرَّع بالذكاء الاصطناعي) أو Agency (إجراء مستقل محكوم) — وأكثر نقاط الفشل شيوعًا في ميزانيات الذكاء الاصطناعي المؤسسية هو اختيار التصنيف الخاطئ قبل اختيار المورد الخاطئ.',
          '\u062a\u062b\u0628\u064a\u062a \u062e\u0637\u0648\u0637 \u0623\u0633\u0627\u0633 \u0627\u0644\u0645\u0642\u0627\u064a\u064a\u0633 \u0648\u0627\u0639\u062a\u0645\u0627\u062f\u0647\u0627',
          '\u0641\u0631\u0636\u064a\u0629 \u0642\u064a\u0645\u0629 \u0644\u0640 90 \u064a\u0648\u0645\u064b\u0627 \u0628\u0623\u0647\u062f\u0627\u0641 \u0631\u0641\u0639 \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u0642\u064a\u0627\u0633'
        ],
        benchmarks: [
          '\u062e\u0637 \u0623\u0633\u0627\u0633 \u0645\u0642\u0627\u064a\u064a\u0633 \u0645\u0648\u0642\u0651\u0639 \u2014 \u0639\u0642\u062f \u0627\u0644\u0642\u064a\u0627\u0633',
          '\u062a\u062d\u062c\u064a\u0645 \u0623\u0641\u0636\u0644 3 \u062d\u0627\u0644\u0627\u062a \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0644\u0644\u0633\u0628\u0627\u0642 \u0627\u0644\u0623\u0648\u0644',
          '\u0633\u0639\u0631 \u062b\u0627\u0628\u062a\u060c \u0645\u062d\u062f\u062f \u062d\u0633\u0628 \u062d\u062c\u0645 \u0627\u0644\u0645\u0624\u0633\u0633\u0629'
        ],
        outputs: '\u0628\u0637\u0627\u0642\u0629 \u0646\u0636\u062c \u00b7 \u062e\u0631\u064a\u0637\u0629 \u062d\u0627\u0644\u0627\u062a \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0645\u0631\u062a\u0628\u0629 \u00b7 \u062e\u0637 \u0623\u0633\u0627\u0633 \u0645\u062b\u0628\u0651\u062a \u00b7 \u0641\u0631\u0636\u064a\u0629 \u0642\u064a\u0645\u0629 90 \u064a\u0648\u0645\u064b\u0627',
        valueHypothesis: {
          title: '\u0641\u0631\u0636\u064a\u0629 \u0627\u0644\u0642\u064a\u0645\u0629 \u0645\u0646 HumanAIze',
          subtitle: '\u064a\u0646\u062a\u0647\u064a \u0643\u0644 \u062a\u0642\u064a\u064a\u0645 \u0628\u0641\u0631\u0636\u064a\u0629 \u0642\u064a\u0645\u0629 \u0645\u0643\u062a\u0648\u0628\u0629 \u0648\u0645\u0648\u0642\u0651\u0639\u0629 \u2014 \u0627\u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0645\u0643\u0648\u0651\u0646\u0629 \u0645\u0646 \u0633\u062a\u0629 \u0623\u062c\u0632\u0627\u0621 \u0627\u0644\u062a\u064a \u062a\u0639\u062a\u0645\u062f\u0647\u0627 \u0627\u0644\u0642\u064a\u0627\u062f\u0629 \u0642\u0628\u0644 \u0623\u0646 \u064a\u0628\u062f\u0623 \u0623\u064a \u0633\u0628\u0627\u0642.',
          items: [
            { label: '\u0627\u0644\u0648\u0636\u0639 \u0627\u0644\u062d\u0627\u0644\u064a', text: '\u0623\u064a\u0646 \u062a\u0642\u0641 \u0627\u0644\u0645\u0624\u0633\u0633\u0629 \u0627\u0644\u064a\u0648\u0645 \u2014 \u0645\u0642\u0627\u064a\u064a\u0633 \u062e\u0637 \u0627\u0644\u0623\u0633\u0627\u0633 \u0648\u0623\u062f\u0627\u0621 \u0627\u0644\u0639\u0645\u0644\u064a\u0627\u062a \u0627\u0644\u062d\u0627\u0644\u064a\u060c \u0645\u064f\u0648\u062b\u0651\u0642\u0629 \u0648\u0645\u0639\u062a\u0645\u062f\u0629.' },
            { label: '\u0646\u0642\u0637\u0629 \u0627\u0644\u0623\u0644\u0645', text: '\u0627\u0644\u0623\u0644\u0645 \u0627\u0644\u062a\u0634\u063a\u064a\u0644\u064a \u0648\u0627\u0644\u0645\u0627\u0644\u064a \u0627\u0644\u0645\u062d\u062f\u062f \u0627\u0644\u0630\u064a \u064a\u062e\u0644\u0642\u0647 \u0627\u0644\u0648\u0636\u0639 \u0627\u0644\u062d\u0627\u0644\u064a \u2014 \u0645\u064f\u0633\u0645\u0651\u0649 \u0648\u064a\u062a\u062d\u0645\u0644\u0647 \u0627\u0644\u0631\u0627\u0639\u064a.' },
            { label: '\u062a\u0643\u0644\u0641\u0629 \u0627\u0644\u062a\u0642\u0627\u0639\u0633', text: '\u0645\u0627 \u064a\u0643\u0644\u0641\u0647 \u0627\u0644\u0628\u0642\u0627\u0621 \u062f\u0648\u0646 \u062a\u062d\u0631\u0643 \u2014 \u0645\u064f\u0642\u0627\u0633\u064b\u0627 \u0628\u0627\u0644\u0648\u0642\u062a \u0648\u0627\u0644\u0645\u0627\u0644 \u0648\u0627\u0644\u0645\u062e\u0627\u0637\u0631 \u0639\u0628\u0631 \u0646\u0627\u0641\u0630\u0629 \u0627\u0644\u0640 90 \u064a\u0648\u0645\u064b\u0627.' },
            { label: '\u0627\u0644\u0648\u0636\u0639 \u0627\u0644\u0645\u0646\u0634\u0648\u062f', text: '\u0627\u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0646\u0647\u0627\u0626\u064a\u0629 \u0627\u0644\u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u0642\u064a\u0627\u0633 \u0627\u0644\u062a\u064a \u064a\u0633\u062a\u0647\u062f\u0641\u0647\u0627 \u0631\u0641\u0639 \u0627\u0644\u0645\u0642\u0627\u064a\u064a\u0633 \u2014 \u0647\u062f\u0641 \u0635\u0631\u064a\u062d \u0642\u0627\u0628\u0644 \u0644\u0644\u062f\u062d\u0636.' },
            { label: '\u0627\u0644\u0639\u0627\u0626\u062f \u0639\u0644\u0649 \u0627\u0644\u0627\u0633\u062a\u062b\u0645\u0627\u0631', text: '\u0631\u0641\u0639 \u0645\u0642\u0627\u064a\u064a\u0633 \u0645\u062a\u0648\u0642\u0639 \u0645\u0642\u0627\u0628\u0644 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u062b\u0627\u0628\u062a \u0644\u0644\u0627\u0631\u062a\u0628\u0627\u0637 \u2014 \u062d\u0627\u0644\u0629 \u0627\u0644\u0639\u0627\u0626\u062f \u0627\u0644\u062a\u064a \u062a\u0639\u062a\u0645\u062f\u0647\u0627 \u0627\u0644\u0642\u064a\u0627\u062f\u0629.' },
            { label: '\u0627\u0644\u062d\u0644', text: '\u062d\u0627\u0644\u0629 \u0627\u0644\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0630\u0627\u062a \u0627\u0644\u0623\u0648\u0644\u0648\u064a\u0629 \u0648\u0633\u0628\u0627\u0642 \u0627\u0644\u0640 90 \u064a\u0648\u0645\u064b\u0627 \u0627\u0644\u0630\u064a \u0633\u064a\u062d\u0631\u0651\u0643 \u0627\u0644\u0631\u0642\u0645.' },
          ]
        },
                color: 'blue'
      },
      {
        id: 'activate',
        number: '02',
        name: '\u0627\u0644\u062a\u0641\u0639\u064a\u0644',
        tagline: '\u0645\u064f\u0633\u0631\u0651\u0639 \u0627\u0644\u062a\u0648\u0633\u0639',
        optional: true,
        meta: '\u0627\u062e\u062a\u064a\u0627\u0631\u064a \u00b7 \u062d\u0633\u0628 \u0627\u0644\u0646\u0637\u0627\u0642 \u00b7 \u0627\u0634\u062a\u0631\u0627\u0643 \u0634\u0647\u0631\u064a \u00b7 \u0645\u0648\u0635\u0649 \u0628\u0647 \u0639\u0646\u062f \u0627\u0644\u062a\u0648\u0633\u0639 \u0628\u0639\u062f \u0627\u0644\u0633\u0628\u0627\u0642\u0627\u062a \u0627\u0644\u0623\u0648\u0644\u0649',
        objective: '\u0627\u062e\u062a\u064a\u0627\u0631\u064a. \u0628\u0645\u062c\u0631\u062f \u0623\u0646 \u062a\u062b\u0628\u062a \u0627\u0644\u0633\u0628\u0627\u0642\u0627\u062a \u0627\u0644\u0623\u0648\u0644\u0649 \u0627\u0644\u0642\u064a\u0645\u0629\u060c \u064a\u0635\u0645\u0645 \u0627\u0644\u062a\u0641\u0639\u064a\u0644 \u062e\u0627\u0631\u0637\u0629 \u0627\u0644\u0637\u0631\u064a\u0642 \u0648\u0646\u0645\u0648\u0630\u062c \u0627\u0644\u062a\u0634\u063a\u064a\u0644 \u0648\u0627\u0644\u062d\u0648\u0643\u0645\u0629 \u0644\u062a\u0648\u0633\u064a\u0639 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0639\u0628\u0631 \u0627\u0644\u0645\u0624\u0633\u0633\u0629. \u064a\u0642\u0639 \u062e\u0627\u0631\u062c \u0627\u0644\u0645\u0633\u0627\u0631 \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u2014 \u062a\u062e\u062a\u0627\u0631\u0647 \u0641\u0642\u0637 \u0639\u0646\u062f \u0627\u0644\u062a\u0648\u0633\u0639 \u0628\u0639\u062f \u0627\u0644\u0633\u0628\u0627\u0642\u0627\u062a \u0627\u0644\u0623\u0648\u0644\u0649.',
        entryPoint: '\u0645\u0648\u0635\u0649 \u0628\u0647 \u0639\u0646\u062f \u0627\u0644\u062a\u0648\u0633\u0639 \u0628\u0639\u062f \u0633\u0628\u0627\u0642\u0627\u062a\u0643 \u0627\u0644\u0623\u0648\u0644\u0649 \u2014 \u0644\u064a\u0633 \u062e\u0637\u0648\u0629 \u0625\u0644\u0632\u0627\u0645\u064a\u0629.',
        startHere: 'ابدأ من هنا إذا كان لديك بالفعل حالة عمل مُثبتة وتحتاج إلى الحوكمة والبنية للانتقال إلى التنفيذ.',
        capabilities: [
          '\u062a\u0635\u0645\u064a\u0645 \u062e\u0627\u0631\u0637\u0629 \u0637\u0631\u064a\u0642 \u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0644\u0640 3 \u0633\u0646\u0648\u0627\u062a',
          '\u0645\u0648\u0627\u0621\u0645\u0629 \u0646\u0645\u0648\u0630\u062c \u0627\u0644\u062a\u0634\u063a\u064a\u0644 \u0648\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u062a\u063a\u064a\u064a\u0631',
          '\u0631\u0633\u0645 \u062e\u0631\u0627\u0626\u0637 \u0627\u0644\u0627\u0645\u062a\u062b\u0627\u0644 \u0627\u0644\u062a\u0646\u0638\u064a\u0645\u064a (\u0642\u0627\u0646\u0648\u0646 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0623\u0648\u0631\u0648\u0628\u064a / \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a\u060c DIFC-10\u060c NIST)'
        ],
        benchmarks: [
          '\u062e\u0627\u0631\u0637\u0629 \u062a\u0648\u0633\u0639 \u0645\u0631\u062a\u0628\u0637\u0629 \u0628\u0646\u062c\u0627\u062d\u0627\u062a \u0627\u0644\u0633\u0628\u0627\u0642\u0627\u062a \u0627\u0644\u0645\u064f\u062b\u0628\u062a\u0629',
          '\u062d\u0648\u0643\u0645\u0629 \u0645\u0648\u0627\u0626\u0645\u0629 \u0644\u0642\u0627\u0646\u0648\u0646 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0623\u0648\u0631\u0648\u0628\u064a \u0648\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a \u0648DIFC-10 \u0648NIST',
          '\u0627\u062e\u062a\u064a\u0627\u0631\u064a \u2014 \u062d\u0633\u0628 \u0627\u0644\u0646\u0637\u0627\u0642\u060c \u0639\u0644\u0649 \u0623\u0633\u0627\u0633 \u0627\u0634\u062a\u0631\u0627\u0643'
        ],
        outputs: '\u062e\u0627\u0631\u0637\u0629 \u0637\u0631\u064a\u0642 \u0644\u0640 3 \u0633\u0646\u0648\u0627\u062a \u00b7 \u0646\u0645\u0648\u0630\u062c \u0627\u0644\u062a\u0634\u063a\u064a\u0644 \u00b7 \u062e\u0631\u064a\u0637\u0629 \u0627\u0644\u0627\u0645\u062a\u062b\u0627\u0644 \u00b7 \u062e\u0637\u0629 \u0627\u0644\u062a\u063a\u064a\u064a\u0631',
        color: 'cyan'
      },
      {
        id: 'implement',
        number: '03',
        name: '\u0627\u0644\u062a\u0646\u0641\u064a\u0630',
        tagline: '\u0633\u0628\u0627\u0642\u0627\u062a \u0627\u0644\u0639\u0627\u0626\u062f \u0641\u064a 90 \u064a\u0648\u0645\u064b\u0627',
        meta: '90 \u064a\u0648\u0645\u064b\u0627 \u0644\u0643\u0644 \u0633\u0628\u0627\u0642 \u00b7 + 10\u201315% \u0631\u0633\u0648\u0645 \u0646\u062c\u0627\u062d \u0627\u0644\u0645\u0642\u0627\u064a\u064a\u0633',
        objective: '\u062a\u064f\u0628\u0646\u0649 \u062d\u0627\u0644\u0627\u062a \u0627\u0644\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0630\u0627\u062a \u0627\u0644\u0623\u0648\u0644\u0648\u064a\u0629 \u0648\u062a\u064f\u0646\u0634\u0631 \u0641\u064a \u0633\u0628\u0627\u0642\u0627\u062a \u0645\u062f\u062a\u0647\u0627 90 \u064a\u0648\u0645\u064b\u0627\u060c \u0648\u062a\u064f\u0642\u0627\u0633 \u0645\u0642\u0627\u0628\u0644 \u062e\u0637 \u0627\u0644\u0623\u0633\u0627\u0633 \u0627\u0644\u0645\u062b\u0628\u0651\u062a. \u064a\u062d\u0645\u0644 \u0643\u0644 \u0633\u0628\u0627\u0642 \u0628\u0648\u0627\u0628\u0629 \u062a\u0641\u0639\u064a\u0644 \u2014 \u0645\u0648\u0627\u0621\u0645\u0629 \u0627\u0644\u0631\u0627\u0639\u064a \u0648\u062a\u062b\u0628\u064a\u062a \u0627\u0644\u0623\u0633\u0627\u0633 \u0648\u0627\u0644\u062d\u0648\u0643\u0645\u0629 \u2014 \u0628\u062d\u064a\u062b \u062a\u064f\u062b\u0628\u062a \u0627\u0644\u0642\u064a\u0645\u0629 \u0623\u0648 \u062a\u064f\u0643\u0631\u0631 \u0623\u0648 \u062a\u064f\u0648\u0642\u0641 \u062e\u0644\u0627\u0644 90 \u064a\u0648\u0645\u064b\u0627.',
        entryPoint: '\u062c\u0648\u0647\u0631 \u0646\u0638\u0627\u0645 \u0627\u0644\u062a\u0634\u063a\u064a\u0644 \u2014 \u064a\u0645\u062a\u062f \u0645\u0633\u0627\u0631 \u0627\u0644\u0639\u0645\u064a\u0644 \u0645\u0628\u0627\u0634\u0631\u0629 \u0645\u0646 \u0627\u0644\u062a\u0642\u064a\u064a\u0645 \u0625\u0644\u0649 \u0627\u0644\u0633\u0628\u0627\u0642 \u0627\u0644\u0623\u0648\u0644.',
        startHere: 'ابدأ من هنا إذا كانت الاستراتيجية والحوكمة قائمة بالفعل وأنت جاهز للبناء.',
        capabilities: [
          '\u0628\u0646\u0627\u0621 \u0648\u0646\u0634\u0631 \u062d\u0627\u0644\u0627\u062a \u0627\u0644\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0630\u0627\u062a \u0627\u0644\u0623\u0648\u0644\u0648\u064a\u0629',
          '\u0642\u064a\u0627\u0633 \u0645\u062b\u0628\u0651\u062a \u0639\u0644\u0649 \u062e\u0637 \u0627\u0644\u0623\u0633\u0627\u0633 \u2014 \u062f\u0648\u0646 \u0627\u062f\u0639\u0627\u0621\u0627\u062a \u063a\u064a\u0631 \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u062f\u062d\u0636',
          '\u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0648\u0643\u064a\u0644 \u0645\u062d\u0643\u0648\u0645 \u0628\u0640TARA-A\u061b \u062d\u0648\u0643\u0645\u0629 \u0623\u0635\u0644\u064a\u0629 \u0644\u0644\u0645\u0648\u0631\u062f \u0641\u064a \u063a\u064a\u0631 \u0630\u0644\u0643',
          'مساءلة بمالك مُسمّى تُفرَض عند نقطة الفعل، لا يُعاد بناؤها لاحقًا في مراجعة حادثة.',
          '\u0628\u0648\u0627\u0628\u0629 \u0627\u0644\u062a\u0641\u0639\u064a\u0644: \u0645\u0648\u0627\u0621\u0645\u0629 \u0627\u0644\u0631\u0627\u0639\u064a \u0648\u062a\u062b\u0628\u064a\u062a \u0627\u0644\u0623\u0633\u0627\u0633 \u0648\u0627\u0644\u062d\u0648\u0643\u0645\u0629'
        ],
        benchmarks: [
          '\u062d\u0627\u0644\u0627\u062a \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u062d\u064a\u0629 \u0641\u064a \u0627\u0644\u0625\u0646\u062a\u0627\u062c \u062e\u0644\u0627\u0644 \u0627\u0644\u0633\u0628\u0627\u0642',
          '\u0628\u0648\u0627\u0628\u0629 \u0627\u0644\u064a\u0648\u0645 90: \u0627\u0644\u062a\u0648\u0633\u0639 \u0623\u0648 \u0627\u0644\u062a\u0643\u0631\u0627\u0631 \u0623\u0648 \u0627\u0644\u0625\u064a\u0642\u0627\u0641',
          '\u0627\u0644\u0623\u062c\u0631 \u0639\u0644\u0649 \u0631\u0641\u0639 \u0627\u0644\u0645\u0642\u0627\u064a\u064a\u0633 \u2014 \u0631\u0633\u0648\u0645 \u0646\u062c\u0627\u062d 10\u201315%\u060c \u0644\u0627 \u0639\u0644\u0649 \u0627\u0644\u0648\u0639\u0648\u062f'
        ],
        outputs: '\u062d\u0627\u0644\u0627\u062a \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0625\u0646\u062a\u0627\u062c\u064a\u0629 \u00b7 \u062f\u0644\u064a\u0644 \u0645\u0642\u0627\u064a\u064a\u0633 \u0645\u062b\u0628\u0651\u062a \u00b7 \u0642\u0631\u0627\u0631 \u062a\u0648\u0633\u0639 \u0627\u0644\u064a\u0648\u0645 90',
        color: 'slate'
      },
      {
        id: 'embed',
        number: '04',
        name: '\u0627\u0644\u062a\u0636\u0645\u064a\u0646',
        tagline: '\u0627\u0644\u0627\u0633\u062a\u062f\u0627\u0645\u0629 \u0648\u0627\u0644\u062a\u0648\u0633\u0639',
        meta: '\u0645\u0633\u062a\u0645\u0631 \u00b7 \u0627\u0634\u062a\u0631\u0627\u0643 \u0634\u0647\u0631\u064a',
        objective: 'هدف كل ارتباط مع HumanAIze هو أن نجعل أنفسنا غير ضروريين. نبني القدرة الداخلية وهياكل الحوكمة وأنظمة القياس التي تحتاجها مؤسستك للحفاظ على قيمة الذكاء الاصطناعي دون اعتماد خارجي. عندما نغادر، تملك كل شيء. فريقك يُشغّله. لا تحتاج إلينا لصيانته. هذه ليست ميزة. إنها التعريف الصادق الوحيد للتحول.',
        entryPoint: '\u0627\u0628\u062f\u0623 \u0645\u0646 \u0647\u0646\u0627 \u0628\u0645\u062c\u0631\u062f \u0623\u0646 \u064a\u0643\u0648\u0646 \u0644\u062f\u064a\u0643 \u0641\u0627\u0626\u0632\u0648\u0646 \u0645\u064f\u062b\u0628\u062a\u0648\u0646 \u062c\u0627\u0647\u0632\u0648\u0646 \u0644\u0644\u062a\u0648\u0633\u0639 \u0639\u0628\u0631 \u0627\u0644\u0645\u0624\u0633\u0633\u0629.',
        startHere: 'ابدأ من هنا إذا كان لديك طيار واحد مُثبت على الأقل وتحتاج إلى توسيعه على مستوى المؤسسة.',
        capabilities: [
          '\u062a\u0648\u0633\u064a\u0639 \u0627\u0644\u0641\u0627\u0626\u0632\u064a\u0646 \u0627\u0644\u0645\u064f\u062b\u0628\u062a\u064a\u0646 \u0639\u0644\u0649 \u0645\u0633\u062a\u0648\u0649 \u0627\u0644\u0645\u0624\u0633\u0633\u0629',
          '\u0645\u062d\u0648 \u0623\u0645\u064a\u0629 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0648\u0628\u0646\u0627\u0621 \u0627\u0644\u0642\u062f\u0631\u0627\u062a (\u0645\u0646 CAIO+ \u0625\u0644\u0649 \u0643\u0644 \u0627\u0644\u0645\u0633\u062a\u0648\u064a\u0627\u062a)',
          '\u0645\u0643\u062a\u0628 \u0627\u0644\u062a\u062d\u0648\u0644 \u0643\u062e\u062f\u0645\u0629',
          '\u0627\u0634\u062a\u0631\u0627\u0643\u0627\u062a AIaaS + \u062a\u062f\u0631\u064a\u0628\u0627\u062a \u0645\u064f\u062c\u0645\u0651\u0639\u0629'
        ],
        benchmarks: [
          '\u0641\u0627\u0626\u0632\u0648\u0646 \u0645\u064f\u062b\u0628\u062a\u0648\u0646 \u0645\u0648\u0633\u0651\u0639\u0648\u0646 \u0639\u0628\u0631 \u0627\u0644\u0645\u0624\u0633\u0633\u0629',
          '\u0646\u0642\u0644 \u0627\u0644\u0642\u062f\u0631\u0627\u062a \u2014 \u0641\u0631\u064a\u0642\u0643 \u064a\u064f\u0634\u063a\u0651\u0644\u0647\u0627',
          '\u0627\u0634\u062a\u0631\u0627\u0643 AIaaS \u0645\u0633\u062a\u0645\u0631 + \u062a\u062f\u0631\u064a\u0628\u0627\u062a \u0645\u064f\u062c\u0645\u0651\u0639\u0629'
        ],
        outputs: '\u0646\u0634\u0631 \u0639\u0644\u0649 \u0645\u0633\u062a\u0648\u0649 \u0627\u0644\u0645\u0624\u0633\u0633\u0629 \u00b7 \u0628\u0631\u0646\u0627\u0645\u062c \u0645\u062d\u0648 \u0623\u0645\u064a\u0629 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a \u00b7 \u0645\u0643\u062a\u0628 \u0627\u0644\u062a\u062d\u0648\u0644 \u00b7 \u0627\u0634\u062a\u0631\u0627\u0643 AIaaS',
        color: 'silver'
      }
    ],
    kpiBand: {
      title: '\u0646\u0638\u0627\u0645 \u0627\u0644\u062a\u0634\u063a\u064a\u0644 \u0628\u0627\u0644\u0623\u0631\u0642\u0627\u0645',
      metrics: [
        { value: '3\u20135 \u0623\u064a\u0627\u0645', label: '\u062d\u0627\u0644\u0629 \u0639\u0645\u0644 Blindspot' },
        { value: '6\u201312 \u0623\u0633\u0628\u0648\u0639\u064b\u0627', label: '\u062a\u062b\u0628\u064a\u062a \u0623\u0633\u0627\u0633 ASSESS' },
        { value: '90 \u064a\u0648\u0645\u064b\u0627', label: '\u0644\u0643\u0644 \u0633\u0628\u0627\u0642 \u0639\u0627\u0626\u062f' },
        { value: '\u0627\u0644\u064a\u0648\u0645 90', label: '\u0627\u0644\u062a\u0648\u0633\u0639 \u0623\u0648 \u0627\u0644\u062a\u0643\u0631\u0627\u0631 \u0623\u0648 \u0627\u0644\u0625\u064a\u0642\u0627\u0641' },
        { value: '10\u201315%', label: '\u0631\u0633\u0648\u0645 \u0646\u062c\u0627\u062d \u0627\u0644\u0645\u0642\u0627\u064a\u064a\u0633' }
      ]
    },
    vsBig4: {
      title: 'HumanAIze \u0645\u0642\u0627\u0628\u0644 \u0627\u0644\u0634\u0631\u0643\u0627\u062a \u0627\u0644\u0623\u0631\u0628\u0639 \u0627\u0644\u0643\u0628\u0631\u0649',
      colBig4: '\u0627\u0644\u0634\u0631\u0643\u0627\u062a \u0627\u0644\u0623\u0631\u0628\u0639 \u0627\u0644\u0643\u0628\u0631\u0649 / \u0645\u0627\u0643\u064a\u0646\u0632\u064a',
      colUs: 'HumanAIze',
      rows: [
        { criteria: '\u0646\u0645\u0648\u0630\u062c \u0627\u0644\u0623\u062a\u0639\u0627\u0628', big4: '\u0627\u0644\u0641\u0648\u062a\u0631\u0629 \u0628\u0627\u0644\u0633\u0627\u0639\u0627\u062a \u0648\u062d\u062c\u0645 \u0627\u0644\u0641\u0631\u064a\u0642', us: '\u062f\u062e\u0648\u0644 \u0628\u0633\u0639\u0631 \u062b\u0627\u0628\u062a + \u0631\u0633\u0648\u0645 \u0646\u062c\u0627\u062d 10\u201315% \u0645\u0631\u062a\u0628\u0637\u0629 \u0628\u0631\u0641\u0639 \u0627\u0644\u0645\u0642\u0627\u064a\u064a\u0633' },
        { criteria: '\u0627\u0644\u062a\u0646\u0641\u064a\u0630', big4: '\u062a\u064f\u0633\u0644\u0651\u0645 \u0627\u0644\u0627\u0633\u062a\u0631\u0627\u062a\u064a\u062c\u064a\u0629 \u0648\u064a\u064f\u062d\u0627\u0644 \u0627\u0644\u062a\u0646\u0641\u064a\u0630', us: '\u0627\u0644\u0627\u0633\u062a\u0631\u0627\u062a\u064a\u062c\u064a\u0629 \u0648\u0627\u0644\u062a\u0646\u0641\u064a\u0630 \u2014 \u0646\u0628\u0642\u0649 \u062d\u062a\u0649 \u064a\u062a\u063a\u064a\u0631 \u0627\u0644\u0631\u0642\u0645' },
        { criteria: '\u0627\u0644\u0642\u064a\u0627\u0633', big4: '\u062a\u064f\u062a\u0648\u0642\u0639 \u0627\u0644\u0646\u062a\u0627\u0626\u062c \u0641\u064a \u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u062a\u0642\u062f\u064a\u0645\u064a', us: '\u0642\u064a\u0645\u0629 \u062a\u064f\u0642\u0627\u0633 \u0645\u0642\u0627\u0628\u0644 \u062e\u0637 \u0623\u0633\u0627\u0633 \u0645\u0648\u0642\u0651\u0639 \u2014 \u062f\u0648\u0646 \u0627\u062f\u0639\u0627\u0621\u0627\u062a \u063a\u064a\u0631 \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u062f\u062d\u0636' },
        { criteria: '\u0646\u0645\u0648\u0630\u062c \u0627\u0644\u062e\u0631\u0648\u062c', big4: '\u064a\u062a\u0639\u0645\u0642 \u0627\u0644\u0627\u0639\u062a\u0645\u0627\u062f \u0645\u0639 \u0643\u0644 \u0627\u0631\u062a\u0628\u0627\u0637', us: '\u0646\u0642\u0644 \u0627\u0644\u0642\u062f\u0631\u0627\u062a \u2014 \u064a\u0645\u062a\u0644\u0643\u0647 \u0641\u0631\u064a\u0642\u0643 \u0639\u0646\u062f\u0645\u0627 \u0646\u063a\u0627\u062f\u0631' },
        { criteria: '\u0627\u0644\u0641\u0631\u064a\u0642', big4: '\u0645\u062d\u0644\u0644\u0648\u0646 \u062d\u062f\u064a\u062b\u0648 \u0627\u0644\u062a\u062e\u0631\u062c \u0641\u064a \u062d\u0633\u0627\u0628\u0643', us: '\u062e\u0628\u0631\u0627\u0621 \u0643\u0628\u0627\u0631 \u0645\u062e\u062a\u0627\u0631\u0648\u0646\u060c \u062f\u0648\u0646 \u0645\u0628\u062a\u062f\u0626\u064a\u0646' },
        { criteria: '\u0627\u0644\u062d\u0648\u0643\u0645\u0629', big4: '\u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0643\u062a\u0646\u0641\u064a\u0630 \u062a\u0642\u0646\u064a', us: 'TARA-A \u0644\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0648\u0643\u064a\u0644\u061b \u062d\u0648\u0643\u0645\u0629 \u0623\u0635\u0644\u064a\u0629 \u0644\u0644\u0645\u0648\u0631\u062f \u0641\u064a \u063a\u064a\u0631 \u0630\u0644\u0643' }
      ]
    },
    commitment: {
      title: '\u0645\u0639\u064a\u0627\u0631 \u0627\u0644\u0645\u0633\u0627\u0621\u0644\u0629 \u0644\u062f\u064a\u0646\u0627',
      items: [
        '\u062e\u0637 \u0623\u0633\u0627\u0633 \u0645\u0642\u0627\u064a\u064a\u0633 \u0645\u0648\u0642\u0651\u0639 \u0642\u0628\u0644 \u0628\u062f\u0621 \u0623\u064a \u0633\u0628\u0627\u0642',
        '\u0641\u0631\u0636\u064a\u0629 \u0642\u064a\u0645\u0629 \u0645\u0643\u062a\u0648\u0628\u0629 \u0644\u0640 90 \u064a\u0648\u0645\u064b\u0627',
        '\u0628\u0648\u0627\u0628\u0629 \u062a\u0641\u0639\u064a\u0644 \u0641\u064a \u0643\u0644 \u0633\u0628\u0627\u0642: \u0627\u0644\u0631\u0627\u0639\u064a \u0648\u0627\u0644\u0623\u0633\u0627\u0633 \u0648\u0627\u0644\u062d\u0648\u0643\u0645\u0629',
        '\u0628\u0648\u0627\u0628\u0629 \u0627\u0644\u064a\u0648\u0645 90 \u2014 \u0627\u0644\u062a\u0648\u0633\u0639 \u0623\u0648 \u0627\u0644\u062a\u0643\u0631\u0627\u0631 \u0623\u0648 \u0627\u0644\u0625\u064a\u0642\u0627\u0641',
        '\u0627\u0644\u0623\u062c\u0631 \u0639\u0644\u0649 \u0631\u0641\u0639 \u0627\u0644\u0645\u0642\u0627\u064a\u064a\u0633\u060c \u0644\u0627 \u0639\u0644\u0649 \u0627\u0644\u0648\u0639\u0648\u062f',
        'التوصيات محايدة تجاه المورّدين — لا منصات مفضّلة ولا رسوم إحالة',
        '\u0645\u0648\u0627\u0621\u0645\u0629 \u062a\u0646\u0638\u064a\u0645\u064a\u0629 \u0639\u0627\u0628\u0631\u0629 \u0644\u0644\u062d\u062f\u0648\u062f (\u0642\u0627\u0646\u0648\u0646 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0623\u0648\u0631\u0648\u0628\u064a / \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a\u060c DIFC-10\u060c NIST)'
      ],
      footer: '\u0642\u064a\u0645\u0629 \u062a\u064f\u062b\u0628\u062a \u2014 \u0623\u0648 \u062a\u064f\u0648\u0642\u0641 \u2014 \u0641\u064a 90 \u064a\u0648\u0645\u064b\u0627. \u0646\u062a\u0642\u0627\u0636\u0649 \u0623\u062c\u0631\u0646\u0627 \u0639\u0644\u0649 \u0627\u0644\u0631\u0641\u0639\u060c \u0644\u0627 \u0639\u0644\u0649 \u0627\u0644\u0648\u0639\u0648\u062f.'
    },
    labels: {
      objective: '\u0627\u0644\u0646\u0645\u0648\u0630\u062c',
      capabilities: '\u0627\u0644\u0642\u062f\u0631\u0627\u062a \u0627\u0644\u0623\u0633\u0627\u0633\u064a\u0629',
      benchmarks: '\u0643\u064a\u0641 \u062a\u064f\u062b\u0628\u062a \u0627\u0644\u0642\u064a\u0645\u0629',
      outputs: '\u0644\u0645\u062d\u0629 \u0627\u0644\u0645\u062e\u0631\u062c\u0627\u062a',
      optional: '\u0627\u062e\u062a\u064a\u0627\u0631\u064a',
      blindspotCalcHeading: 'حاسبة النقاط العمياء',
      blindspotCalcSub: 'احسب تكلفة عدم اتخاذ أي إجراء. اكتشف أين تستنزف النقاط العمياء للذكاء الاصطناعي القيمة بهدوء — في أقل من دقيقتين.',
      roiCalcHeading: 'حاسبة عائد الاستثمار للذكاء الاصطناعي',
      roiCalcSub: 'احسب العائد المحتمل لأول سباق عائد استثمار مدته 90 يومًا مقابل معايير قياسية موثوقة للقطاع.'
    }
  }
};

const pillarIcons = {
  assess: Search,
  activate: Zap,
  implement: Cog,
  embed: Users
};

const getHeaderGradient = (color: string) => {
  switch (color) {
    case 'blue': return 'from-blue-600 to-blue-800';
    case 'cyan': return 'from-cyan-500 to-blue-600';
    case 'slate': return 'from-slate-500 to-slate-700';
    case 'silver': return 'from-gray-400 to-gray-600';
    default: return 'from-blue-600 to-cyan-500';
  }
};

const getPillBg = (color: string) => {
  switch (color) {
    case 'blue': return 'bg-blue-600';
    case 'cyan': return 'bg-cyan-500';
    case 'slate': return 'bg-slate-600';
    case 'silver': return 'bg-gray-500';
    default: return 'bg-blue-600';
  }
};

const getAccentColor = (color: string) => {
  switch (color) {
    case 'blue': return 'text-blue-400';
    case 'cyan': return 'text-cyan-400';
    case 'slate': return 'text-slate-400';
    case 'silver': return 'text-gray-400';
    default: return 'text-cyan-400';
  }
};

export default function ServicesPage() {
  const { language } = useLanguage();
  const [heroRef, heroInView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const [pillarsRef, pillarsInView] = useInView({ triggerOnce: true, threshold: 0.05 });
  const [kpiRef, kpiInView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const [commitRef, commitInView] = useInView({ triggerOnce: true, threshold: 0.1 });

  const content = servicesContent[language as keyof typeof servicesContent] || servicesContent.en;
  const isRTL = language === 'ar';

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0e1a] via-[#0f1629] to-[#0a0e1a]" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Hero Section */}
      <motion.section
        ref={heroRef}
        initial={{ opacity: 0, y: 30 }}
        animate={heroInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7 }}
        className="pt-32 pb-16 px-4"
      >
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4">
            <span className="bg-gradient-to-r from-white via-cyan-200 to-blue-300 bg-clip-text text-transparent">
              {content.heroTitle}
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-400 font-light">
            {content.heroSubtitle}
          </p>

          {/* Progress Flow */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-2 md:gap-4">
            {content.pillars.map((pillar, index) => {
              const Icon = pillarIcons[pillar.id as keyof typeof pillarIcons];
              return (
                <div key={pillar.id} className="flex items-center">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={heroInView ? { opacity: 1, scale: 1 } : {}}
                    transition={{ duration: 0.5, delay: index * 0.15 }}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full ${getPillBg(pillar.color)} text-white font-semibold text-sm md:text-base`}
                  >
                    <Icon size={18} />
                    {pillar.name}
                  </motion.div>
                  {index < content.pillars.length - 1 && (
                    <ArrowRight className="text-gray-600 mx-1 md:mx-2 hidden sm:block" size={20} />
                  )}
                </div>
              );
            })}
          </div>

          {/* Progress Labels */}
          <div className="mt-6 flex justify-center">
            <div className="flex items-center gap-0 w-full max-w-2xl">
              {content.progressLabels.map((label, index) => (
                <div key={index} className="flex-1 text-center">
                  <div className="h-1 bg-gradient-to-r from-blue-600 via-cyan-500 to-gray-500 mb-2" />
                  <span className="text-xs text-gray-500">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.section>

      {/* Commitment Section */}
      <motion.section
        ref={commitRef}
        initial={{ opacity: 0, y: 30 }}
        animate={commitInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7 }}
        className="py-16 px-4 pb-24"
      >
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-[#1a2332] to-[#111827] rounded-2xl p-8 md:p-10 border border-cyan-500/30">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center">
                <Shield className="text-white" size={24} />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white">
                {content.commitment.title}
              </h2>
            </div>

            <div className="grid md:grid-cols-2 gap-3 mb-6">
              {content.commitment.items.map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle2 className="text-cyan-400 mt-0.5 flex-shrink-0" size={18} />
                  <span className="text-gray-300">{item}</span>
                </div>
              ))}
            </div>

            <div className="pt-6 border-t border-gray-700/50">
              <p className="text-lg text-cyan-300 font-semibold text-center">
                {content.commitment.footer}
              </p>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Pillars Section */}
      <section ref={pillarsRef} className="py-12 px-4">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Intro paragraph */}
          <div className="max-w-4xl mx-auto text-center pb-2">
            <p className="text-lg text-gray-300 leading-relaxed">{content.introPara}</p>
          </div>

          {/* Blindspot — Optional entry point */}
          <div className="bg-[#0f1629]/60 rounded-2xl border-2 border-dashed border-cyan-500/40 p-6 md:p-8">
            <div className={`flex flex-wrap items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <span className="inline-block px-3 py-1 rounded-full bg-cyan-500/15 text-cyan-300 text-xs font-semibold uppercase tracking-wider">
                {content.blindspot.label}
              </span>
              <h2 className="text-2xl md:text-3xl font-bold text-white">{content.blindspot.name}</h2>
              <span className="text-cyan-200/90 text-lg">{content.blindspot.tagline}</span>
            </div>
            <p className={`text-sm text-gray-500 mb-4 ${isRTL ? 'text-right' : ''}`}>{content.blindspot.meta}</p>
            <p className={`text-gray-300 text-base leading-relaxed mb-5 ${isRTL ? 'text-right' : ''}`}>{content.blindspot.desc}</p>
            <ul className="grid md:grid-cols-2 gap-2 mb-5">
              {content.blindspot.items.map((item, i) => (
                <li key={i} className={`flex items-start gap-2 text-gray-300 ${isRTL ? 'flex-row-reverse text-right' : ''}`}>
                  <CheckCircle2 className="text-cyan-400 mt-0.5 flex-shrink-0" size={16} />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <p className={`text-sm text-gray-400 italic ${isRTL ? 'text-right' : ''}`}>{content.blindspot.bestFor}</p>

            {/* Blindspot Calculator artefact */}
            <div className="mt-8">
              <h3 className={`text-xl md:text-2xl font-bold text-white mb-2 ${isRTL ? 'text-right' : ''}`}>{content.labels.blindspotCalcHeading}</h3>
              <p className={`text-gray-400 text-sm mb-4 ${isRTL ? 'text-right' : ''}`}>{content.labels.blindspotCalcSub}</p>
              <ToolAccessButton
                language={language}
                toolPath="/tools/blindspot-calculator.html"
                formType="blindspot_calculator"
                subject="Blindspot Calculator access"
                downloadName="HumanAIze-Blindspot-Calculator.html"
                toolName={content.labels.blindspotCalcHeading}
              />
            </div>
          </div>

          {content.pillars.map((pillar: any, index: number) => {
            const Icon = pillarIcons[pillar.id as keyof typeof pillarIcons];
            return (
              <motion.div
                key={pillar.id}
                initial={{ opacity: 0, y: 40 }}
                animate={pillarsInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                className="bg-[#111827]/80 rounded-2xl border border-gray-700/50 overflow-hidden hover:border-cyan-500/30 transition-all duration-300"
              >
                {/* Pillar Header */}
                <div className={`bg-gradient-to-r ${getHeaderGradient(pillar.color)} p-6`}>
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center">
                      <Icon className="text-white" size={28} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <div className="text-white/80 text-sm font-medium">STAGE {pillar.number}</div>
                        {pillar.optional && (
                          <span className="text-[11px] font-semibold uppercase tracking-wide bg-white/20 text-white px-2 py-0.5 rounded-full">{content.labels.optional}</span>
                        )}
                      </div>
                      <h2 className="text-2xl md:text-3xl font-bold text-white">{pillar.name}</h2>
                      <p className="text-white/90 text-lg">{pillar.tagline}</p>
                      {pillar.meta && <p className="text-white/70 text-sm mt-1">{pillar.meta}</p>}
                    </div>
                  </div>
                </div>

                {/* Pillar Content */}
                <div className="p-6 md:p-8">
                  {/* Objective */}
                  <div className="mb-6">
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="text-cyan-400" size={20} />
                      <h3 className="text-cyan-400 font-semibold text-lg">{content.labels.objective}</h3>
                    </div>
                    <p className="text-gray-300 text-base leading-relaxed">
                      {pillar.objective}
                    </p>
                    <div className={`mt-3 flex items-start gap-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 px-4 py-2.5 ${isRTL ? 'flex-row-reverse text-right' : ''}`}>
                      <ArrowRight className="text-cyan-400 mt-0.5 flex-shrink-0" size={16} />
                      <span className="text-cyan-200 text-sm font-medium">{pillar.entryPoint}</span>
                    </div>
                    {pillar.startHere && (
                      <p className={`mt-2 text-sm text-gray-400 italic ${isRTL ? 'text-right' : ''}`}>{pillar.startHere}</p>
                    )}
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    {/* Core Capabilities */}
                    <div>
                      <h3 className="text-white font-semibold text-lg mb-3 flex items-center gap-2">
                        <Cog className="text-blue-400" size={18} />
                        {content.labels.capabilities}
                      </h3>
                      <ul className="space-y-2">
                        {pillar.capabilities.map((cap: any, i: number) => (
                          <li key={i} className="flex items-start gap-2 text-gray-300">
                            <CheckCircle2 className="text-cyan-400 mt-0.5 flex-shrink-0" size={16} />
                            <span>{cap}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Key Benchmarks */}
                    <div>
                      <h3 className="text-white font-semibold text-lg mb-3 flex items-center gap-2">
                        <TrendingUp className="text-cyan-400" size={18} />
                        {content.labels.benchmarks}
                      </h3>
                      <ul className="space-y-2">
                        {pillar.benchmarks.map((bench: any, i: number) => (
                          <li key={i} className="flex items-start gap-2 text-gray-300">
                            <CheckCircle2 className="text-gray-400 mt-0.5 flex-shrink-0" size={16} />
                            <span>{bench}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Output Snapshot */}
                  <div className="mt-6 p-4 bg-[#0a0e1a]/50 rounded-lg border border-gray-700/30">
                    <h4 className="text-gray-500 text-sm font-medium mb-1">{content.labels.outputs}</h4>
                    <p className="text-white font-medium">{pillar.outputs}</p>
                  </div>

                  {/* AI ROI Calculator artefact (ASSESS only) */}
                  {index === 0 && (
                    <div className="mt-6">
                      <h3 className={`text-xl md:text-2xl font-bold text-white mb-2 ${isRTL ? 'text-right' : ''}`}>{content.labels.roiCalcHeading}</h3>
                      <p className={`text-gray-400 text-sm mb-4 ${isRTL ? 'text-right' : ''}`}>{content.labels.roiCalcSub}</p>
                      <ToolAccessButton
                        language={language}
                        toolPath="/tools/ai-roi-calculator.html"
                        formType="roi_calculator"
                        subject="AI ROI Calculator access"
                        downloadName="HumanAIze-AI-ROI-Calculator.html"
                        toolName={content.labels.roiCalcHeading}
                      />
                    </div>
                  )}

                  {/* Value Hypothesis (Assess only) */}
                  {pillar.valueHypothesis && (
                    <div className="mt-6 p-5 bg-gradient-to-br from-blue-900/20 to-cyan-900/10 rounded-xl border border-cyan-500/20">
                      <div className={`flex items-center gap-2 mb-1 ${isRTL ? 'flex-row-reverse text-right' : ''}`}>
                        <Target className="text-cyan-400 flex-shrink-0" size={18} />
                        <h4 className="text-white font-semibold text-lg">{pillar.valueHypothesis.title}</h4>
                      </div>
                      <p className={`text-gray-400 text-sm mb-4 ${isRTL ? 'text-right' : ''}`}>{pillar.valueHypothesis.subtitle}</p>
                      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {pillar.valueHypothesis.items.map((vh: any, i: number) => (
                          <div key={i} className={`rounded-lg bg-[#0a0e1a]/60 border border-gray-700/40 p-4 ${isRTL ? 'text-right' : ''}`}>
                            <div className={`flex items-center gap-2 mb-1.5 ${isRTL ? 'flex-row-reverse' : ''}`}>
                              <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-bold flex items-center justify-center flex-shrink-0">{i + 1}</span>
                              <span className="text-cyan-300 font-semibold text-sm">{vh.label}</span>
                            </div>
                            <p className="text-gray-300 text-sm leading-relaxed">{vh.text}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Capability Building (only for Embed pillar) */}
                  {pillar.capabilityBuilding && (
                    <div className="mt-6 p-5 bg-gradient-to-br from-gray-800/30 to-slate-800/20 rounded-xl border border-gray-600/30">
                      <h4 className="text-gray-300 font-semibold text-lg mb-1">{pillar.capabilityBuilding.title}</h4>
                      <p className="text-gray-500 text-sm mb-4">{pillar.capabilityBuilding.subtitle}</p>
                      
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <ul className="space-y-1.5">
                            {pillar.capabilityBuilding.items.map((item: any, i: number) => (
                              <li key={i} className="flex items-start gap-2 text-gray-300 text-sm">
                                <CheckCircle2 className="text-cyan-400 mt-0.5 flex-shrink-0" size={14} />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <div className="text-gray-400 font-medium text-sm mb-2">Outcomes</div>
                          <ul className="space-y-1.5">
                            {pillar.capabilityBuilding.outcomes.map((outcome: any, i: number) => (
                              <li key={i} className="flex items-start gap-2 text-gray-300 text-sm">
                                <Shield className="text-gray-400 mt-0.5 flex-shrink-0" size={14} />
                                <span>{outcome}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* KPI Benchmark Band */}
      <motion.section
        ref={kpiRef}
        initial={{ opacity: 0, y: 30 }}
        animate={kpiInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7 }}
        className="py-16 px-4"
      >
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-8">
            <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
              {content.kpiBand.title}
            </span>
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {content.kpiBand.metrics.map((metric, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={kpiInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-[#111827]/80 p-5 rounded-xl border border-cyan-500/20 text-center hover:border-cyan-400/40 transition-all"
              >
                <div className="text-2xl md:text-3xl font-bold text-cyan-400 mb-1">{metric.value}</div>
                <div className="text-gray-500 text-sm">{metric.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Vs. Big4 Comparison */}
      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-8">
            <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
              {content.vsBig4.title}
            </span>
          </h2>
          <div className="overflow-x-auto rounded-2xl border border-gray-700/50">
            <table className="w-full text-left border-collapse" dir={isRTL ? 'rtl' : 'ltr'}>
              <thead>
                <tr className="bg-[#0f1629]">
                  <th className="p-4 text-gray-400 font-semibold text-sm"></th>
                  <th className="p-4 text-gray-300 font-semibold text-sm border-l border-gray-700/50">{content.vsBig4.colBig4}</th>
                  <th className="p-4 text-cyan-300 font-bold text-sm border-l border-cyan-500/30 bg-cyan-500/5">{content.vsBig4.colUs}</th>
                </tr>
              </thead>
              <tbody>
                {content.vsBig4.rows.map((row, i) => (
                  <tr key={i} className="border-t border-gray-700/40">
                    <td className="p-4 text-white font-semibold text-sm align-top">{row.criteria}</td>
                    <td className="p-4 text-gray-400 text-sm align-top border-l border-gray-700/50">{row.big4}</td>
                    <td className="p-4 text-gray-200 text-sm align-top border-l border-cyan-500/30 bg-cyan-500/5">{row.us}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <FaqSection ids={['where-start', 'what-services', 'what-blindspot', 'what-assess', 'what-90-day-sprint', 'what-roi-as-service', 'no-credible-roi']} />
    </div>
  );
}