'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Link from 'next/link';
import { useLanguage } from '@/lib/language-context';
import { Button } from '@/components/ui/button';
import FaqSection from '@/components/sections/faq-section';

const pricingContent = {
  eyebrow: {
    en: 'OUR PRICING',
    de: 'UNSERE PREISE',
    ar: 'أسعارنا'
  },
  title: {
    en: 'Investment Models Aligned to Enterprise Outcomes',
    de: 'Investitionsmodelle ausgerichtet auf Unternehmensergebnisse',
    ar: 'نماذج استثمارية متوافقة مع نتائج المؤسسات'
  },
  subtitle: {
    en: 'We align fees to defined outcomes — not billable hours. Engagements are structured to match governance, procurement, and ROI expectations in DACH and the UAE.',
    de: 'Wir orientieren unsere Honorare an definierten Ergebnissen — nicht an abrechenbaren Stunden. Engagements sind auf Governance, Beschaffung und ROI-Erwartungen in DACH und den VAE abgestimmt.',
    ar: 'نحن نوائم الرسوم مع النتائج المحددة — وليس الساعات القابلة للفوترة. يتم هيكلة التعاقدات لتتوافق مع توقعات الحوكمة والمشتريات وعائد الاستثمار في DACH والإمارات.'
  },
  journey: {
    en: ['Assess', 'Activate', 'Implement', 'Embed'],
    de: ['Bewerten', 'Aktivieren', 'Umsetzen', 'Verankern'],
    ar: ['التقييم', 'التفعيل', 'التنفيذ', 'الترسيخ']
  },
  blindspot: {
    kicker: { en: 'OPTIONAL ENTRY POINT', de: 'OPTIONALER EINSTIEGSPUNKT', ar: 'نقطة دخول اختيارية' },
    title: { en: 'Blindspot — Opportunity Case Builder', de: 'Blindspot — Opportunity-Case-Builder', ar: 'Blindspot — أداة بناء حالة الفرص' },
    note: { en: 'Fixed fee · 3–5 days · Standalone, optional', de: 'Festpreis · 3–5 Tage · Eigenständig, optional', ar: 'رسوم ثابتة · 3–5 أيام · مستقل واختياري' },
    desc: {
      en: "Not sure there's a credible AI opportunity yet? We scan for it and build the business case your board needs to release budget.",
      de: 'Noch nicht sicher, ob eine glaubwürdige KI-Chance besteht? Wir identifizieren sie und erstellen den Business Case, den Ihr Vorstand benötigt, um Budget freizugeben.',
      ar: 'لست متأكدًا بعد من وجود فرصة ذكاء اصطناعي موثوقة؟ نقوم بالبحث عنها وبناء حالة العمل التي يحتاجها مجلس إدارتك للإفراج عن الميزانية.'
    },
    items: {
      en: ['AI opportunity scan, no prior AI investment needed', 'Budget-ready business case for leadership sign-off'],
      de: ['KI-Chancen-Scan, keine vorherige KI-Investition erforderlich', 'Budgetreifer Business Case für die Freigabe durch die Führung'],
      ar: ['مسح فرص الذكاء الاصطناعي، دون الحاجة إلى استثمار سابق', 'حالة عمل جاهزة للميزانية لاعتماد القيادة']
    },
    tag: {
      en: 'Best for: organisations with no AI investment yet, who need internal buy-in before committing to anything larger.',
      de: 'Ideal für: Organisationen ohne bisherige KI-Investition, die interne Zustimmung benötigen, bevor sie sich zu etwas Größerem verpflichten.',
      ar: 'الأفضل لـ: المؤسسات التي ليس لديها استثمار في الذكاء الاصطناعي بعد وتحتاج إلى موافقة داخلية قبل الالتزام بأي شيء أكبر.'
    }
  },
  cards: [
    {
      number: 'I',
      kicker: { en: 'KNOW BEFORE YOU INVEST', de: 'WISSEN, BEVOR SIE INVESTIEREN', ar: 'اعرف قبل أن تستثمر' },
      title: { en: 'Assess', de: 'Bewerten', ar: 'التقييم' },
      note: { en: 'Fixed fee · 4–8 weeks · Entry point into the Operating System', de: 'Festpreis · 4–8 Wochen · Einstieg in das Operating System', ar: 'رسوم ثابتة · 4–8 أسبوعًا · نقطة الدخول إلى نظام التشغيل' },
      desc: {
        en: 'A board-ready diagnostic that tells you where AI value actually lives — before capital is committed.',
        de: 'Eine vorstandsreife Diagnose, die Ihnen zeigt, wo der KI-Wert tatsächlich liegt — bevor Kapital gebunden wird.',
        ar: 'تشخيص جاهز للمجلس يخبرك أين تكمن قيمة الذكاء الاصطناعي فعليًا — قبل التزام رأس المال.'
      },
      items: {
        en: ['AI maturity audit across 5 criteria', 'Top-3 use cases prioritised and scored', 'Metric baselines locked and signed off', '90-Day Value Hypothesis with metric uplift targets'],
        de: ['KI-Reifegrad-Audit über 5 Kriterien', 'Top-3-Anwendungsfälle priorisiert und bewertet', 'Metrik-Baselines fixiert und freigegeben', '90-Tage-Wert-Hypothese mit Zielwerten für Kennzahlensteigerung'],
        ar: ['تدقيق نضج الذكاء الاصطناعي عبر 5 معايير', 'ترتيب أفضل 3 حالات استخدام وتقييمها', 'تثبيت واعتماد خطوط أساس المقاييس', 'فرضية القيمة لـ 90 يومًا مع أهداف تحسين المقاييس']
      },
      pillars: { en: ['Pillar I', 'Fixed fee'], de: ['Säule I', 'Festpreis'], ar: ['الركيزة الأولى', 'رسوم ثابتة'] },
      tag: { en: 'Best for: first mandate, board clarity, no capital committed yet.', de: 'Ideal für: erstes Mandat, Vorstandsklarheit, noch kein Kapital gebunden.', ar: 'الأفضل لـ: التفويض الأول، وضوح المجلس، دون التزام رأسمالي بعد.' },
      featured: false,
      icon: 'diagnostic',
      color: 'blue'
    },
    {
      number: 'II',
      kicker: { en: 'STRATEGY, ARCHITECTURE & GOVERNANCE', de: 'STRATEGIE, ARCHITEKTUR & GOVERNANCE', ar: 'الاستراتيجية والهندسة والحوكمة' },
      title: { en: 'Activate', de: 'Aktivieren', ar: 'التفعيل' },
      note: { en: 'Monthly retainer, scoped to engagement · Recommended once ASSESS is complete', de: 'Monatlicher Retainer, auf das Engagement zugeschnitten · Empfohlen nach Abschluss von ASSESS', ar: 'اشتراك شهري، محدد النطاق حسب التعاقد · موصى به بعد اكتمال مرحلة التقييم' },
      desc: {
        en: 'The enterprise blueprint that turns a validated opportunity into an executable, governed programme.',
        de: 'Der Unternehmens-Blueprint, der eine validierte Chance in ein ausführbares, gesteuertes Programm verwandelt.',
        ar: 'مخطط المؤسسة الذي يحول الفرصة المُتحقق منها إلى برنامج قابل للتنفيذ ومحكوم.'
      },
      items: {
        en: ['3-year AI roadmap design', 'Operating model alignment & change management', 'Regulatory compliance mapping (EU AI Act / UAE, DIFC-10, NIST)'],
        de: ['Gestaltung einer 3-Jahres-KI-Roadmap', 'Ausrichtung des Betriebsmodells & Change Management', 'Mapping der regulatorischen Compliance (EU AI Act / VAE, DIFC-10, NIST)'],
        ar: ['تصميم خارطة طريق للذكاء الاصطناعي لمدة 3 سنوات', 'مواءمة نموذج التشغيل وإدارة التغيير', 'رسم خرائط الامتثال التنظيمي (قانون الذكاء الاصطناعي الأوروبي / الإمارات، DIFC-10، NIST)']
      },
      pillars: { en: ['Pillar II', 'Retainer'], de: ['Säule II', 'Retainer'], ar: ['الركيزة الثانية', 'اشتراك'] },
      tag: { en: 'Best for: organisations with a validated business case who need governance and architecture before delivery.', de: 'Ideal für: Organisationen mit validiertem Business Case, die Governance und Architektur vor der Umsetzung benötigen.', ar: 'الأفضل لـ: المؤسسات التي لديها حالة عمل مُتحقق منها وتحتاج إلى الحوكمة والهندسة قبل التنفيذ.' },
      featured: false,
      icon: 'blueprint',
      color: 'cyan'
    },
    {
      number: 'III',
      kicker: { en: 'ENGINEER AI INTO THE CORE', de: 'KI IM KERN VERANKERN', ar: 'هندسة الذكاء الاصطناعي في الصميم' },
      title: { en: 'Implement', de: 'Umsetzen', ar: 'التنفيذ' },
      note: { en: 'Per 90-day sprint + Metric success fee · Milestone-based', de: 'Pro 90-Tage-Sprint + Metrik-Erfolgshonorar · Meilensteinbasiert', ar: 'لكل سباق 90 يومًا + رسوم نجاح مرتبطة بالمقاييس · قائم على المعالم' },
      desc: {
        en: 'We build in your environment in 90-day sprints, measured against a baseline locked before we start. Fixed fee plus a success fee tied to the metric uplift we deliver — we are paid on outcome, not on hours.',
        de: 'Wir bauen in Ihrer Umgebung in 90-Tage-Sprints, gemessen an einer vor dem Start fixierten Baseline. Festhonorar plus Erfolgshonorar, das an die von uns erzielte Metrik-Steigerung gekoppelt ist — wir werden für das Ergebnis bezahlt, nicht für Stunden.',
        ar: 'نبني في بيئتك على شكل سباقات مدتها 90 يومًا، تُقاس مقابل خط أساس مثبّت قبل أن نبدأ. رسوم ثابتة بالإضافة إلى رسوم نجاح مرتبطة بتحسّن المقاييس الذي نحققه — نتقاضى أجرنا مقابل النتيجة، لا مقابل الساعات.'
      },
      items: {
        en: ['Priority use cases built and deployed to production', 'Measurement against a locked baseline — no unfalsifiable claims', 'Agentic AI governed by TARA-A; vendor-native governance elsewhere', 'Day-90 gate: scale, iterate, or kill'],
        de: ['Priorisierte Anwendungsfälle entwickelt und in Produktion gebracht', 'Messung gegen eine fixierte Baseline — keine unbelegbaren Behauptungen', 'Agentische KI gesteuert durch TARA-A; anbietereigene Governance im Übrigen', 'Tag-90-Gate: skalieren, iterieren oder stoppen'],
        ar: ['بناء حالات الاستخدام ذات الأولوية ونشرها في الإنتاج', 'القياس مقابل خط أساس مثبّت — دون ادعاءات غير قابلة للتحقق', 'ذكاء اصطناعي وكيلي محكوم بـ TARA-A؛ وحوكمة أصلية للمورّد فيما عدا ذلك', 'بوابة اليوم 90: التوسع أو التكرار أو الإيقاف']
      },
      pillars: { en: ['Pillar III', 'Sprint + success fee'], de: ['Säule III', 'Sprint + Erfolgshonorar'], ar: ['الركيزة الثالثة', 'سباق + رسوم نجاح'] },
      tag: { en: 'Best for: organisations ready to move from roadmap to production, willing to commit to a measured 90-day sprint.', de: 'Ideal für: Organisationen, die von der Roadmap zur Produktion übergehen wollen und bereit sind, sich auf einen gemessenen 90-Tage-Sprint einzulassen.', ar: 'الأفضل لـ: المؤسسات الجاهزة للانتقال من خارطة الطريق إلى الإنتاج والمستعدة للالتزام بسباق مُقاس مدته 90 يومًا.' },
      featured: true,
      highlight: 3,
      icon: 'build',
      color: 'cyan'
    },
    {
      number: 'IV',
      kicker: { en: 'MAKE AI PERMANENT, NOT PERIPHERAL', de: 'KI DAUERHAFT MACHEN, NICHT PERIPHER', ar: 'اجعل الذكاء الاصطناعي دائمًا لا هامشيًا' },
      title: { en: 'Embed', de: 'Verankern', ar: 'الترسيخ' },
      note: { en: 'Ongoing monthly retainer · Recommended when scaling beyond first sprints', de: 'Laufender monatlicher Retainer · Empfohlen bei Skalierung über die ersten Sprints hinaus', ar: 'اشتراك شهري مستمر · موصى به عند التوسع بعد السباقات الأولى' },
      desc: {
        en: 'Once a sprint proves value, Embed is how it survives contact with the rest of the organisation — scaled, governed, and run by your own people.',
        de: 'Sobald ein Sprint Wert nachweist, ist Embed der Weg, wie er den Kontakt mit dem Rest der Organisation übersteht — skaliert, gesteuert und von Ihren eigenen Mitarbeitern betrieben.',
        ar: 'بمجرد أن يُثبت السباق قيمته، فإن الترسيخ هو الطريقة التي يصمد بها أمام بقية المؤسسة — مُوسَّعًا ومحكومًا ويُدار بواسطة موظفيك.'
      },
      items: {
        en: ['Scale proven winners org-wide', 'AI literacy and capability building, CAIO+ to all levels', 'Transformation-Office-as-a-Service'],
        de: ['Bewährte Erfolge organisationsweit skalieren', 'KI-Kompetenz und Capability Building, CAIO+ bis auf alle Ebenen', 'Transformation-Office-as-a-Service'],
        ar: ['توسيع النجاحات المُثبَتة على مستوى المؤسسة', 'محو الأمية بالذكاء الاصطناعي وبناء القدرات، من CAIO+ إلى جميع المستويات', 'مكتب التحول كخدمة']
      },
      pillars: { en: ['Pillar IV', 'Retainer'], de: ['Säule IV', 'Retainer'], ar: ['الركيزة الرابعة', 'اشتراك'] },
      tag: { en: 'Best for: organisations with at least one proven 90-day win who want it to become permanent capability.', de: 'Ideal für: Organisationen mit mindestens einem bewährten 90-Tage-Erfolg, der zu dauerhafter Fähigkeit werden soll.', ar: 'الأفضل لـ: المؤسسات التي حققت نجاحًا واحدًا على الأقل خلال 90 يومًا وترغب في تحويله إلى قدرة دائمة.' },
      featured: false,
      icon: 'scale',
      color: 'silver'
    }
  ],
  assurance: {
    title: { en: 'What you can expect', de: 'Was Sie erwarten können', ar: 'ما يمكنك توقعه' },
    desc: {
      en: 'Every engagement begins with a metric baseline and ends with measurable reporting. Scope is explicit. Governance is built in. Accountability is named.',
      de: 'Jedes Engagement beginnt mit einer Metrik-Basis und endet mit messbarer Berichterstattung. Der Umfang ist explizit. Governance ist eingebaut. Verantwortlichkeit ist benannt.',
      ar: 'يبدأ كل تعاقد بخط أساس للمقاييس وينتهي بتقارير قابلة للقياس. النطاق صريح. الحوكمة مدمجة. المسؤولية محددة.'
    },
    items: {
      en: ['Defined metric baseline before work begins', 'Milestone gates aligned to executive governance', 'DACH & UAE delivery fluency — no handoffs'],
      de: ['Definierte Metrik-Basis vor Arbeitsbeginn', 'Meilenstein-Gates ausgerichtet auf Executive Governance', 'DACH & VAE Lieferungsfluss — keine Übergaben'],
      ar: ['خط أساس محدد للمقاييس قبل بدء العمل', 'بوابات معالم متوافقة مع الحوكمة التنفيذية', 'طلاقة التسليم في DACH والإمارات — بدون تسليمات']
    },
    ctaNote: {
      en: 'To receive a tailored proposal aligned to your scale and risk profile:',
      de: 'Um ein maßgeschneidertes Angebot zu erhalten, das auf Ihre Größe und Ihr Risikoprofil abgestimmt ist:',
      ar: 'للحصول على عرض مخصص يتوافق مع حجمك وملف المخاطر الخاص بك:'
    },
    ctaButton: { en: 'Talk to us', de: 'Sprechen Sie mit uns', ar: 'تحدث معنا' },
    ctaFine: {
      en: "We'll recommend the smallest credible starting point.",
      de: 'Wir empfehlen den kleinsten glaubwürdigen Ausgangspunkt.',
      ar: 'سنوصي بأصغر نقطة بداية معقولة.'
    }
  }
};

const CardIcon = ({ type }: { type: string }) => {
  const icons: Record<string, JSX.Element> = {
    diagnostic: (
      <svg viewBox="0 0 24 24" className="w-6 h-6">
        <path d="M4 7h16M4 12h10M4 17h16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
      </svg>
    ),
    blueprint: (
      <svg viewBox="0 0 24 24" className="w-6 h-6">
        <path d="M4 20V8m0 0l4-4 4 4M4 8h8M14 20V4h6v16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    build: (
      <svg viewBox="0 0 24 24" className="w-6 h-6">
        <path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18v3h3l6.3-6.3a4 4 0 0 0 5.4-5.4l-2.3 2.3-2-2 2.3-2.3z" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    scale: (
      <svg viewBox="0 0 24 24" className="w-6 h-6">
        <path d="M12 2v4m0 12v4M4.2 4.2l2.8 2.8m10 10l2.8 2.8M2 12h4m12 0h4M4.2 19.8l2.8-2.8m10-10l2.8-2.8" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
        <path d="M8 12a4 4 0 1 0 8 0a4 4 0 1 0-8 0" fill="none" stroke="currentColor" strokeWidth="1.8"/>
      </svg>
    )
  };
  return icons[type] || icons.diagnostic;
};

export default function PricingPage() {
  const { language } = useLanguage();
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const isRTL = language === 'ar';

  const getText = (obj: Record<string, string | string[]>) => {
    return obj[language] || obj.en;
  };

  const getCardBorderColor = (color: string, featured: boolean) => {
    if (featured) return 'border-cyan-500/50 bg-gradient-to-br from-cyan-500/10 to-blue-500/5';
    if (color === 'blue') return 'border-blue-500/30 hover:border-blue-500/50';
    if (color === 'silver') return 'border-gray-400/30 hover:border-gray-400/50';
    return 'border-cyan-600/30 hover:border-cyan-500/50';
  };

  const getIconBgColor = (color: string) => {
    if (color === 'cyan') return 'bg-gradient-to-br from-cyan-500 to-blue-600';
    if (color === 'blue') return 'bg-gradient-to-br from-blue-500 to-blue-700';
    if (color === 'silver') return 'bg-gradient-to-br from-gray-400 to-gray-600';
    return 'bg-gradient-to-br from-blue-500 to-cyan-500';
  };

  return (
    <>
    <section
      className="min-h-screen bg-gradient-to-b from-[#0a0e1a] via-[#0f1629] to-[#0a0e1a] text-white py-20 md:py-24"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div className="w-[92%] max-w-7xl mx-auto">
        {/* Header */}
        <motion.header
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-10"
        >
          <p className="text-xs tracking-[0.2em] uppercase text-cyan-400 mb-3 font-medium">
            {getText(pricingContent.eyebrow) as string}
          </p>
          <h1 className="text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-white via-cyan-200 to-blue-300 bg-clip-text text-transparent">
            {getText(pricingContent.title) as string}
          </h1>
          <p className="text-gray-400 max-w-3xl leading-relaxed text-lg">
            {getText(pricingContent.subtitle) as string}
          </p>
        </motion.header>

        {/* Journey Line — 4 pillars */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex items-center gap-3 my-8 flex-wrap"
        >
          {(getText(pricingContent.journey) as string[]).map((step, i, arr) => (
            <div key={i} className="flex items-center gap-3">
              <span className="inline-flex items-center border border-cyan-500/30 bg-cyan-500/10 px-4 py-2 rounded-full text-sm text-cyan-300 font-medium">
                {step}
              </span>
              {i < arr.length - 1 && (
                <div className="w-10 h-0.5 bg-gradient-to-r from-cyan-500/50 to-blue-500/30" />
              )}
            </div>
          ))}
        </motion.div>

        {/* Blindspot — optional entry point banner */}
        <motion.article
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="relative overflow-hidden rounded-2xl p-6 md:p-7 border border-dashed border-cyan-400/40 bg-[#0f1629]/70 backdrop-blur mb-8"
        >
          <div className={`flex flex-col md:flex-row gap-5 md:items-start ${isRTL ? 'md:flex-row-reverse text-right' : ''}`}>
            <div className="flex-shrink-0">
              <span className="inline-flex items-center gap-2 text-[11px] tracking-[0.15em] uppercase text-cyan-300 border border-cyan-400/40 bg-cyan-500/10 px-3 py-1.5 rounded-full font-semibold">
                {getText(pricingContent.blindspot.kicker) as string}
              </span>
            </div>
            <div className="flex-1">
              <h3 className="text-xl md:text-2xl font-bold text-white">
                {getText(pricingContent.blindspot.title) as string}
              </h3>
              <p className="text-cyan-400 text-sm mt-1 font-medium">
                {getText(pricingContent.blindspot.note) as string}
              </p>
              <p className="mt-3 text-gray-300 leading-relaxed max-w-3xl">
                {getText(pricingContent.blindspot.desc) as string}
              </p>
              <ul className={`mt-4 space-y-2 text-gray-300 ${isRTL ? 'pr-5' : 'pl-5'}`}>
                {(getText(pricingContent.blindspot.items) as string[]).map((item, i) => (
                  <li key={i} className="list-disc leading-snug">{item}</li>
                ))}
              </ul>
              <p className="mt-4 text-sm text-gray-400 italic">
                {getText(pricingContent.blindspot.tag) as string}
              </p>
            </div>
          </div>
        </motion.article>

        {/* Cards Grid — 4 pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {pricingContent.cards.map((card, index) => (
            <motion.article
              key={index}
              initial={{ opacity: 0, y: 25 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
              className={`relative overflow-hidden rounded-2xl p-6 border bg-[#111827]/80 backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-cyan-500/10 ${getCardBorderColor(card.color, card.featured)}`}
            >
              {card.featured && (
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-400" />
              )}

              {/* Card Top */}
              <div className={`flex gap-4 items-start ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className={`w-12 h-12 rounded-xl grid place-items-center text-white flex-shrink-0 ${getIconBgColor(card.color)}`}>
                  <CardIcon type={card.icon} />
                </div>
                <div className={`flex-1 ${isRTL ? 'text-right' : ''}`}>
                  <div className={`flex items-center gap-2 mb-1 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <span className="text-xs font-bold text-cyan-400/80">PILLAR {card.number}</span>
                    <span className="text-xs tracking-[0.12em] uppercase text-gray-400 font-medium">
                      {getText(card.kicker) as string}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-white">
                    {getText(card.title) as string}
                  </h3>
                  <p className="text-cyan-400 text-sm mt-1 font-medium">
                    {getText(card.note) as string}
                  </p>
                </div>
              </div>

              {/* Description */}
              <p className="mt-4 text-gray-300 leading-relaxed">
                {getText(card.desc) as string}
              </p>

              {/* Items List */}
              <ul className={`mt-4 space-y-2 text-gray-300 ${isRTL ? 'pr-5' : 'pl-5'}`}>
                {(getText(card.items) as string[]).map((item, i) => (
                  <li
                    key={i}
                    className={`list-disc leading-snug ${(card as any).highlight === i ? 'font-bold text-white' : ''}`}
                  >
                    {item}
                  </li>
                ))}
              </ul>

              {/* Pillars / fee-model chips */}
              <div className="mt-5 flex flex-wrap gap-2">
                {(getText(card.pillars) as string[]).map((pill, i) => (
                  <span
                    key={i}
                    className="text-xs text-cyan-300 border border-cyan-500/30 bg-cyan-500/10 px-3 py-1.5 rounded-full font-medium"
                  >
                    {pill}
                  </span>
                ))}
              </div>

              {/* Footer Tag */}
              <div className="mt-5 pt-4 border-t border-gray-700/50">
                <span className="text-sm text-gray-400">
                  {getText(card.tag) as string}
                </span>
              </div>
            </motion.article>
          ))}
        </div>

        {/* Assurance / CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="grid grid-cols-1 lg:grid-cols-[1.2fr_0.8fr] gap-6 bg-gradient-to-br from-[#1a2332] to-[#111827] border border-cyan-500/20 rounded-2xl p-6 md:p-8"
        >
          {/* Left: What you can expect */}
          <div className={isRTL ? 'text-right' : ''}>
            <h3 className="text-xl font-bold text-white mb-3">
              {getText(pricingContent.assurance.title) as string}
            </h3>
            <p className="text-gray-400 leading-relaxed mb-4">
              {getText(pricingContent.assurance.desc) as string}
            </p>
            <ul className={`space-y-2 text-gray-300 ${isRTL ? 'pr-5' : 'pl-5'}`}>
              {(getText(pricingContent.assurance.items) as string[]).map((item, i) => (
                <li key={i} className="list-disc leading-snug">{item}</li>
              ))}
            </ul>
          </div>

          {/* Right: CTA */}
          <div className={`flex flex-col justify-center gap-4 lg:border-l lg:border-gray-700/50 lg:pl-6 ${isRTL ? 'lg:border-l-0 lg:border-r lg:pr-6 lg:pl-0 text-right' : ''}`}>
            <p className="text-gray-400 leading-snug">
              {getText(pricingContent.assurance.ctaNote) as string}
            </p>
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold px-8 w-max shadow-lg shadow-cyan-500/25"
            >
              <Link href="/contact">
                {getText(pricingContent.assurance.ctaButton) as string}
              </Link>
            </Button>
            <p className="text-sm text-gray-500">
              {getText(pricingContent.assurance.ctaFine) as string}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
    <FaqSection ids={['how-much-cost', 'how-outcome-pricing', 'what-roi-as-service']} />
    </>
  );
}
