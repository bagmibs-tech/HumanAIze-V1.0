
'use client';

import { useLanguage } from '@/lib/language-context';
import { getPageContent } from '@/lib/content';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import HeroSection from '@/components/sections/hero-section';
import TrustStrip from '@/components/sections/trust-strip';
import ProblemDifferentiation from '@/components/sections/problem-differentiation';
import AboutSnapshot from '@/components/sections/about-snapshot';
import ServicesOverview from '@/components/sections/services-overview';
import HowWeWorkTeaser from '@/components/sections/how-we-work-teaser';
import PricingStrategy from '@/components/sections/pricing-strategy';
import CaseStudiesHighlight from '@/components/sections/case-studies-highlight';
import FounderSnapshot from '@/components/sections/founder-snapshot';

import TrustedBy from '@/components/sections/trusted-by';
import IndustriesServed from '@/components/sections/industries-served';
import FinalCTA from '@/components/sections/final-cta';
import FaqSection from '@/components/sections/faq-section';
import NewsletterSignup from '@/components/newsletter-signup';

export default function HomePage() {
  const { language } = useLanguage();
  const pageData: any = getPageContent('homepage', language) || getPageContent('homepage', 'en');

  const sections = pageData?.sections || [];
  
  const getSection = (id: string) => sections?.find?.((s: any) => s?.section_id === id);

  return (
    <div className="w-full">
      <HeroSection data={getSection('hero')} language={language} />
      <TrustStrip data={getSection('trust_strip')} language={language} />
      <ProblemDifferentiation language={language} />
      <AboutSnapshot data={getSection('about_snapshot')} language={language} />
      <ServicesOverview />
      <HowWeWorkTeaser data={getSection('how_we_work_teaser')} language={language} />
      <PricingStrategy data={getSection('pricing_strategy')} language={language} />
      <CaseStudiesHighlight data={getSection('case_studies_highlight')} language={language} />
      <FounderSnapshot data={getSection('founder_snapshot')} language={language} />
      <NewsletterSignup language={language} />
      <FaqSection ids={['what-is-humanaize', 'how-different', 'who-works-with', 'how-get-started']} />
      <FinalCTA data={getSection('final_cta')} language={language} />
      <TrustedBy language={language} />
      <IndustriesServed language={language} />
    </div>
  );
}
