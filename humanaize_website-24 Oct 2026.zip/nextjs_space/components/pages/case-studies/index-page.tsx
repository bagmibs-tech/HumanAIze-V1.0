'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '@/lib/language-context';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const pageContent = {
  en: {
    title: 'Case Studies',
    subtitle: 'Proven ROI across DACH & UAE use cases in manufacturing, logistics, healthcare, and more',
    provenImpact: 'Proven Impact Across Industries',
    challenge: 'Challenge',
    solution: 'Solution',
    impact: 'Impact',
    readMore: 'Read Full Case Study',
    cards: [
      {
        title: 'Manufacturing (DACH)',
        description: 'AI-Driven Quality Assurance',
        metrics: [
          { value: '15pp+', label: 'defect detection (80% → 95%)' },
          { value: '30%', label: 'throughput gain' },
          { value: '100%', label: 'ERP traceability for audits' }
        ]
      },
      {
        title: 'Logistics (DACH & UAE)',
        description: 'AI-Powered AGV',
        metrics: [
          { value: '20–40%', label: 'manpower capacity freed' },
          { value: '100%', label: 'automated material flow' },
          { value: 'Real-time', label: 'order scheduling' }
        ]
      },
      {
        title: 'Insurance & Healthcare',
        description: 'Medical Forms AI',
        metrics: [
          { value: '92%', label: 'extraction accuracy' },
          { value: '<1 day', label: 'turnaround (from 5–7 days)' },
          { value: '50%', label: 'cost reduction' }
        ]
      }
    ],
    detailedCases: [
      {
        title: 'Automotive Manufacturing | AI-Driven Quality Assurance',
        challenge: 'Inconsistent quality, manual inspections, and limited real-time traceability across production lines.',
        solution: 'AI-powered quality inspection integrated with ERP and production systems.',
        impacts: ['95% defect detection (up from 80%)', '30% throughput increase', 'Mid six-figure annual savings'],
        link: '/case-studies/automotive-quality-assurance'
      },
      {
        title: 'Banking | AI-Powered Invoice & Compliance Automation',
        challenge: 'Slow, manual invoice processing with high audit effort and compliance risk.',
        solution: 'AI document and invoice copilot with built-in audit trails and governance.',
        impacts: ['80% faster processing', '20–35% cost avoidance', 'Real-time audit readiness'],
        link: '/case-studies/banking-invoice-automation'
      },
      {
        title: 'Energy & Utilities | Predictive Maintenance & Asset Intelligence',
        challenge: 'Reactive maintenance, unplanned outages, and rising operational costs.',
        solution: 'AI-based predictive maintenance and asset intelligence platform.',
        impacts: ['20–30% maintenance cost reduction', '~25% fewer outages', 'Improved regulatory performance'],
        link: '/case-studies/energy-predictive-maintenance'
      },
      {
        title: 'Healthcare | AI-Based Medical Document Automation',
        challenge: 'Manual processing of medical forms causing long turnaround times and high admin effort.',
        solution: 'AI-driven medical document extraction and workflow automation.',
        impacts: ['<1-day turnaround (from 5–7 days)', '~50% cost reduction', '92% extraction accuracy'],
        link: '/case-studies/healthcare-document-automation'
      }
    ]
  },
  de: {
    title: 'Fallstudien',
    subtitle: 'Nachgewiesener ROI in DACH & VAE Anwendungsfällen in Fertigung, Logistik, Gesundheitswesen und mehr',
    provenImpact: 'Nachgewiesene Wirkung in allen Branchen',
    challenge: 'Herausforderung',
    solution: 'Lösung',
    impact: 'Auswirkung',
    readMore: 'Vollständige Fallstudie lesen',
    cards: [
      {
        title: 'Fertigung (DACH)',
        description: 'KI-gesteuerte Qualitätssicherung',
        metrics: [
          { value: '+15pp', label: 'Fehlererkennung (80% → 95%)' },
          { value: '30%', label: 'Durchsatzsteigerung' },
          { value: '100%', label: 'ERP-Rückverfolgbarkeit für Audits' }
        ]
      },
      {
        title: 'Logistik (DACH & VAE)',
        description: 'KI-gesteuerte FTS',
        metrics: [
          { value: '20–40%', label: 'Personalkapazität freigesetzt' },
          { value: '100%', label: 'automatisierter Materialfluss' },
          { value: 'Echtzeit', label: 'Auftragsplanung' }
        ]
      },
      {
        title: 'Versicherung & Gesundheitswesen',
        description: 'Medizinische Formulare KI',
        metrics: [
          { value: '92%', label: 'Extraktionsgenauigkeit' },
          { value: '<1 Tag', label: 'Bearbeitungszeit (von 5–7 Tagen)' },
          { value: '50%', label: 'Kostenreduzierung' }
        ]
      }
    ],
    detailedCases: [
      {
        title: 'Automobilfertigung | KI-gesteuerte Qualitätssicherung',
        challenge: 'Inkonsistente Qualität, manuelle Inspektionen und begrenzte Echtzeit-Rückverfolgbarkeit in Produktionslinien.',
        solution: 'KI-gestützte Qualitätsprüfung integriert mit ERP- und Produktionssystemen.',
        impacts: ['95% Fehlererkennung (von 80%)', '30% Durchsatzsteigerung', 'Sechsstellige jährliche Einsparungen'],
        link: '/case-studies/automotive-quality-assurance'
      },
      {
        title: 'Bankwesen | KI-gestützte Rechnungs- und Compliance-Automatisierung',
        challenge: 'Langsame, manuelle Rechnungsbearbeitung mit hohem Prüfungsaufwand und Compliance-Risiko.',
        solution: 'KI-Dokumenten- und Rechnungs-Copilot mit integrierten Audit-Trails und Governance.',
        impacts: ['80% schnellere Verarbeitung', '20–35% Kostenvermeidung', 'Echtzeit-Audit-Bereitschaft'],
        link: '/case-studies/banking-invoice-automation'
      },
      {
        title: 'Energie & Versorgung | Vorausschauende Wartung & Asset Intelligence',
        challenge: 'Reaktive Wartung, ungeplante Ausfälle und steigende Betriebskosten.',
        solution: 'KI-basierte vorausschauende Wartung und Asset-Intelligence-Plattform.',
        impacts: ['20–30% Wartungskostenreduktion', '~25% weniger Ausfälle', 'Verbesserte regulatorische Leistung'],
        link: '/case-studies/energy-predictive-maintenance'
      },
      {
        title: 'Gesundheitswesen | KI-basierte medizinische Dokumentenautomatisierung',
        challenge: 'Manuelle Bearbeitung medizinischer Formulare mit langen Bearbeitungszeiten und hohem Verwaltungsaufwand.',
        solution: 'KI-gesteuerte medizinische Dokumentenextraktion und Workflow-Automatisierung.',
        impacts: ['<1 Tag Bearbeitungszeit (von 5–7 Tagen)', '~50% Kostenreduzierung', '92% Extraktionsgenauigkeit'],
        link: '/case-studies/healthcare-document-automation'
      }
    ]
  },
  ar: {
    title: 'دراسات الحالة',
    subtitle: 'عائد استثمار مثبت عبر حالات استخدام DACH والإمارات في التصنيع والخدمات اللوجستية والرعاية الصحية والمزيد',
    provenImpact: 'تأثير مثبت عبر الصناعات',
    challenge: 'التحدي',
    solution: 'الحل',
    impact: 'التأثير',
    readMore: 'اقرأ دراسة الحالة الكاملة',
    cards: [
      {
        title: 'التصنيع (DACH)',
        description: 'ضمان الجودة بالذكاء الاصطناعي',
        metrics: [
          { value: '+15 نقطة', label: 'اكتشاف العيوب (80% ← 95%)' },
          { value: '30%', label: 'زيادة الإنتاجية' },
          { value: '100%', label: 'تتبع ERP للتدقيق' }
        ]
      },
      {
        title: 'الخدمات اللوجستية (DACH والإمارات)',
        description: 'مركبات موجهة آلياً بالذكاء الاصطناعي',
        metrics: [
          { value: '20-40%', label: 'تحرير قدرة القوى العاملة' },
          { value: '100%', label: 'تدفق المواد الآلي' },
          { value: 'فوري', label: 'جدولة الطلبات' }
        ]
      },
      {
        title: 'التأمين والرعاية الصحية',
        description: 'ذكاء اصطناعي للنماذج الطبية',
        metrics: [
          { value: '92%', label: 'دقة الاستخراج' },
          { value: 'أقل من يوم', label: 'وقت المعالجة (من 5-7 أيام)' },
          { value: '50%', label: 'تخفيض التكلفة' }
        ]
      }
    ],
    detailedCases: [
      {
        title: 'تصنيع السيارات | ضمان الجودة بالذكاء الاصطناعي',
        challenge: 'جودة غير متسقة، وعمليات فحص يدوية، وتتبع محدود في الوقت الفعلي عبر خطوط الإنتاج.',
        solution: 'فحص الجودة المدعوم بالذكاء الاصطناعي المتكامل مع أنظمة ERP والإنتاج.',
        impacts: ['95% اكتشاف العيوب (من 80%)', '30% زيادة في الإنتاجية', 'وفورات سنوية بستة أرقام'],
        link: '/case-studies/automotive-quality-assurance'
      },
      {
        title: 'البنوك | أتمتة الفواتير والامتثال بالذكاء الاصطناعي',
        challenge: 'معالجة الفواتير اليدوية البطيئة مع جهد تدقيق عالٍ ومخاطر امتثال.',
        solution: 'مساعد ذكاء اصطناعي للمستندات والفواتير مع مسارات تدقيق وحوكمة مدمجة.',
        impacts: ['80% معالجة أسرع', '20-35% تجنب التكاليف', 'جاهزية التدقيق في الوقت الفعلي'],
        link: '/case-studies/banking-invoice-automation'
      },
      {
        title: 'الطاقة والمرافق | الصيانة التنبؤية وذكاء الأصول',
        challenge: 'صيانة تفاعلية، وانقطاعات غير مخطط لها، وارتفاع تكاليف التشغيل.',
        solution: 'منصة صيانة تنبؤية وذكاء أصول قائمة على الذكاء الاصطناعي.',
        impacts: ['20-30% تخفيض تكاليف الصيانة', '~25% انقطاعات أقل', 'أداء تنظيمي محسّن'],
        link: '/case-studies/energy-predictive-maintenance'
      },
      {
        title: 'الرعاية الصحية | أتمتة المستندات الطبية بالذكاء الاصطناعي',
        challenge: 'المعالجة اليدوية للنماذج الطبية تسبب أوقات معالجة طويلة وجهد إداري عالٍ.',
        solution: 'استخراج المستندات الطبية وأتمتة سير العمل بالذكاء الاصطناعي.',
        impacts: ['أقل من يوم وقت المعالجة (من 5-7 أيام)', '~50% تخفيض التكلفة', '92% دقة الاستخراج'],
        link: '/case-studies/healthcare-document-automation'
      }
    ]
  }
};

export default function CaseStudies() {
  const { language } = useLanguage();
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const content = pageContent[language as keyof typeof pageContent] || pageContent.en;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            {content.title}
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            {content.subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {content.cards.map((card, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="shadow-xl hover:shadow-2xl transition-shadow h-full">
                <CardHeader>
                  <CardTitle className="text-xl">{card.title}</CardTitle>
                  <CardDescription>{card.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {card.metrics.map((metric, mIndex) => (
                      <div key={mIndex} className={`border-l-4 ${index === 1 ? 'border-orange-600' : 'border-blue-600'} pl-4`}>
                        <div className={`text-2xl font-bold ${index === 1 ? 'text-orange-600' : 'text-blue-600'}`}>
                          {metric.value}
                        </div>
                        <div className="text-sm text-gray-600">{metric.label}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Proven Impact Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="py-16 bg-gradient-to-b from-[#0f172a] to-[#1e293b] rounded-3xl mb-12"
        >
          <div className="px-6 lg:px-12">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 bg-gradient-to-r from-purple-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent">
              {content.provenImpact}
            </h2>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {content.detailedCases.map((caseStudy, index) => (
                <div
                  key={index}
                  className="bg-[#1a2332] rounded-2xl p-6 border border-gray-700/50 hover:border-cyan-500/50 transition-all"
                >
                  <h3 className="text-xl font-bold text-white mb-4">
                    {caseStudy.title}
                  </h3>
                  
                  <div className="space-y-4">
                    <div>
                      <span className="text-cyan-400 font-semibold text-sm uppercase tracking-wide">
                        {content.challenge}
                      </span>
                      <p className="text-gray-300 mt-1">{caseStudy.challenge}</p>
                    </div>
                    
                    <div>
                      <span className="text-cyan-400 font-semibold text-sm uppercase tracking-wide">
                        {content.solution}
                      </span>
                      <p className="text-gray-300 mt-1">{caseStudy.solution}</p>
                    </div>
                    
                    <div>
                      <span className="text-cyan-400 font-semibold text-sm uppercase tracking-wide">
                        {content.impact}
                      </span>
                      <ul className="mt-2 space-y-1">
                        {caseStudy.impacts.map((impact, i) => (
                          <li key={i} className="flex items-center gap-2 text-gray-300">
                            <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                            {impact}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <Button
                    asChild
                    variant="ghost"
                    className="mt-4 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10 p-0"
                  >
                    <Link href={caseStudy.link}>
                      {content.readMore}
                      <ArrowRight className="ml-2" size={16} />
                    </Link>
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
