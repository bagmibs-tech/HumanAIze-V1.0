'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useLanguage } from '@/lib/language-context';
import FaqSection from '@/components/sections/faq-section';

const pageContent = {
  eyebrow: {
    en: 'OUR APPROACH',
    de: 'WIE WIR ARBEITEN',
    ar: 'نهجنا'
  },
  title: {
    en: 'Our 5-Step Delivery Framework',
    de: 'Unser 5-Schritte-Umsetzungsrahmen',
    ar: 'إطار التنفيذ المكون من 5 خطوات'
  },
  subtitle: {
    en: 'From executive alignment to measurable AI ROI — governed, orchestrated, and accountable across DACH & UAE.',
    de: 'Von der Führungsabstimmung bis zum messbaren KI-ROI — gesteuert, orchestriert und verantwortlich in DACH & VAE.',
    ar: 'من التوافق التنفيذي إلى عائد استثمار ذكاء اصطناعي قابل للقياس — محكوم ومنسق وخاضع للمساءلة في DACH والإمارات.'
  },
  blindspot: {
    en: "Before the framework below begins: if you don't yet have a validated AI opportunity, Blindspot builds the business case first.",
    de: 'Bevor der folgende Rahmen beginnt: Wenn Sie noch keine validierte KI-Chance haben, erstellt Blindspot zuerst den Business Case.',
    ar: '\u0642\u0628\u0644 \u0623\u0646 \u064a\u0628\u062f\u0623 \u0627\u0644\u0625\u0637\u0627\u0631 \u0623\u062f\u0646\u0627\u0647: \u0625\u0630\u0627 \u0644\u0645 \u062a\u0643\u0646 \u0644\u062f\u064a\u0643 \u0628\u0639\u062f \u0641\u0631\u0635\u0629 \u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064a \u0645\u062a\u062d\u0642\u0642 \u0645\u0646\u0647\u0627\u060c \u064a\u0642\u0648\u0645 Blindspot \u0628\u0628\u0646\u0627\u0621 \u062f\u0631\u0627\u0633\u0629 \u0627\u0644\u062c\u062f\u0648\u0649 \u0623\u0648\u0644\u0627\u064b.'
  },
  processNotePrefix: {
    en: 'This is the delivery process inside the four stages on our ',
    de: 'Dies ist der Umsetzungsprozess innerhalb der vier Stufen auf unserer Seite ',
    ar: 'هذا هو عملية التنفيذ داخل المراحل الأربع على صفحة '
  },
  processNoteServices: { en: 'Services', de: 'Leistungen', ar: 'الخدمات' },
  processNoteMid: {
    en: ' page, and how each is ',
    de: ', und wie jede ',
    ar: '، وكيف تُسعّر كل منها ضمن '
  },
  processNotePriced: { en: 'priced', de: 'bepreist wird', ar: 'التسعير' },
  processNoteSuffix: { en: '.', de: '.', ar: '.' },
  blindspotCta: {
    en: 'Learn more',
    de: 'Mehr erfahren',
    ar: '\u0627\u0639\u0631\u0641 \u0627\u0644\u0645\u0632\u064a\u062f'
  },
  steps: [
    {
      number: '01',
      pillarTag: { en: 'part of Assess', de: 'Teil von Assess', ar: '\u062c\u0632\u0621 \u0645\u0646 Assess' },
      title: {
        en: 'Discovery & Alignment',
        de: 'Entdeckung & Abstimmung',
        ar: 'الاكتشاف والتنسيق'
      },
      description: {
        en: 'Define scope, risk boundaries, and measurable metric baseline.',
        de: 'Umfang, Risikogrenzen und messbare Metrik-Baselines definieren.',
        ar: 'تحديد النطاق وحدود المخاطر وخط الأساس للمقاييس القابلة للقياس.'
      },
      items: {
        en: ['Executive interviews', 'Metric & P&L mapping', 'Regulatory context profiling', 'Initial tech & data landscape scan'],
        de: ['Führungsinterviews', 'Metrik- & P&L-Mapping', 'Regulatorische Kontextanalyse', 'Erste Technologie- & Datenlandschaftsanalyse'],
        ar: ['مقابلات تنفيذية', 'رسم خرائط المقاييس والأرباح والخسائر', 'تحليل السياق التنظيمي', 'المسح الأولي للتكنولوجيا والبيانات']
      }
    },
    {
      number: '02',
      pillarTag: { en: 'part of Assess', de: 'Teil von Assess', ar: '\u062c\u0632\u0621 \u0645\u0646 Assess' },
      title: {
        en: 'Readiness & Prioritisation',
        de: 'Bereitschaft & Priorisierung',
        ar: 'الجاهزية وتحديد الأولويات'
      },
      description: {
        en: 'Identify highest-impact initiatives with defensible ROI logic.',
        de: 'Initiativen mit höchster Wirkung und nachweisbarer ROI-Logik identifizieren.',
        ar: 'تحديد المبادرات ذات التأثير الأعلى مع منطق عائد استثمار قابل للدفاع.'
      },
      items: {
        en: ['AI maturity scoring', 'Impact × feasibility matrix', 'Risk-tier classification', '90-day ROI modelling'],
        de: ['KI-Reifebewertung', 'Wirkungs- × Machbarkeitsmatrix', 'Risikoklassifizierung', '90-Tage-ROI-Modellierung'],
        ar: ['تسجيل نضج الذكاء الاصطناعي', 'مصفوفة التأثير × الجدوى', 'تصنيف مستوى المخاطر', 'نمذجة عائد الاستثمار لـ 90 يومًا']
      }
    },
    {
      number: '03',
      pillarTag: { en: '= Activate', de: '= Activate', ar: '= Activate' },
      title: {
        en: 'Strategy & Blueprinting',
        de: 'Strategie & Konzeption',
        ar: 'الاستراتيجية والتخطيط'
      },
      description: {
        en: 'Design architecture, governance, and operating model.',
        de: 'Architektur, Governance und Betriebsmodell gestalten.',
        ar: 'تصميم البنية والحوكمة ونموذج التشغيل.'
      },
      items: {
        en: ['3-year transformation roadmap', 'Operating model & decision rights', 'Data & cloud architecture', 'Governance & compliance framework'],
        de: ['3-Jahres-Transformations-Roadmap', 'Betriebsmodell & Entscheidungsrechte', 'Daten- & Cloud-Architektur', 'Governance- & Compliance-Framework'],
        ar: ['خارطة طريق التحول لمدة 3 سنوات', 'نموذج التشغيل وحقوق القرار', 'بنية البيانات والسحابة', 'إطار الحوكمة والامتثال']
      }
    },
    {
      number: '04',
      pillarTag: { en: '= Implement', de: '= Implement', ar: '= Implement' },
      title: {
        en: 'Execution & Orchestration',
        de: 'Umsetzung & Orchestrierung',
        ar: 'التنفيذ والتنسيق'
      },
      description: {
        en: 'Deliver production-grade systems with metric tracking.',
        de: 'Produktionsreife Systeme mit Metrik-Tracking liefern.',
        ar: 'تقديم أنظمة جاهزة للإنتاج مع تتبع المقاييس.'
      },
      items: {
        en: ['MVP deployment (6–12 weeks)', 'SAP & cloud integration', 'AI function rollout', 'Board metric reporting'],
        de: ['MVP-Bereitstellung (6–12 Wochen)', 'SAP- & Cloud-Integration', 'KI-Funktionseinführung', 'Vorstandsberichterstattung'],
        ar: ['نشر MVP (6-12 أسبوع)', 'تكامل SAP والسحابة', 'إطلاق وظائف الذكاء الاصطناعي', 'تقارير المقاييس لمجلس الإدارة']
      }
    },
    {
      number: '05',
      pillarTag: { en: '= Embed', de: '= Embed', ar: '= Embed' },
      title: {
        en: 'Embed, Measure & Scale',
        de: 'Verankern, Messen & Skalieren',
        ar: 'التضمين والقياس والتوسع'
      },
      description: {
        en: 'Institutionalise adoption and internal capability.',
        de: 'Akzeptanz und interne Fähigkeiten institutionalisieren.',
        ar: 'إضفاء الطابع المؤسسي على التبني والقدرات الداخلية.'
      },
      items: {
        en: ['Executive AI coaching', 'Capability building (hybrid / internal)', 'Adoption governance', 'Continuous ROI dashboards'],
        de: ['Executive KI-Coaching', 'Kompetenzaufbau (hybrid / intern)', 'Adoptionssteuerung', 'Kontinuierliche ROI-Dashboards'],
        ar: ['تدريب الذكاء الاصطناعي التنفيذي', 'بناء القدرات (هجين / داخلي)', 'حوكمة التبني', 'لوحات معلومات ROI المستمرة']
      },
      highlight: 1 // Index of item to highlight
    }
  ],
  visualLabels: {
    en: ['Discovery', 'Prioritise', 'Blueprint', 'Execute', 'Scale'],
    de: ['Entdecken', 'Priorisieren', 'Konzipieren', 'Umsetzen', 'Skalieren'],
    ar: ['الاكتشاف', 'الترتيب', 'التخطيط', 'التنفيذ', 'التوسع']
  },
  benchmarks: [
    {
      value: { en: '90 Days', de: '90 Tage', ar: '90 يومًا' },
      label: { en: 'to measurable ROI', de: 'bis messbarer ROI', ar: 'لعائد استثمار قابل للقياس' }
    },
    {
      value: { en: 'Governed', de: 'Gesteuert', ar: 'محكوم' },
      label: { en: 'risk & compliance', de: 'Risiko & Compliance', ar: 'المخاطر والامتثال' }
    },
    {
      value: { en: 'Accountable', de: 'Verantwortlich', ar: 'مسؤول' },
      label: { en: 'single-owner delivery', de: 'Einzelverantwortliche Lieferung', ar: 'تسليم بمسؤول واحد' }
    }
  ]
};

export default function HowWeWorkPage() {
  const { language } = useLanguage();
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const isRTL = language === 'ar';

  const getText = (obj: Record<string, string>) => obj[language] || obj.en;

  return (
    <>
    <section 
      className="bg-[#0B0F14] py-20 md:py-24 text-[#E5E9EF]"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div className="w-[90%] max-w-7xl mx-auto">
        {/* Header */}
        <motion.header
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-12 md:mb-16"
        >
          <p className="text-xs tracking-[2px] text-[#8FA3B8] mb-3">
            {getText(pageContent.eyebrow)}
          </p>
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">
            {getText(pageContent.title)}
          </h1>
          <p className="text-[#AAB4BF] max-w-3xl text-lg">
            {getText(pageContent.subtitle)}
          </p>
          <p className="text-[#8FA3B8] max-w-3xl text-base mt-3">
            {getText(pageContent.processNotePrefix)}
            <a href="/services" className="text-[#00AEEF] hover:underline">{getText(pageContent.processNoteServices)}</a>
            {getText(pageContent.processNoteMid)}
            <a href="/pricing" className="text-[#00AEEF] hover:underline">{getText(pageContent.processNotePriced)}</a>
            {getText(pageContent.processNoteSuffix)}
          </p>
        </motion.header>

        {/* Blindspot Callout */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.15 }}
          className={`mb-10 rounded-2xl border border-dashed border-[#00AEEF]/40 bg-[#00AEEF]/5 p-5 md:p-6 flex flex-col sm:flex-row sm:items-center gap-4 ${isRTL ? 'sm:flex-row-reverse text-right' : ''}`}
        >
          <div className="flex-shrink-0">
            <span className="inline-flex items-center rounded-full bg-[#00AEEF]/15 text-[#00AEEF] text-xs font-semibold tracking-wide px-3 py-1">BLINDSPOT</span>
          </div>
          <p className="text-[#C7D0D9] text-sm md:text-base flex-1">
            {getText(pageContent.blindspot)}
          </p>
          <a href="/services" className="flex-shrink-0 inline-flex items-center gap-1 text-[#00AEEF] font-semibold text-sm hover:underline">
            {getText(pageContent.blindspotCta)} {isRTL ? '\u2190' : '\u2192'}
          </a>
        </motion.div>

        {/* Grid: Steps + Visual */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Steps Column */}
          <div className="lg:col-span-7 space-y-5">
            {pageContent.steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, x: isRTL ? 30 : -30 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.1 * index }}
                className="bg-[#121821] border border-white/5 rounded-2xl p-6 hover:border-[#00AEEF] hover:shadow-[0_0_18px_rgba(0,174,239,0.2)] transition-all duration-200"
              >
                {/* Step Top */}
                <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className="bg-[#00AEEF] text-black font-bold w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0">
                    {step.number}
                  </div>
                  <div className={isRTL ? 'text-right' : ''}>
                    <div className={`flex items-center gap-2 mb-1 flex-wrap ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <h3 className="text-white font-semibold text-lg">
                        {getText(step.title)}
                      </h3>
                      <span className="inline-flex items-center rounded-full border border-[#00AEEF]/30 text-[#00AEEF] text-[11px] font-medium px-2 py-0.5 whitespace-nowrap">
                        {getText(step.pillarTag)}
                      </span>
                    </div>
                    <p className="text-[#AAB4BF] text-sm">
                      {getText(step.description)}
                    </p>
                  </div>
                </div>
                {/* Items */}
                <ul className={`mt-4 space-y-1 text-[#C7D0D9] text-sm ${isRTL ? 'pr-4' : 'pl-4'}`}>
                  {(step.items[language] || step.items.en).map((item: string, i: number) => (
                    <li 
                      key={i} 
                      className={`${isRTL ? 'list-disc list-inside' : 'list-disc'} ${
                        step.highlight === i ? 'font-bold text-white' : ''
                      }`}
                    >
                      {item}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>

          {/* Visual Column */}
          <div className="lg:col-span-5">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="bg-[#121821] rounded-2xl p-6 md:p-8 border border-white/5 sticky top-24"
            >
              {/* SVG Diagram */}
              <svg viewBox="0 0 900 400" className="w-full h-auto">
                <defs>
                  <linearGradient id="blueGlow" x1="0" x2="1">
                    <stop offset="0%" stopColor="#00AEEF" stopOpacity="0.15" />
                    <stop offset="100%" stopColor="#00AEEF" stopOpacity="0.35" />
                  </linearGradient>
                </defs>

                {/* Background */}
                <rect x="20" y="40" width="860" height="300" rx="20" fill="url(#blueGlow)" />

                {/* Timeline */}
                <line
                  x1="120" y1="190" x2="780" y2="190"
                  stroke="#00AEEF" strokeWidth="3" strokeOpacity="0.5"
                />

                {/* Nodes */}
                <g fill="#00AEEF">
                  <circle cx="120" cy="190" r="10" />
                  <circle cx="285" cy="190" r="10" />
                  <circle cx="450" cy="190" r="10" />
                  <circle cx="615" cy="190" r="10" />
                  <circle cx="780" cy="190" r="10" />
                </g>

                {/* Labels */}
                <g fill="#C7D0D9" fontSize="16" textAnchor="middle">
                  {(pageContent.visualLabels[language] || pageContent.visualLabels.en).map((label: string, i: number) => (
                    <text key={i} x={120 + i * 165} y="160">
                      {label}
                    </text>
                  ))}
                </g>
              </svg>

              {/* Benchmarks */}
              <div className="flex flex-wrap justify-between gap-4 mt-6 text-[#AAB4BF]">
                {pageContent.benchmarks.map((bench, i) => (
                  <div key={i} className="text-center flex-1 min-w-[100px]">
                    <strong className="text-[#00AEEF] block text-lg">
                      {getText(bench.value)}
                    </strong>
                    <span className="text-xs">{getText(bench.label)}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
    <FaqSection ids={['what-90-day-sprint', 'where-start', 'how-governance']} />
    </>
  );
}
