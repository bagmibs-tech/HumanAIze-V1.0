'use client';

import { useEffect, useRef } from 'react';

const UTM_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'] as const;
const STORAGE_KEY = 'hz_utm';

/** Snake-case keys (as they appear in URL query params). */
export interface UtmParamsRaw {
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_content?: string;
  utm_term?: string;
}

/** Camel-case keys matching the API / Prisma field names. */
export interface UtmParams {
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  utmContent?: string;
  utmTerm?: string;
}

/** Read stored UTM params (sessionStorage) and return camelCase keys for the API. */
export function getStoredUtm(): UtmParams {
  if (typeof window === 'undefined') return {};
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const p: UtmParamsRaw = JSON.parse(raw);
    return {
      utmSource: p.utm_source,
      utmMedium: p.utm_medium,
      utmCampaign: p.utm_campaign,
      utmContent: p.utm_content,
      utmTerm: p.utm_term,
    };
  } catch {
    return {};
  }
}

/**
 * Hook: on mount, reads UTM query-params from the current URL and
 * persists them in sessionStorage so every form submission in the
 * session can include them — even after the user navigates away
 * from the landing page. First-touch wins: if UTMs are already
 * stored we keep them (the visitor came from one outbound link
 * and is now browsing around).
 */
export function useUtmCapture() {
  const ran = useRef(false);
  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    try {
      const params = new URLSearchParams(window.location.search);
      const incoming: UtmParamsRaw = {};
      let hasAny = false;
      for (const k of UTM_KEYS) {
        const v = params.get(k);
        if (v) { incoming[k] = v; hasAny = true; }
      }
      if (!hasAny) return; // no UTMs on this page load
      // First-touch: keep existing if present
      const existing = sessionStorage.getItem(STORAGE_KEY);
      if (!existing) {
        sessionStorage.setItem(STORAGE_KEY, JSON.stringify(incoming));
      }
    } catch { /* SSR / private browsing */ }
  }, []);
}
