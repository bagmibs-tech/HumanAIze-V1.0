import crypto from 'crypto';
import { cookies } from 'next/headers';

export const ADMIN_COOKIE = 'hz_admin';

export function expectedToken(): string {
  const pw = process.env.ADMIN_PASSWORD || '';
  const sec = process.env.ADMIN_SESSION_SECRET || 'humanaize-admin-fallback-secret';
  return crypto.createHmac('sha256', sec).update(pw).digest('hex');
}

export function verifyPassword(pw: string): boolean {
  const real = process.env.ADMIN_PASSWORD || '';
  if (!real || !pw) return false;
  const a = Buffer.from(pw);
  const b = Buffer.from(real);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export function isAuthed(): boolean {
  const c = cookies().get(ADMIN_COOKIE)?.value;
  if (!c) return false;
  const exp = expectedToken();
  try {
    return crypto.timingSafeEqual(Buffer.from(c), Buffer.from(exp));
  } catch {
    return false;
  }
}
