// Server-only uplift benchmarks for the Blind Spot Calculator.
// These are never exposed to the client until a valid session code is entered.
export type Uplift = { time: number; cost: number; risk: number; revenue: number };

// Keys are normalised (lowercased, alphanumerics only) so the lookup is
// tolerant of the exact label the HTML sends (e.g. "Energy & Utilities").
export const UPLIFT_BENCHMARKS: Record<string, Uplift> = {
  manufacturing: { time: 0.30, cost: 0.25, risk: 0.35, revenue: 0.15 },
  logistics: { time: 0.35, cost: 0.30, risk: 0.25, revenue: 0.12 },
  bfsi: { time: 0.45, cost: 0.28, risk: 0.40, revenue: 0.10 },
  healthcare: { time: 0.60, cost: 0.45, risk: 0.30, revenue: 0.08 },
  energyutilities: { time: 0.25, cost: 0.25, risk: 0.30, revenue: 0.10 },
  retail: { time: 0.30, cost: 0.22, risk: 0.20, revenue: 0.15 },
  realestatesmartcities: { time: 0.50, cost: 0.30, risk: 0.30, revenue: 0.12 },
};

const DEFAULT_UPLIFT: Uplift = { time: 0.30, cost: 0.25, risk: 0.30, revenue: 0.12 };

function normalise(s: string): string {
  return (s || '').toLowerCase().replace(/[^a-z]/g, '');
}

export function upliftForVertical(vertical: string): Uplift {
  const key = normalise(vertical);
  if (UPLIFT_BENCHMARKS[key]) return UPLIFT_BENCHMARKS[key];
  // Handle common aliases the widget may send.
  if (key.startsWith('energy')) return UPLIFT_BENCHMARKS.energyutilities;
  if (key.startsWith('realestate') || key.includes('smartcit')) return UPLIFT_BENCHMARKS.realestatesmartcities;
  return DEFAULT_UPLIFT;
}
