export type FaqItem = {
  id: string;
  q: { en: string; de: string; ar: string };
  a: { en: string; de: string; ar: string };
};

export type FaqGroup = {
  id: string;
  title: { en: string; de: string; ar: string };
  items: FaqItem[];
};

export const faqGroups: FaqGroup[] = [
  {
    id: 'about',
    title: {
      en: 'About HumanAIze',
      de: 'Über HumanAIze',
      ar: 'عن HumanAIze'
    },
    items: [
      {
        id: 'what-is-humanaize',
        q: {
          en: 'What is HumanAIze?',
          de: 'Was ist HumanAIze?',
          ar: 'ما هي HumanAIze؟'
        },
        a: {
          en: 'HumanAIze is an AI transformation firm serving mid-to-large enterprises in DACH (Germany, Austria, Switzerland) and the UAE. It ties its fees to defined business outcomes rather than hours billed, and works to make AI investments produce measurable ROI within 90 days.',
          de: 'HumanAIze ist eine KI-Transformationsfirma für mittlere bis große Unternehmen in der DACH-Region (Deutschland, Österreich, Schweiz) und den VAE. Sie koppelt ihre Honorare an definierte Geschäftsergebnisse statt an abgerechnete Stunden und sorgt dafür, dass KI-Investitionen innerhalb von 90 Tagen messbaren ROI liefern.',
          ar: 'HumanAIze هي شركة تحول بالذكاء الاصطناعي تخدم المؤسسات المتوسطة والكبيرة في منطقة DACH (ألمانيا والنمسا وسويسرا) والإمارات. تربط أتعابها بنتائج أعمال محددة بدلاً من الساعات المفوترة، وتعمل على جعل استثمارات الذكاء الاصطناعي تحقق عائداً قابلاً للقياس خلال 90 يوماً.'
        }
      },
      {
        id: 'how-different',
        q: {
          en: 'How is HumanAIze different from a Big4 firm or AI consultancy?',
          de: 'Wie unterscheidet sich HumanAIze von einer Big4-Firma oder KI-Beratung?',
          ar: 'كيف تختلف HumanAIze عن شركات Big4 أو استشارات الذكاء الاصطناعي؟'
        },
        a: {
          en: 'HumanAIze links its fee to defined KPI outcomes, is vendor-neutral with no preferred platforms or referral fees, uses senior practitioners instead of junior analyst teams, and transfers the capability to your team when the engagement ends. Big4 firms typically bill by time and team size.',
          de: 'HumanAIze koppelt sein Honorar an definierte KPI-Ergebnisse, ist herstellerneutral ohne bevorzugte Plattformen oder Vermittlungsgebühren, setzt erfahrene Praktiker statt Junior-Analystenteams ein und überträgt die Fähigkeit an Ihr Team, wenn die Zusammenarbeit endet. Big4-Firmen rechnen typischerweise nach Zeit und Teamgröße ab.',
          ar: 'تربط HumanAIze أتعابها بنتائج مؤشرات أداء محددة، وهي محايدة تجاه المورّدين دون منصات مفضّلة أو رسوم إحالة، وتستخدم خبراء كباراً بدلاً من فرق المحللين المبتدئين، وتنقل القدرة إلى فريقك عند انتهاء الارتباط. شركات Big4 تفوتر عادة حسب الوقت وحجم الفريق.'
        }
      },
      {
        id: 'who-works-with',
        q: {
          en: 'Who does HumanAIze work with?',
          de: 'Mit wem arbeitet HumanAIze?',
          ar: 'مع من تعمل HumanAIze؟'
        },
        a: {
          en: 'CDOs, CFOs and other C-level leaders at mid-to-large enterprises in DACH and the UAE who are accountable for AI investment and want a number to change, not a strategy deck. This includes organisations whose existing AI spend has not yet produced measurable ROI.',
          de: 'CDOs, CFOs und andere Führungskräfte auf C-Level in mittleren bis großen Unternehmen in DACH und den VAE, die für KI-Investitionen verantwortlich sind und eine Kennzahl verändern wollen — keine Strategiepräsentation. Dazu gehören Organisationen, deren bisherige KI-Ausgaben noch keinen messbaren ROI erbracht haben.',
          ar: 'الرؤساء التنفيذيون للبيانات والمالية وغيرهم من قادة المستوى التنفيذي في المؤسسات المتوسطة والكبيرة في DACH والإمارات الذين يتحملون مسؤولية استثمار الذكاء الاصطناعي ويريدون تغيير رقم، لا عرض استراتيجية. ويشمل ذلك المؤسسات التي لم تحقق نفقاتها الحالية على الذكاء الاصطناعي عائداً قابلاً للقياس بعد.'
        }
      },
      {
        id: 'who-leads',
        q: {
          en: 'Who leads HumanAIze?',
          de: 'Wer führt HumanAIze?',
          ar: 'من يقود HumanAIze؟'
        },
        a: {
          en: 'HumanAIze was founded by Bagmi Sahoo, a senior AI transformation leader with 18+ years of enterprise transformation experience across DACH and the UAE, and UAE Delegate to the Global Alliance for AI (GAFAI). Every engagement is senior-led.',
          de: 'HumanAIze wurde von Bagmi Sahoo gegründet, einer erfahrenen Führungskraft für KI-Transformation mit über 18 Jahren Erfahrung in der Unternehmenstransformation in DACH und den VAE sowie VAE-Delegierte der Global Alliance for AI (GAFAI). Jede Zusammenarbeit wird von Senior-Experten geführt.',
          ar: 'تأسست HumanAIze على يد Bagmi Sahoo، قائدة تحول بالذكاء الاصطناعي مخضرمة تملك أكثر من 18 عاماً من خبرة التحول المؤسسي عبر DACH والإمارات، ومندوبة الإمارات لدى التحالف العالمي للذكاء الاصطناعي (GAFAI). كل ارتباط يقوده خبراء كبار.'
        }
      },
      {
        id: 'where-based',
        q: {
          en: 'Where is HumanAIze based?',
          de: 'Wo hat HumanAIze seinen Sitz?',
          ar: 'أين يقع مقر HumanAIze؟'
        },
        a: {
          en: 'HumanAIze FZE LLC is based in Dubai, UAE, and serves enterprises across DACH and the Middle East with an integrated team, so there are no regional handoffs between markets.',
          de: 'HumanAIze FZE LLC hat seinen Sitz in Dubai, VAE, und betreut Unternehmen in DACH und dem Nahen Osten mit einem integrierten Team, sodass es keine regionalen Übergaben zwischen Märkten gibt.',
          ar: 'تتخذ HumanAIze FZE LLC من دبي بالإمارات مقراً لها، وتخدم المؤسسات عبر DACH والشرق الأوسط بفريق متكامل، بحيث لا توجد عمليات تسليم إقليمية بين الأسواق.'
        }
      }
    ]
  },
  {
    id: 'services',
    title: {
      en: 'Services and the engagement journey',
      de: 'Leistungen und der Weg der Zusammenarbeit',
      ar: 'الخدمات ورحلة الارتباط'
    },
    items: [
      {
        id: 'where-start',
        q: {
          en: 'Where should my organisation start?',
          de: 'Wo sollte meine Organisation beginnen?',
          ar: 'من أين يجب أن تبدأ مؤسستي؟'
        },
        a: {
          en: 'Start where you are. With no AI investment or internal buy-in, start with Blindspot. With budget authority but no validated case, start with Assess. With a validated case, start at Activate. With strategy and governance in place, start at Implement. With a proven pilot to scale, start at Embed.',
          de: 'Beginnen Sie dort, wo Sie stehen. Ohne KI-Investition oder internen Rückhalt beginnen Sie mit Blindspot. Mit Budgethoheit, aber ohne validierten Case beginnen Sie mit Assess. Mit einem validierten Case starten Sie bei Activate. Mit Strategie und Governance starten Sie bei Implement. Mit einem bewährten Pilotprojekt zum Skalieren starten Sie bei Embed.',
          ar: 'ابدأ من حيث أنت. دون استثمار في الذكاء الاصطناعي أو دعم داخلي، ابدأ بـ Blindspot. مع صلاحية الميزانية دون حالة مُثبتة، ابدأ بـ Assess. مع حالة مُثبتة، ابدأ من Activate. مع وجود استراتيجية وحوكمة، ابدأ من Implement. مع طيار مُثبت للتوسع، ابدأ من Embed.'
        }
      },
      {
        id: 'what-services',
        q: {
          en: 'What services does HumanAIze offer?',
          de: 'Welche Leistungen bietet HumanAIze?',
          ar: 'ما الخدمات التي تقدمها HumanAIze؟'
        },
        a: {
          en: 'HumanAIze offers a four-stage Operating System: Assess (diagnostic and business case), Activate (strategy, architecture and governance), Implement (90-day ROI sprints) and Embed (scaling and capability transfer). A separate optional offer, Blindspot, builds the internal business case before any commitment.',
          de: 'HumanAIze bietet ein vierstufiges Operating System: Assess (Diagnose und Business Case), Activate (Strategie, Architektur und Governance), Implement (90-Tage-ROI-Sprints) und Embed (Skalierung und Capability-Transfer). Ein separates optionales Angebot, Blindspot, erstellt den internen Business Case vor jeder Verpflichtung.',
          ar: 'تقدم HumanAIze نظام تشغيل من أربع مراحل: Assess (التشخيص وحالة العمل)، Activate (الاستراتيجية والبنية والحوكمة)، Implement (سباقات عائد مدتها 90 يوماً) و Embed (التوسع ونقل القدرة). وهناك عرض اختياري منفصل، Blindspot، يبني حالة العمل الداخلية قبل أي التزام.'
        }
      },
      {
        id: 'what-blindspot',
        q: {
          en: 'What is the Blindspot Opportunity Assessment?',
          de: 'Was ist das Blindspot Opportunity Assessment?',
          ar: 'ما هو تقييم الفرص Blindspot؟'
        },
        a: {
          en: 'Blindspot is a standalone, fixed-fee engagement of 3–5 days that scans for AI opportunities and builds a budget-ready business case for leadership sign-off. It is designed for organisations with no prior AI investment, and sits outside the four-stage methodology as an optional entry point.',
          de: 'Blindspot ist eine eigenständige Festpreis-Zusammenarbeit von 3–5 Tagen, die KI-Chancen aufspürt und einen budgetreifen Business Case zur Freigabe durch die Führung erstellt. Es ist für Organisationen ohne vorherige KI-Investition konzipiert und liegt als optionaler Einstiegspunkt außerhalb der vierstufigen Methodik.',
          ar: 'Blindspot ارتباط مستقل بسعر ثابت مدته 3–5 أيام يبحث عن فرص الذكاء الاصطناعي ويبني حالة عمل جاهزة للميزانية لاعتماد القيادة. مصمم للمؤسسات التي لا تملك استثماراً سابقاً في الذكاء الاصطناعي، ويقع خارج المنهجية ذات المراحل الأربع كنقطة دخول اختيارية.'
        }
      },
      {
        id: 'what-assess',
        q: {
          en: 'What is the Assess stage?',
          de: 'Was ist die Assess-Stufe?',
          ar: 'ما هي مرحلة Assess؟'
        },
        a: {
          en: 'Assess is a fixed-fee diagnostic of 4–8 weeks that audits AI maturity, prioritises and scores the top use cases, locks KPI baselines with sign-off, and produces a 90-Day Value Hypothesis with metric uplift targets. It tells you which AI investments are worth making before capital is committed.',
          de: 'Assess ist eine Festpreis-Diagnose von 4–8 Wochen, die die KI-Reife prüft, die wichtigsten Use Cases priorisiert und bewertet, KPI-Baselines mit Freigabe fixiert und eine 90-Tage-Wert-Hypothese mit Uplift-Zielwerten erstellt. Sie sagt Ihnen, welche KI-Investitionen sich lohnen, bevor Kapital gebunden wird.',
          ar: 'Assess تشخيص بسعر ثابت مدته 4–8 أسابيع يدقق نضج الذكاء الاصطناعي، ويرتب ويقيّم أهم حالات الاستخدام، ويثبّت خطوط أساس مؤشرات الأداء مع الاعتماد، وينتج فرضية قيمة لـ 90 يوماً بأهداف رفع قابلة للقياس. يخبرك أي استثمارات الذكاء الاصطناعي تستحق قبل الالتزام برأس المال.'
        }
      },
      {
        id: 'what-90-day-sprint',
        q: {
          en: 'What is a 90-Day ROI Sprint?',
          de: 'Was ist ein 90-Tage-ROI-Sprint?',
          ar: 'ما هو سباق العائد لـ 90 يوماً؟'
        },
        a: {
          en: 'A 90-Day ROI Sprint is a time-boxed Implement engagement that builds and deploys priority AI use cases and measures results against a baseline locked beforehand. It ends with a day-90 gate: scale, iterate, or stop. The sprint clock starts only after Assess has locked the baseline.',
          de: 'Ein 90-Tage-ROI-Sprint ist eine zeitlich begrenzte Implement-Zusammenarbeit, die priorisierte KI-Use-Cases baut und deployt und die Ergebnisse gegen eine zuvor fixierte Baseline misst. Er endet mit einem Day-90-Gate: skalieren, iterieren oder stoppen. Die Sprint-Uhr startet erst, nachdem Assess die Baseline fixiert hat.',
          ar: 'سباق العائد لـ 90 يوماً هو ارتباط Implement محدد المدة يبني وينشر حالات استخدام ذات أولوية ويقيس النتائج مقابل خط أساس مُثبت مسبقاً. ينتهي ببوابة اليوم 90: التوسع أو التكرار أو التوقف. تبدأ ساعة السباق فقط بعد أن يثبّت Assess خط الأساس.'
        }
      },
      {
        id: 'what-roi-as-service',
        q: {
          en: 'What does "ROI as a Service" mean?',
          de: 'Was bedeutet „ROI as a Service“?',
          ar: 'ماذا يعني «العائد كخدمة»؟'
        },
        a: {
          en: 'ROI as a Service means HumanAIze\'s fee is tied to defined outcomes rather than hours worked. KPIs and the baseline are agreed in writing before work begins, and Implement engagements include a success fee linked to the KPI uplift delivered.',
          de: 'ROI as a Service bedeutet, dass das Honorar von HumanAIze an definierte Ergebnisse statt an geleistete Stunden gekoppelt ist. KPIs und die Baseline werden schriftlich vereinbart, bevor die Arbeit beginnt, und Implement-Zusammenarbeiten enthalten ein Erfolgshonorar, das an den gelieferten KPI-Uplift gekoppelt ist.',
          ar: 'العائد كخدمة يعني أن أتعاب HumanAIze مرتبطة بنتائج محددة بدلاً من ساعات العمل. تُتفق مؤشرات الأداء وخط الأساس كتابياً قبل بدء العمل، وتتضمن ارتباطات Implement رسوم نجاح مرتبطة برفع مؤشر الأداء المُنجَز.'
        }
      },
      {
        id: 'no-credible-roi',
        q: {
          en: 'What happens if there is no credible ROI path?',
          de: 'Was passiert, wenn es keinen glaubwürdigen ROI-Pfad gibt?',
          ar: 'ماذا يحدث إذا لم يكن هناك مسار عائد موثوق؟'
        },
        a: {
          en: 'HumanAIze does not begin. If a credible path to measurable ROI is not visible within 90 days, HumanAIze tells you and declines to start. This protects both sides from wasted investment.',
          de: 'HumanAIze beginnt nicht. Wenn innerhalb von 90 Tagen kein glaubwürdiger Pfad zu messbarem ROI erkennbar ist, teilt HumanAIze Ihnen das mit und lehnt den Start ab. Das schützt beide Seiten vor verschwendeter Investition.',
          ar: 'لا تبدأ HumanAIze. إذا لم يكن هناك مسار موثوق لعائد قابل للقياس خلال 90 يوماً، تخبرك HumanAIze وترفض البدء. هذا يحمي الطرفين من استثمار ضائع.'
        }
      }
    ]
  },
  {
    id: 'pricing',
    title: {
      en: 'Pricing and commercial model',
      de: 'Preise und Geschäftsmodell',
      ar: 'التسعير والنموذج التجاري'
    },
    items: [
      {
        id: 'how-much-cost',
        q: {
          en: 'How much does HumanAIze cost?',
          de: 'Was kostet HumanAIze?',
          ar: 'كم تكلفة HumanAIze؟'
        },
        a: {
          en: 'Fees depend on organisation size, scope and market, so HumanAIze does not publish a price list. Blindspot and Assess are fixed-fee, Activate and Embed are monthly retainers, and Implement is a fixed fee per 90-day sprint plus a success fee tied to KPI uplift. Book a diagnostic for a scoped proposal.',
          de: 'Die Honorare hängen von Organisationsgröße, Umfang und Markt ab, daher veröffentlicht HumanAIze keine Preisliste. Blindspot und Assess sind Festpreis, Activate und Embed sind monatliche Retainer, und Implement ist ein Festpreis pro 90-Tage-Sprint plus Erfolgshonorar, das an den KPI-Uplift gekoppelt ist. Buchen Sie eine Diagnose für ein zugeschnittenes Angebot.',
          ar: 'تعتمد الأتعاب على حجم المؤسسة والنطاق والسوق، لذلك لا تنشر HumanAIze قائمة أسعار. Blindspot و Assess بسعر ثابت، و Activate و Embed اشتراكات شهرية، و Implement سعر ثابت لكل سباق مدته 90 يوماً بالإضافة إلى رسوم نجاح مرتبطة برفع مؤشر الأداء. احجز تشخيصاً للحصول على عرض محدد.'
        }
      },
      {
        id: 'how-outcome-pricing',
        q: {
          en: 'How does outcome-linked pricing work?',
          de: 'Wie funktioniert ergebnisgekoppelte Preisgestaltung?',
          ar: 'كيف يعمل التسعير المرتبط بالنتائج؟'
        },
        a: {
          en: 'Before work begins, you and HumanAIze agree the KPI baseline and the 90-day objective in writing. For Implement sprints, part of the fee depends on the measured uplift against that baseline, so HumanAIze is paid on results, not promises.',
          de: 'Bevor die Arbeit beginnt, vereinbaren Sie und HumanAIze die KPI-Baseline und das 90-Tage-Ziel schriftlich. Bei Implement-Sprints hängt ein Teil des Honorars vom gemessenen Uplift gegenüber dieser Baseline ab, sodass HumanAIze auf Ergebnisse vergütet wird, nicht auf Versprechen.',
          ar: 'قبل بدء العمل، تتفق أنت و HumanAIze كتابياً على خط أساس مؤشر الأداء وهدف الـ 90 يوماً. في سباقات Implement، يعتمد جزء من الأتعاب على الرفع المقاس مقابل ذلك الخط، لذلك تُدفع HumanAIze على النتائج وليس الوعود.'
        }
      }
    ]
  },
  {
    id: 'trust',
    title: {
      en: 'Trust, governance and delivery',
      de: 'Vertrauen, Governance und Umsetzung',
      ar: 'الثقة والحوكمة والتنفيذ'
    },
    items: [
      {
        id: 'is-vendor-neutral',
        q: {
          en: 'Is HumanAIze vendor-neutral?',
          de: 'Ist HumanAIze herstellerneutral?',
          ar: 'هل HumanAIze محايدة تجاه المورّدين؟'
        },
        a: {
          en: 'Yes. HumanAIze has no preferred technology partners, takes no referral fees and has no platform to sell. Recommendations are based only on what serves your outcome, so you are never locked in to a vendor through HumanAIze.',
          de: 'Ja. HumanAIze hat keine bevorzugten Technologiepartner, nimmt keine Vermittlungsgebühren und hat keine Plattform zu verkaufen. Empfehlungen basieren nur darauf, was Ihrem Ergebnis dient, sodass Sie durch HumanAIze niemals an einen Anbieter gebunden werden.',
          ar: 'نعم. ليس لدى HumanAIze شركاء تقنية مفضّلون، ولا تأخذ رسوم إحالة، وليس لديها منصة لبيعها. تستند التوصيات فقط إلى ما يخدم نتيجتك، لذلك لن تُحبس أبداً مع مورّد عبر HumanAIze.'
        }
      },
      {
        id: 'who-owns-work',
        q: {
          en: 'Who owns the work when the engagement ends?',
          de: 'Wem gehört die Arbeit, wenn die Zusammenarbeit endet?',
          ar: 'من يملك العمل عند انتهاء الارتباط؟'
        },
        a: {
          en: 'You do. Capability transfer is built into every engagement: HumanAIze builds the internal capability, governance structures and measurement systems your team needs to run AI value without external dependency.',
          de: 'Sie. Capability-Transfer ist in jede Zusammenarbeit eingebaut: HumanAIze baut die interne Fähigkeit, Governance-Strukturen und Messsysteme auf, die Ihr Team braucht, um KI-Wert ohne externe Abhängigkeit zu betreiben.',
          ar: 'أنت. نقل القدرة مدمج في كل ارتباط: تبني HumanAIze القدرة الداخلية وهياكل الحوكمة وأنظمة القياس التي يحتاجها فريقك لتشغيل قيمة الذكاء الاصطناعي دون اعتماد خارجي.'
        }
      },
      {
        id: 'how-governance',
        q: {
          en: 'How does HumanAIze handle AI governance and regulation?',
          de: 'Wie geht HumanAIze mit KI-Governance und Regulierung um?',
          ar: 'كيف تتعامل HumanAIze مع حوكمة الذكاء الاصطناعي والتنظيم؟'
        },
        a: {
          en: 'Activate includes regulatory compliance mapping across the EU AI Act, UAE requirements, DIFC-10 and NIST. In Implement, agentic AI is governed by HumanAIze\'s TARA-A framework, and vendor-native governance is adopted for other tools.',
          de: 'Activate umfasst die Zuordnung der regulatorischen Compliance über den EU AI Act, VAE-Anforderungen, DIFC-10 und NIST. In Implement wird agentische KI durch das TARA-A-Framework von HumanAIze gesteuert, und für andere Tools wird herstellereigene Governance übernommen.',
          ar: 'تتضمن Activate رسم الامتثال التنظيمي عبر قانون الذكاء الاصطناعي الأوروبي ومتطلبات الإمارات و DIFC-10 و NIST. في Implement، يخضع الذكاء الاصطناعي الوكيلي لإطار TARA-A الخاص بـ HumanAIze، وتُعتمد الحوكمة الأصلية للمورّد للأدوات الأخرى.'
        }
      },
      {
        id: 'what-results',
        q: {
          en: 'What results can I expect?',
          de: 'Welche Ergebnisse kann ich erwarten?',
          ar: 'ما النتائج التي يمكنني توقعها؟'
        },
        a: {
          en: 'HumanAIze\'s benchmarks, set in writing before an engagement starts, are 15–30% process cycle-time reduction, 20–28% IT cost optimisation, 20–40% AI-driven process acceleration, and 15–25% FTE productivity uplift. First measurable outcomes are targeted within 90 days.',
          de: 'Die Benchmarks von HumanAIze, schriftlich festgelegt bevor eine Zusammenarbeit beginnt, sind 15–30% Reduktion der Prozesszykluszeit, 20–28% IT-Kostenoptimierung, 20–40% KI-getriebene Prozessbeschleunigung und 15–25% Steigerung der FTE-Produktivität. Erste messbare Ergebnisse werden innerhalb von 90 Tagen angestrebt.',
          ar: 'معايير HumanAIze، المحددة كتابياً قبل بدء الارتباط، هي تخفيض زمن دورة العملية بنسبة 15–30%، وتحسين تكاليف تقنية المعلومات بنسبة 20–28%، وتسريع العمليات بالذكاء الاصطناعي بنسبة 20–40%، ورفع إنتاجية الموظف المكافئ بنسبة 15–25%. تُستهدف أولى النتائج القابلة للقياس خلال 90 يوماً.'
        }
      },
      {
        id: 'how-get-started',
        q: {
          en: 'How do I get started?',
          de: 'Wie fange ich an?',
          ar: 'كيف أبدأ؟'
        },
        a: {
          en: 'Book an AI Readiness Diagnostic: a 30-minute conversation with a senior HumanAIze advisor. There is no pitch or deck. You will hear where the value gap in your AI investment is, whether or not you engage HumanAIze.',
          de: 'Buchen Sie eine AI-Readiness-Diagnose: ein 30-minütiges Gespräch mit einem erfahrenen HumanAIze-Berater. Es gibt keinen Pitch und keine Präsentation. Sie erfahren, wo die Wertlücke in Ihrer KI-Investition liegt — ob Sie mit HumanAIze zusammenarbeiten oder nicht.',
          ar: 'احجز تشخيص جاهزية الذكاء الاصطناعي: محادثة مدتها 30 دقيقة مع مستشار أول في HumanAIze. لا يوجد عرض ترويجي أو شرائح. ستسمع أين تقع فجوة القيمة في استثمار الذكاء الاصطناعي لديك، سواء تعاقدت مع HumanAIze أم لا.'
        }
      }
    ]
  }
];

const allItems: FaqItem[] = faqGroups.flatMap((g) => g.items);

export function getFaqById(id: string): FaqItem | undefined {
  return allItems.find((i) => i.id === id);
}

export function getFaqItems(ids: string[]): FaqItem[] {
  return ids.map((id) => getFaqById(id)).filter((i): i is FaqItem => Boolean(i));
}
