import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Standing self-serve unlock code for the Blind Spot Calculator.
  // Never expires; used by the "Get an instant code" email flow.
  await prisma.blindspotCode.upsert({
    where: { code: 'ROI90' },
    update: { active: true },
    create: {
      code: 'ROI90',
      prospectName: 'Self-serve standing code',
      active: true,
      expiresAt: null,
    },
  });

  // A second demo/session code that HumanAIze can share verbally in live sessions.
  await prisma.blindspotCode.upsert({
    where: { code: 'SEE2026' },
    update: { active: true },
    create: {
      code: 'SEE2026',
      prospectName: 'Live session code',
      active: true,
      expiresAt: null,
    },
  });

  console.log('Seeded Blind Spot Calculator codes: ROI90, SEE2026');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
