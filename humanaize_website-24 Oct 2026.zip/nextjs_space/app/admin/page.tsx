export const dynamic = 'force-dynamic';

import { redirect } from 'next/navigation';
import { isAuthed } from '@/lib/admin-auth';
import { prisma } from '@/lib/db';
import AdminDashboard, { AdminRow } from '@/components/admin/admin-dashboard';

function utmFields(r: { utmSource?: string | null; utmMedium?: string | null; utmCampaign?: string | null; utmContent?: string | null; utmTerm?: string | null }) {
  return {
    utmSource: r.utmSource || null,
    utmMedium: r.utmMedium || null,
    utmCampaign: r.utmCampaign || null,
    utmContent: r.utmContent || null,
    utmTerm: r.utmTerm || null,
  };
}

export default async function AdminPage() {
  if (!isAuthed()) redirect('/admin/login');

  const [contacts, readiness, roi, bsLeads, bsUnlocks] = await Promise.all([
    prisma.contactSubmission.findMany({ orderBy: { createdAt: 'desc' } }),
    prisma.readinessLead.findMany({ orderBy: { createdAt: 'desc' } }),
    prisma.roiCalculatorLead.findMany({ orderBy: { createdAt: 'desc' } }),
    prisma.blindspotLead.findMany({ orderBy: { createdAt: 'desc' } }),
    prisma.blindspotUnlock.findMany({ orderBy: { createdAt: 'desc' } }),
  ]);

  const rows: AdminRow[] = [];

  for (const r of contacts) {
    const sourceLabel = r.formType === 'framework_download' ? 'Framework Download'
      : r.formType === 'readiness_diagnostic' ? 'Readiness Diagnostic'
      : r.formType === 'blindspot_calculator' ? 'Blindspot Calculator'
      : r.formType === 'roi_calculator' ? 'ROI Calculator'
      : 'Contact Form';
    rows.push({
      id: `contact-${r.id}`,
      source: sourceLabel,
      name: r.name,
      email: r.email,
      company: r.company || '',
      createdAt: r.createdAt.toISOString(),
      ...utmFields(r),
      detail: {
        Phone: r.phone,
        Subject: r.subject,
        Message: r.message,
        'Form Type': r.formType,
      },
    });
  }

  for (const r of readiness) {
    rows.push({
      id: `readiness-${r.id}`,
      source: 'Readiness Assessment',
      name: r.name,
      email: r.email,
      company: r.company,
      createdAt: r.createdAt.toISOString(),
      ...utmFields(r),
      detail: {
        Phone: r.phone,
        Region: r.region,
        Industry: r.industry,
        'Overall Score': r.overallScore,
        'Overall Stage': r.overallStage,
        'Recommended Pillar': r.recommendedPillar,
        'Dimension Scores': r.dimensionScores,
      },
    });
  }

  for (const r of roi) {
    rows.push({
      id: `roi-${r.id}`,
      source: 'ROI Calculator',
      name: r.name,
      email: r.email,
      company: r.company,
      createdAt: r.createdAt.toISOString(),
      ...utmFields(r),
      detail: {
        Phone: r.phone,
        Region: r.region,
        Industry: r.industry,
        Currency: r.currency,
        'Use Case': r.useCaseName,
        'Benefit Category': r.benefitCategory,
        'Year 0 Investment': r.year0Investment,
        'Discount Rate %': r.discountRatePct,
        'Conservative NPV': r.conservativeNpv,
        'Base NPV': r.baseNpv,
        'Optimistic NPV': r.optimisticNpv,
        'Base ROI %': r.baseRoiPct,
        'Payback (months)': r.basePaybackMonths,
        'Base IRR %': r.baseIrrPct,
        'Case Strength': r.caseStrength,
        'Intangible Scores': r.intangibleScores,
      },
    });
  }

  for (const r of bsLeads) {
    rows.push({
      id: `bslead-${r.id}`,
      source: 'Blindspot Lead',
      name: r.name,
      email: r.email,
      company: r.organisation || '',
      createdAt: r.createdAt.toISOString(),
      ...utmFields(r),
      detail: {
        Phone: r.phone,
        Organisation: r.organisation,
        Vertical: r.vertical,
        Region: r.region,
        'Cost of Inaction': r.costOfInaction,
        Currency: r.currency,
        'Code Issued': r.codeIssued,
      },
    });
  }

  for (const r of bsUnlocks) {
    rows.push({
      id: `bsunlock-${r.id}`,
      source: 'Blindspot Unlock',
      name: '—',
      email: '—',
      company: r.organisation || '',
      createdAt: r.createdAt.toISOString(),
      utmSource: null, utmMedium: null, utmCampaign: null, utmContent: null, utmTerm: null,
      detail: {
        Code: r.code,
        Valid: r.valid,
        Organisation: r.organisation,
        Vertical: r.vertical,
        Region: r.region,
        'Cost of Inaction': r.costOfInaction,
        Currency: r.currency,
      },
    });
  }

  rows.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));

  return <AdminDashboard rows={rows} />;
}
