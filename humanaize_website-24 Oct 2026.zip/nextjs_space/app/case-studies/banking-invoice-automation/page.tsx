import type { Metadata } from 'next';
import BankingInvoiceAutomationCaseStudy from '@/components/pages/case-studies/banking-invoice-automation';

export const metadata: Metadata = {
  title: 'Banking Invoice Automation AI Case Study | HumanAIze',
  description:
    'How a bank automated invoice processing with AI to slash manual handling time and error rates \u2014 delivering measurable, benchmarked ROI within 90 days.',
  alternates: { canonical: '/case-studies/banking-invoice-automation' },
  openGraph: {
    title: 'Banking Invoice Automation AI Case Study | HumanAIze',
    description:
      'AI-driven invoice automation cutting manual handling time and error rates for a banking client.',
    url: '/case-studies/banking-invoice-automation',
    type: 'article',
  },
};

export default function Page() {
  return <BankingInvoiceAutomationCaseStudy />;
}
