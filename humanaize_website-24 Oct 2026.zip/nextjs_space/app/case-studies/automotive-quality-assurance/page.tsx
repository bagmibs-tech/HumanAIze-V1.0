import type { Metadata } from 'next';
import AutomotiveQualityAssuranceCaseStudy from '@/components/pages/case-studies/automotive-quality-assurance';

export const metadata: Metadata = {
  title: 'Automotive Quality Assurance AI Case Study | HumanAIze',
  description:
    'How an automotive manufacturer used AI-powered visual inspection to cut defect escape rates and boost quality-assurance throughput \u2014 with benchmarked ROI in 90 days.',
  alternates: { canonical: '/case-studies/automotive-quality-assurance' },
  openGraph: {
    title: 'Automotive Quality Assurance AI Case Study | HumanAIze',
    description:
      'AI-powered visual inspection cutting defect escape rates and boosting QA throughput for an automotive manufacturer.',
    url: '/case-studies/automotive-quality-assurance',
    type: 'article',
  },
};

export default function Page() {
  return <AutomotiveQualityAssuranceCaseStudy />;
}
