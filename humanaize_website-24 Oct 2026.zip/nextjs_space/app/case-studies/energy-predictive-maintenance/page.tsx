import type { Metadata } from 'next';
import EnergyPredictiveMaintenanceCaseStudy from '@/components/pages/case-studies/energy-predictive-maintenance';

export const metadata: Metadata = {
  title: 'Energy Predictive Maintenance AI Case Study | HumanAIze',
  description:
    'How an energy operator applied AI predictive maintenance to reduce unplanned downtime and maintenance costs \u2014 with benchmarked ROI delivered in 90 days.',
  alternates: { canonical: '/case-studies/energy-predictive-maintenance' },
  openGraph: {
    title: 'Energy Predictive Maintenance AI Case Study | HumanAIze',
    description:
      'AI predictive maintenance reducing unplanned downtime and maintenance costs for an energy operator.',
    url: '/case-studies/energy-predictive-maintenance',
    type: 'article',
  },
};

export default function Page() {
  return <EnergyPredictiveMaintenanceCaseStudy />;
}
