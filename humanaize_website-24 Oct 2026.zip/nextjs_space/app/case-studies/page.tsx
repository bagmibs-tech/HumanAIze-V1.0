import type { Metadata } from 'next';
import CaseStudies from '@/components/pages/case-studies/index-page';

export const metadata: Metadata = {
  title: 'Case Studies - Proven AI ROI Across DACH & UAE | HumanAIze',
  description:
    'Real-world AI and digital transformation results across manufacturing, banking, healthcare, and energy in DACH and UAE. See measurable, benchmarked ROI outcomes.',
  alternates: { canonical: '/case-studies' },
  openGraph: {
    title: 'Case Studies - Proven AI ROI Across DACH & UAE | HumanAIze',
    description:
      'Real-world AI and digital transformation results across manufacturing, banking, healthcare, and energy in DACH and UAE.',
    url: '/case-studies',
    type: 'website',
  },
};

export default function Page() {
  return <CaseStudies />;
}
