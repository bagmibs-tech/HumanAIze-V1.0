import type { Metadata } from 'next';
import HealthcareDocumentAutomationCaseStudy from '@/components/pages/case-studies/healthcare-document-automation';

export const metadata: Metadata = {
  title: 'Healthcare Document Automation AI Case Study | HumanAIze',
  description:
    'How a healthcare provider automated clinical document processing with AI to speed up workflows and reduce administrative load \u2014 with benchmarked ROI in 90 days.',
  alternates: { canonical: '/case-studies/healthcare-document-automation' },
  openGraph: {
    title: 'Healthcare Document Automation AI Case Study | HumanAIze',
    description:
      'AI-powered clinical document automation speeding up workflows and cutting administrative load for a healthcare provider.',
    url: '/case-studies/healthcare-document-automation',
    type: 'article',
  },
};

export default function Page() {
  return <HealthcareDocumentAutomationCaseStudy />;
}
