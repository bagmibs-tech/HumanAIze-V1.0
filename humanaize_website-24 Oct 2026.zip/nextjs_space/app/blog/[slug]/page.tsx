import type { Metadata } from 'next';
import BlogPostPage from '@/components/pages/blog-post-page';
import { blogContent } from '@/lib/blog-content';

const postMeta: Record<string, { title: string; description: string }> = {
  'dach-ai-acceleration': {
    title: 'Why DACH Needs to Accelerate Its AI Journey',
    description:
      'An analysis of the current state, challenges, and opportunities for AI adoption in Germany, Austria, and Switzerland.',
  },
  'uae-ai-leadership': {
    title: 'What the UAE is Doing to Stay Ahead in AI Leadership',
    description:
      "Exploring the UAE's strategic AI initiatives, investments, and policy frameworks that position it as a global AI leader.",
  },
  'dach-uae-cross-learning': {
    title: 'Bridging Two Worlds: What DACH and UAE Can Learn from Each Other',
    description:
      'A strategic analysis of complementary strengths and collaboration opportunities between DACH and UAE in AI adoption.',
  },
  'eu-ai-act-compliance': {
    title: 'EU AI Act: A Practical Guide for Business Leaders',
    description:
      "Understanding the EU AI Act's risk-based framework, compliance requirements, and how to turn regulatory obligations into competitive advantages.",
  },
  'agentic-ai-enterprise': {
    title: 'Agentic AI: The Next Frontier for Enterprise Transformation',
    description:
      'Exploring autonomous AI agents that can plan, execute, and adapt to achieve complex business objectives with minimal human intervention.',
  },
};

export async function generateStaticParams() {
  return Object.keys(postMeta).map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const meta = postMeta[params.slug];
  if (!meta) {
    return {
      title: 'Insights | HumanAIze',
      description: 'AI and digital transformation insights for DACH and UAE enterprises.',
    };
  }
  const canonical = `/blog/${params.slug}`;
  return {
    title: `${meta.title} | HumanAIze`,
    description: meta.description,
    alternates: { canonical },
    openGraph: {
      title: meta.title,
      description: meta.description,
      url: canonical,
      type: 'article',
    },
    twitter: {
      card: 'summary_large_image',
      title: meta.title,
      description: meta.description,
    },
  };
}

export default function BlogPost({ params }: { params: { slug: string } }) {
  const content = blogContent[params.slug] || '';
  return <BlogPostPage slug={params.slug} content={content} />;
}
