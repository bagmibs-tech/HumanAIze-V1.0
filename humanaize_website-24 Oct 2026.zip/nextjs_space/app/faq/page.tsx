import dynamic from 'next/dynamic';

const FaqPage = dynamic(() => import('@/components/pages/faq-page'), {
  ssr: true,
});

export const metadata = {
  title: 'FAQ — How HumanAIze Works | AI Transformation for DACH & UAE',
  description: 'Answers on HumanAIze: outcome-linked fees, the Assess → Activate → Implement → Embed Operating System, Blindspot, pricing, vendor-neutrality, governance and 90-day ROI.',
  alternates: { canonical: '/faq' },
  openGraph: {
    title: 'FAQ — How HumanAIze Works',
    description: 'How HumanAIze ties fees to outcomes and delivers measurable AI ROI within 90 days across DACH and the UAE.',
    url: 'https://human-aize.com/faq',
  },
};

export default function Faq() {
  return <FaqPage />;
}
