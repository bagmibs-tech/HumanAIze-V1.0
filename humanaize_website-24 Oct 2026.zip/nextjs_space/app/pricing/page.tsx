import PricingPage from '@/components/pages/pricing-page';

export const metadata = {
  title: 'Pricing - Outcome-Aligned AI Investment Models | HumanAIze',
  description: 'Investment models aligned to enterprise outcomes. We align fees to defined outcomes — not billable hours.',
  alternates: { canonical: '/pricing' },
  openGraph: {
    title: 'Pricing - Outcome-Aligned AI Investment Models | HumanAIze',
    description: 'Investment models aligned to enterprise outcomes. We align fees to defined outcomes — not billable hours.',
    url: 'https://human-aize.com/pricing',
  },
};

export default function Pricing() {
  return <PricingPage />;
}
