import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

const emailOk = (e: string) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e || '');
const numOrNull = (v: any) => (v != null && v !== '' ? Number(v) : null);
const intOrNull = (v: any) => (v != null && v !== '' ? Math.round(Number(v)) : null);

// POST /api/tools/roi-leads — AI ROI Calculator lead capture
export async function POST(request: NextRequest) {
  try {
    const b = await request.json();
    if (!b?.name || !emailOk(b?.email) || !b?.company) {
      return NextResponse.json({ status: 'error', error: 'name, valid email and company are required' }, { status: 400 });
    }

    const lead = await prisma.roiCalculatorLead.create({
      data: {
        name: String(b.name),
        email: String(b.email),
        company: String(b.company),
        phone: b.phone ? String(b.phone) : null,
        region: b.region ? String(b.region) : null,
        industry: b.industry ? String(b.industry) : null,
        currency: b.currency ? String(b.currency) : null,
        useCaseName: b.use_case_name ? String(b.use_case_name) : null,
        benefitCategory: b.benefit_category ? String(b.benefit_category) : null,
        year0Investment: numOrNull(b.year0_investment),
        discountRatePct: numOrNull(b.discount_rate_pct),
        baseNpv: numOrNull(b.base_npv),
        baseRoiPct: numOrNull(b.base_roi_pct),
        basePaybackMonths: intOrNull(b.base_payback_months),
        baseIrrPct: numOrNull(b.base_irr_pct),
        conservativeNpv: numOrNull(b.conservative_npv),
        optimisticNpv: numOrNull(b.optimistic_npv),
        intangibleScores: b.intangible_scores ?? undefined,
        caseStrength: b.case_strength ? String(b.case_strength) : null,
        utmSource: b.utm_source ? String(b.utm_source) : null,
        utmMedium: b.utm_medium ? String(b.utm_medium) : null,
        utmCampaign: b.utm_campaign ? String(b.utm_campaign) : null,
        utmContent: b.utm_content ? String(b.utm_content) : null,
        utmTerm: b.utm_term ? String(b.utm_term) : null,
        submittedAt: b.submitted_at ? new Date(b.submitted_at) : new Date(),
      },
    });

    return NextResponse.json({ status: 'ok', leadId: lead.id }, { status: 200 });
  } catch (err) {
    console.error('roi lead error:', err);
    return NextResponse.json({ status: 'error', error: 'failed to store lead' }, { status: 500 });
  }
}
