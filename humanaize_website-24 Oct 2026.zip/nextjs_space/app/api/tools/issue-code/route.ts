import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

const emailOk = (e: string) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e || '');

// The standing self-serve code handed out by the email flow.
const STANDING_CODE = 'ROI90';

async function notifyTeam(lead: {
  name: string; email: string; phone?: string | null; organisation?: string | null;
  region?: string | null; vertical?: string | null; costOfInaction?: number | null; currency?: string | null;
}) {
  try {
    const appUrl = process.env.NEXTAUTH_URL || 'https://human-aize.com';
    const htmlBody = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #06b6d4; border-bottom: 2px solid #06b6d4; padding-bottom: 10px;">
          New Blind Spot Calculator lead — HumanAIze
        </h2>
        <div style="background: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 10px 0;"><strong>Name:</strong> ${lead.name}</p>
          <p style="margin: 10px 0;"><strong>Email:</strong> <a href="mailto:${lead.email}">${lead.email}</a></p>
          ${lead.phone ? `<p style="margin: 10px 0;"><strong>Phone:</strong> ${lead.phone}</p>` : ''}
          ${lead.organisation ? `<p style="margin: 10px 0;"><strong>Organisation:</strong> ${lead.organisation}</p>` : ''}
          ${lead.region ? `<p style="margin: 10px 0;"><strong>Region:</strong> ${lead.region}</p>` : ''}
          ${lead.vertical ? `<p style="margin: 10px 0;"><strong>Vertical:</strong> ${lead.vertical}</p>` : ''}
          ${lead.costOfInaction != null ? `<p style="margin: 10px 0;"><strong>Cost of inaction:</strong> ${lead.currency || ''} ${lead.costOfInaction.toLocaleString()}</p>` : ''}
          <p style="margin: 10px 0;"><strong>Code issued:</strong> ${STANDING_CODE}</p>
        </div>
        <p style="color: #666; font-size: 12px;">Submitted at: ${new Date().toLocaleString()}</p>
      </div>`;

    await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_CONTACT_FORM_SUBMISSION,
        subject: `New Blind Spot Calculator lead from ${lead.name}`,
        body: htmlBody,
        is_html: true,
        recipient_email: 'connect@human-aize.com',
        sender_email: `noreply@${new URL(appUrl).hostname}`,
        sender_alias: 'HumanAIze',
      }),
    });
  } catch (e) {
    console.error('issue-code notify error:', e);
  }
}

// POST /api/tools/issue-code — Blind Spot Calculator self-serve email flow
export async function POST(request: NextRequest) {
  try {
    const b = await request.json();
    if (!b?.name || !emailOk(b?.email)) {
      return NextResponse.json({ error: 'name and a valid email are required' }, { status: 400 });
    }

    // Ensure the standing code exists (idempotent).
    await prisma.blindspotCode.upsert({
      where: { code: STANDING_CODE },
      update: { active: true },
      create: { code: STANDING_CODE, prospectName: 'Self-serve standing code', active: true, expiresAt: null },
    });

    const lead = {
      name: String(b.name),
      email: String(b.email),
      phone: b.phone ? String(b.phone) : null,
      organisation: b.organisation ? String(b.organisation) : null,
      region: b.region ? String(b.region) : null,
      vertical: b.vertical ? String(b.vertical) : null,
      costOfInaction: b.costOfInaction != null ? Number(b.costOfInaction) : null,
      currency: b.currency ? String(b.currency) : null,
    };

    await prisma.blindspotLead.create({
      data: {
        ...lead,
        codeIssued: STANDING_CODE,
        utmSource: b.utm_source ? String(b.utm_source) : null,
        utmMedium: b.utm_medium ? String(b.utm_medium) : null,
        utmCampaign: b.utm_campaign ? String(b.utm_campaign) : null,
        utmContent: b.utm_content ? String(b.utm_content) : null,
        utmTerm: b.utm_term ? String(b.utm_term) : null,
      },
    });

    // Fire-and-forget notification so a real follow-up can happen.
    await notifyTeam(lead);

    return NextResponse.json({ code: STANDING_CODE }, { status: 200 });
  } catch (err) {
    console.error('issue-code error:', err);
    return NextResponse.json({ error: 'failed to issue code' }, { status: 500 });
  }
}
