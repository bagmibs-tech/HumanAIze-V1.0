import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { upliftForVertical } from '@/lib/tools-benchmarks';

export const dynamic = 'force-dynamic';

// POST /api/tools/validate-code — Blind Spot Calculator unlock
export async function POST(request: NextRequest) {
  try {
    const b = await request.json();
    const code = String(b?.code || '').trim().toUpperCase();

    let valid = false;
    if (code) {
      const row = await prisma.blindspotCode.findUnique({ where: { code } });
      if (row && row.active && (!row.expiresAt || row.expiresAt.getTime() > Date.now())) {
        valid = true;
      }
    }

    // Log every unlock attempt (valid or not) for attempt analytics.
    try {
      await prisma.blindspotUnlock.create({
        data: {
          code: code || '(empty)',
          organisation: b.organisation ? String(b.organisation) : null,
          region: b.region ? String(b.region) : null,
          vertical: b.vertical ? String(b.vertical) : null,
          costOfInaction: b.costOfInaction != null ? Number(b.costOfInaction) : null,
          currency: b.currency ? String(b.currency) : null,
          valid,
        },
      });
    } catch (logErr) {
      console.error('unlock log error:', logErr);
    }

    if (!valid) {
      return NextResponse.json({ valid: false }, { status: 200 });
    }

    const uplift = upliftForVertical(String(b?.vertical || ''));
    return NextResponse.json({ valid: true, uplift }, { status: 200 });
  } catch (err) {
    console.error('validate-code error:', err);
    return NextResponse.json({ valid: false }, { status: 200 });
  }
}
