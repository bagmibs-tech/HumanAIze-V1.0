import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

const emailOk = (e: string) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e || '');

// POST /api/tools/leads — AI Readiness Diagnostic lead capture
export async function POST(request: NextRequest) {
  try {
    const b = await request.json();
    if (!b?.name || !emailOk(b?.email) || !b?.company) {
      return NextResponse.json({ status: 'error', error: 'name, valid email and company are required' }, { status: 400 });
    }

    const lead = await prisma.readinessLead.create({
      data: {
        name: String(b.name),
        email: String(b.email),
        company: String(b.company),
        phone: b.phone ? String(b.phone) : null,
        region: b.region ? String(b.region) : null,
        industry: b.industry ? String(b.industry) : null,
        overallScore: b.overall_score != null ? Number(b.overall_score) : null,
        overallStage: b.overall_stage != null ? Number(b.overall_stage) : null,
        dimensionScores: b.dimension_scores ?? undefined,
        recommendedPillar: b.recommended_pillar ? String(b.recommended_pillar) : null,
        utmSource: b.utm_source ? String(b.utm_source) : null,
        utmMedium: b.utm_medium ? String(b.utm_medium) : null,
        utmCampaign: b.utm_campaign ? String(b.utm_campaign) : null,
        utmContent: b.utm_content ? String(b.utm_content) : null,
        utmTerm: b.utm_term ? String(b.utm_term) : null,
        submittedAt: b.submitted_at ? new Date(b.submitted_at) : new Date(),
      },
    });

    return NextResponse.json({ status: 'ok', leadId: lead.id }, { status: 200 });
  } catch (err) {
    console.error('readiness lead error:', err);
    return NextResponse.json({ status: 'error', error: 'failed to store lead' }, { status: 500 });
  }
}
