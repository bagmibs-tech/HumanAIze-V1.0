export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { verifyPassword, expectedToken, ADMIN_COOKIE } from '@/lib/admin-auth';

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const password = typeof body?.password === 'string' ? body.password : '';
    if (!verifyPassword(password)) {
      return NextResponse.json({ ok: false, error: 'Invalid password' }, { status: 401 });
    }
    const res = NextResponse.json({ ok: true });
    res.cookies.set(ADMIN_COOKIE, expectedToken(), {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 12,
    });
    return res;
  } catch {
    return NextResponse.json({ ok: false, error: 'Bad request' }, { status: 400 });
  }
}
